<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Acesso à rede de apoio estudantil Salve Aluno.">
    <title>Acesso | Salve Aluno</title>
    <link rel="icon" type="image/png" href="assets/images/logo-salve-aluno-icon-preview.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="css/brand-logo.css">
    <link rel="stylesheet" href="css/accessibility.css">
</head>
<body class="auth-page">
    <main class="auth-layout">
        <section class="auth-intro">
            <a class="brand brand-light" href="index.php" aria-label="Salve Aluno - Página inicial"><img class="brand-logo" src="assets/images/logo-salve-aluno-icon.png" alt="Logo Salve Aluno"><span>salve<span class="brand-accent">.</span>aluno</span></a>
            <div class="auth-intro-copy"><p class="eyebrow auth-eyebrow">Uma rede que escuta</p><h1>Seu apoio começa com uma conversa.</h1><p>Entre para acompanhar sua jornada e fortalecer a rede de apoio da sua escola.</p></div>
            <p class="auth-intro-note">Seguro, gratuito e feito para cada trajetória.</p>
        </section>
        <section class="auth-panel" aria-labelledby="auth-title">
            <div class="auth-panel-inner">
                <a class="brand auth-mobile-brand" href="index.php" aria-label="Salve Aluno - Página inicial"><img class="brand-logo" src="assets/images/logo-salve-aluno-icon.png" alt="Logo Salve Aluno"><span>salve<span class="brand-accent">.</span>aluno</span></a>
                <div class="auth-view active" data-auth-panel="login">
                    <p class="eyebrow">Acesso seguro</p><h2 id="auth-title">Bem-vindo de volta.</h2><p class="muted">Escolha seu perfil para entrar no painel correspondente.</p>
                    <form id="loginForm" class="auth-form">
                        <fieldset class="profile-selector"><legend>Eu sou</legend><button type="button" class="profile-btn active" data-profile="aluno"><span>♙</span>Aluno</button><button type="button" class="profile-btn" data-profile="professor"><span>▤</span>Professor</button><button type="button" class="profile-btn" data-profile="escola"><span>⌂</span>Escola</button><button type="button" class="profile-btn" data-profile="assistente"><span>◌</span>Assistente social</button><button type="button" class="profile-btn" data-profile="admin"><span>⚙</span>Administrador</button></fieldset>
                        <label for="loginEmail">E-mail</label><input id="loginEmail" name="email" type="email" placeholder="aluno@escola.edu.br" required>
                        <label for="loginPassword">Senha</label><div class="auth-password"><input id="loginPassword" name="password" type="password" placeholder="Digite sua senha" required><button type="button" class="password-toggle" aria-label="Mostrar senha">◉</button></div>
                        <div class="auth-form-row"><label class="checkbox-label"><input type="checkbox" name="remember"> <span>Manter conectado</span></label><button class="auth-link forgot-trigger" type="button">Esqueci minha senha</button></div>
                        <button class="button button-primary button-wide" type="submit">Entrar no painel <span>→</span></button><p id="loginMessage" class="form-message" role="status"></p>
                    </form>
                </div>
                <div class="auth-view" data-auth-panel="forgot" hidden><p class="eyebrow">Recuperação de acesso</p><h2>Vamos recuperar sua senha.</h2><p class="muted">Informe o e-mail cadastrado. Neste protótipo, a confirmação aparece aqui mesmo.</p><form id="forgotForm" class="auth-form"><label for="forgotEmail">E-mail</label><input id="forgotEmail" type="email" required placeholder="voce@escola.edu.br"><button class="button button-primary button-wide" type="submit">Enviar instruções <span>→</span></button><p id="forgotMessage" class="form-message" role="status"></p></form><button class="auth-link back-login" type="button">Voltar para entrar</button></div>
            </div>
            <footer class="auth-footer"><a href="index.php">Voltar à página inicial</a><span>Privacidade e segurança</span></footer>
        </section>
    </main>
    <script src="js/api-client.js"></script>
    <script src="js/login.js"></script>
<script src="js/buttons.js"></script>
<script src="js/accessibility.js"></script>
</body>
</html>
