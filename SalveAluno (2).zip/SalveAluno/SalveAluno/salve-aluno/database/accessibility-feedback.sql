-- Optional, standalone schema for future accessibility feedback submissions.
-- This file is intentionally separate and is not imported by the application.
-- Do not store names, email addresses, health data, or accessibility preferences here.
CREATE TABLE IF NOT EXISTS accessibility_feedback (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    category ENUM('libras', 'audio', 'visual', 'keyboard', 'screen_reader', 'forms', 'other') NOT NULL,
    page_path VARCHAR(255) NOT NULL DEFAULT '',
    message TEXT NOT NULL,
    consent_given TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY accessibility_feedback_created_at (created_at),
    KEY accessibility_feedback_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
