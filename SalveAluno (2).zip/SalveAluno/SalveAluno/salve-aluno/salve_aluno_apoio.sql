-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27/10/2026 às 20:41
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `salve_aluno_apoio`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `acessibilidade_oportunidades`
--

CREATE TABLE `acessibilidade_oportunidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `oportunidade_id` bigint(20) UNSIGNED NOT NULL,
  `possui_rampa` tinyint(1) NOT NULL DEFAULT 0,
  `banheiro_adaptado` tinyint(1) NOT NULL DEFAULT 0,
  `atendimento_prioritario` tinyint(1) NOT NULL DEFAULT 0,
  `libras` tinyint(1) NOT NULL DEFAULT 0,
  `descricao` varchar(500) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `alertas`
--

CREATE TABLE `alertas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `aluno_id` bigint(20) UNSIGNED DEFAULT NULL,
  `diagnostico_id` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `tipo` varchar(50) NOT NULL,
  `titulo` varchar(160) NOT NULL,
  `mensagem` text NOT NULL,
  `severidade` enum('informativo','atencao','alto','urgente') NOT NULL DEFAULT 'informativo',
  `lido_em` datetime DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `alunos`
--

CREATE TABLE `alunos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `matricula` varchar(40) NOT NULL DEFAULT '',
  `turma` varchar(60) NOT NULL DEFAULT '',
  `serie` varchar(40) NOT NULL DEFAULT '',
  `turno` varchar(30) NOT NULL DEFAULT '',
  `data_nascimento` date DEFAULT NULL,
  `possui_deficiencia` tinyint(1) NOT NULL DEFAULT 0,
  `necessidades_acessibilidade` varchar(500) NOT NULL DEFAULT '',
  `responsavel_nome` varchar(120) NOT NULL DEFAULT '',
  `responsavel_contato` varchar(120) NOT NULL DEFAULT '',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `alunos`
--

INSERT INTO `alunos` (`id`, `usuario_id`, `escola_id`, `matricula`, `turma`, `serie`, `turno`, `data_nascimento`, `possui_deficiencia`, `necessidades_acessibilidade`, `responsavel_nome`, `responsavel_contato`, `criado_em`) VALUES
(1, 2, 1, 'ALUNO-001', '8º ano A', '8º ano', 'manhã', NULL, 0, '', '', '', '2026-10-27 17:29:09');

-- --------------------------------------------------------

--
-- Estrutura para tabela `anexos_solicitacoes`
--

CREATE TABLE `anexos_solicitacoes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `solicitacao_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `nome_original` varchar(255) NOT NULL,
  `mime_type` varchar(120) NOT NULL,
  `caminho_armazenamento` varchar(500) NOT NULL,
  `tamanho_bytes` int(10) UNSIGNED NOT NULL,
  `enviado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `arquivos_registro`
--

CREATE TABLE `arquivos_registro` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `record_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `content_type` varchar(100) NOT NULL,
  `content` mediumblob NOT NULL,
  `created_at` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `assistentes`
--

CREATE TABLE `assistentes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `registro_profissional` varchar(60) NOT NULL DEFAULT '',
  `especialidade` varchar(120) NOT NULL DEFAULT '',
  `territorio_atendimento` varchar(255) NOT NULL DEFAULT '',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `assistentes`
--

INSERT INTO `assistentes` (`id`, `usuario_id`, `escola_id`, `registro_profissional`, `especialidade`, `territorio_atendimento`, `criado_em`) VALUES
(1, 5, 1, 'AS-001', 'Assistência social escolar', 'Comunidade escolar e território próximo', '2026-10-27 17:30:11');

-- --------------------------------------------------------

--
-- Estrutura para tabela `atendimentos`
--

CREATE TABLE `atendimentos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `aluno_id` bigint(20) UNSIGNED NOT NULL,
  `assistente_id` bigint(20) UNSIGNED DEFAULT NULL,
  `criado_por` bigint(20) UNSIGNED NOT NULL,
  `tipo` varchar(60) NOT NULL,
  `motivo` varchar(255) NOT NULL DEFAULT '',
  `observacoes` text NOT NULL,
  `inicio` datetime NOT NULL,
  `fim` datetime DEFAULT NULL,
  `status` enum('agendado','em_atendimento','concluido','cancelado','faltou') NOT NULL DEFAULT 'agendado',
  `encaminhamento_necessario` tinyint(1) NOT NULL DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `auditoria_lgpd`
--

CREATE TABLE `auditoria_lgpd` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` bigint(20) UNSIGNED DEFAULT NULL,
  `escola_id` bigint(20) UNSIGNED DEFAULT NULL,
  `acao` varchar(80) NOT NULL,
  `entidade` varchar(80) NOT NULL,
  `entidade_id` varchar(64) NOT NULL DEFAULT '',
  `finalidade` varchar(120) NOT NULL DEFAULT '',
  `dados_minimizados_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_minimizados_json`)),
  `ip_hash` char(64) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `beneficios`
--

CREATE TABLE `beneficios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `categoria_id` bigint(20) UNSIGNED NOT NULL,
  `titulo` varchar(160) NOT NULL,
  `descricao` text NOT NULL,
  `tipo` varchar(40) NOT NULL DEFAULT 'doacao',
  `quantidade_total` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `quantidade_disponivel` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `valor_referencia` decimal(10,2) DEFAULT NULL,
  `imagem` varchar(255) NOT NULL DEFAULT '',
  `tamanho` varchar(80) NOT NULL DEFAULT '',
  `status` enum('disponivel','esgotado','arquivado') NOT NULL DEFAULT 'disponivel',
  `criado_por` bigint(20) UNSIGNED NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias_auxilio`
--

CREATE TABLE `categorias_auxilio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(48) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(240) NOT NULL DEFAULT '',
  `ativa` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `categorias_auxilio`
--

INSERT INTO `categorias_auxilio` (`id`, `slug`, `nome`, `descricao`, `ativa`) VALUES
(1, 'materiais', 'Materiais escolares', 'Cadernos, mochilas e itens para estudar.', 1),
(2, 'roupas', 'Roupas', 'Roupas em bom estado.', 1),
(3, 'tecnologia', 'Tecnologia', 'Equipamentos e conectividade.', 1),
(4, 'alimentacao', 'Alimentação e higiene', 'Itens essenciais para a rotina escolar.', 1),
(5, 'transporte', 'Transporte', 'Apoio para deslocamento e permanência.', 1),
(6, 'uniformes', 'Uniformes', 'Uniformes escolares em bom estado.', 1),
(7, 'livros', 'Livros', 'Livros didáticos e materiais de leitura.', 1),
(8, 'calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.', 1),
(9, 'outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias_beneficios`
--

CREATE TABLE `categorias_beneficios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `slug` varchar(60) NOT NULL,
  `descricao` varchar(255) NOT NULL DEFAULT '',
  `ativa` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `categorias_beneficios`
--

INSERT INTO `categorias_beneficios` (`id`, `nome`, `slug`, `descricao`, `ativa`) VALUES
(1, 'Materiais escolares', 'materiais', 'Cadernos, mochilas e itens para estudar.', 1),
(2, 'Roupas', 'roupas', 'Roupas em bom estado.', 1),
(3, 'Tecnologia', 'tecnologia', 'Equipamentos e conectividade.', 1),
(4, 'Alimentação e higiene', 'alimentacao', 'Itens essenciais para a rotina escolar.', 1),
(5, 'Transporte', 'transporte', 'Apoio para deslocamento e permanência.', 1),
(6, 'Uniformes', 'uniformes', 'Uniformes escolares em bom estado.', 1),
(7, 'Livros', 'livros', 'Livros didáticos e materiais de leitura.', 1),
(8, 'Calçados', 'calcados', 'Calçados em bom estado para o dia a dia.', 1),
(9, 'Outros', 'outros', 'Outros recursos para apoiar a permanência estudantil.', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `checkins`
--

CREATE TABLE `checkins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `professor_id` bigint(20) UNSIGNED NOT NULL,
  `turma` varchar(60) NOT NULL,
  `clima` enum('bem','estavel','atencao','critico') NOT NULL,
  `participacao` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `presenca` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `observacao` varchar(1000) NOT NULL DEFAULT '',
  `realizado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `comunicados`
--

CREATE TABLE `comunicados` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `publicado_por` bigint(20) UNSIGNED NOT NULL,
  `titulo` varchar(180) NOT NULL,
  `mensagem` text NOT NULL,
  `publico` varchar(30) NOT NULL DEFAULT 'todos',
  `publicado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `expira_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `consentimentos_lgpd`
--

CREATE TABLE `consentimentos_lgpd` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `finalidade` varchar(100) NOT NULL,
  `versao_politica` varchar(30) NOT NULL,
  `consentiu` tinyint(1) NOT NULL,
  `origem` varchar(80) NOT NULL DEFAULT 'aplicacao',
  `ip_hash` char(64) DEFAULT NULL,
  `consentido_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `revogado_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `diagnosticos`
--

CREATE TABLE `diagnosticos` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `aluno_id` bigint(20) UNSIGNED DEFAULT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `perfil_codigo` varchar(30) NOT NULL,
  `score` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `nivel_atencao` enum('estavel','acompanhar','prioritario') NOT NULL,
  `resumo` varchar(500) NOT NULL,
  `respondido_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `encaminhamentos`
--

CREATE TABLE `encaminhamentos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `aluno_id` bigint(20) UNSIGNED NOT NULL,
  `criado_por` bigint(20) UNSIGNED NOT NULL,
  `destino` varchar(100) NOT NULL,
  `motivo` varchar(255) NOT NULL,
  `observacao` text NOT NULL,
  `prioridade` enum('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
  `status` enum('aberto','em_acompanhamento','resolvido','cancelado') NOT NULL DEFAULT 'aberto',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `concluido_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `encerramentos_reuniao`
--

CREATE TABLE `encerramentos_reuniao` (
  `meeting_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `closed_at` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `escolas`
--

CREATE TABLE `escolas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(160) NOT NULL,
  `codigo` varchar(64) NOT NULL,
  `cnpj` varchar(18) DEFAULT NULL,
  `email` varchar(254) NOT NULL DEFAULT '',
  `telefone` varchar(40) NOT NULL DEFAULT '',
  `endereco` varchar(255) NOT NULL DEFAULT '',
  `cidade` varchar(100) NOT NULL DEFAULT '',
  `estado` char(2) NOT NULL DEFAULT '',
  `turno_principal` varchar(30) NOT NULL DEFAULT '',
  `ativa` tinyint(1) NOT NULL DEFAULT 1,
  `criada_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizada_em` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `escolas`
--

INSERT INTO `escolas` (`id`, `nome`, `codigo`, `cnpj`, `email`, `telefone`, `endereco`, `cidade`, `estado`, `turno_principal`, `ativa`, `criada_em`, `atualizada_em`) VALUES
(1, 'Escola Municipal', 'escola-municipal', NULL, '', '', '', '', '', 'manhã e tarde', 1, '2026-10-27 17:25:44', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_solidarios`
--

CREATE TABLE `itens_solidarios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `categoria_id` bigint(20) UNSIGNED NOT NULL,
  `school_key` varchar(64) NOT NULL,
  `titulo` varchar(160) NOT NULL,
  `descricao` text NOT NULL,
  `tamanho` varchar(80) NOT NULL DEFAULT '',
  `condicao` varchar(80) NOT NULL DEFAULT 'Novo ou em ótimo estado',
  `quantidade_total` int(10) UNSIGNED NOT NULL,
  `quantidade_disponivel` int(10) UNSIGNED NOT NULL,
  `caminho_imagem` varchar(255) NOT NULL DEFAULT '',
  `tipo` varchar(20) NOT NULL DEFAULT 'doacao',
  `doador` varchar(120) NOT NULL DEFAULT 'An??nimo',
  `data_doacao` varchar(10) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'disponivel',
  `chave_seed` varchar(60) DEFAULT NULL,
  `criado_por` bigint(20) UNSIGNED NOT NULL,
  `criado_em` varchar(35) NOT NULL,
  `atualizado_em` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itens_solidarios`
--

INSERT INTO `itens_solidarios` (`id`, `categoria_id`, `school_key`, `titulo`, `descricao`, `tamanho`, `condicao`, `quantidade_total`, `quantidade_disponivel`, `caminho_imagem`, `tipo`, `doador`, `data_doacao`, `status`, `chave_seed`, `criado_por`, `criado_em`, `atualizado_em`) VALUES
(1, 1, 'escola-municipal', 'Kit Material Escolar', 'Kit Material Escolar - Lápis de cor, tesoura, borracha', 'Médio', 'Novo', 10, 10, 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=900&q=80', 'doacao', 'Escola Ijima', NULL, 'disponivel', NULL, 5, '2026-10-27T19:08:53+00:00', NULL),
(2, 8, 'escola-municipal', 'Tênis Branco', 'Calçados brancos all star', '37', 'Seminovo', 3, 3, 'assets/images/doacao-roupas.jpg', 'doacao', 'Bazar Flor', NULL, 'disponivel', NULL, 5, '2026-10-27T19:09:57+00:00', NULL),
(3, 7, 'escola-municipal', 'Kit Livros Literatura', 'Kit Livros Literatura - empréstimo para trabalhos escolares', 'Médio', 'Novo', 7, 7, 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=80', 'emprestimo', 'Biblioteca Municipal', NULL, 'disponivel', NULL, 5, '2026-10-27T19:10:53+00:00', NULL),
(4, 3, 'escola-municipal', 'Notebook Positivo', 'Notebooks Positivo para trabalhos escolares', 'Pequeno', 'Novo ou em ótimo estado', 6, 6, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80', 'emprestimo', 'Escola Girassol', NULL, 'disponivel', NULL, 5, '2026-10-27T19:11:48+00:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `limites_tentativa`
--

CREATE TABLE `limites_tentativa` (
  `rate_key` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `attempts` int(10) UNSIGNED NOT NULL,
  `window_started` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `limites_tentativa`
--

INSERT INTO `limites_tentativa` (`rate_key`, `attempts`, `window_started`) VALUES
('1603e8026847ca244552950b1a5bf06bb1fa1d0013de7d956848523af3f3c779', 1, 1793129031),
('577eb45ff0fb55867e7ca9964f72f082ea1f43cd3cb854e02ef8597f62c97d19', 2, 1793122836),
('7541c8de469bda38324c782d9ffa49bf3f4761fe11f7c2e22961d228d16814e1', 1, 1793129012),
('bd87260d3ad0868510e0b0be10b75eac5dacb41674b8fca3fe594c1d57cf7743', 2, 1793127480),
('db79f97776dd95de68998fdf24b97f452e7b63e4eef7a5eae9c9d83f528929a1', 1, 1793128325),
('edf7c677f0e8921de2bfca0b376b323737d3a047d9ddd4d73feb4ec358a5a394', 1, 1793129803);

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens_canal_seguro`
--

CREATE TABLE `mensagens_canal_seguro` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `remetente_usuario_id` bigint(20) UNSIGNED NOT NULL,
  `aluno_id` bigint(20) UNSIGNED DEFAULT NULL,
  `destinatario_usuario_id` bigint(20) UNSIGNED DEFAULT NULL,
  `anonima` tinyint(1) NOT NULL DEFAULT 0,
  `assunto` varchar(160) NOT NULL DEFAULT '',
  `mensagem` text NOT NULL,
  `criptografada` tinyint(1) NOT NULL DEFAULT 0,
  `lida_em` datetime DEFAULT NULL,
  `enviada_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `movimentacoes_auxilio`
--

CREATE TABLE `movimentacoes_auxilio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `solicitacao_id` char(32) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `tipo_movimentacao` varchar(32) NOT NULL,
  `quantidade` int(10) UNSIGNED NOT NULL,
  `observacao` varchar(500) NOT NULL DEFAULT '',
  `criado_em` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notificacoes_solidarias`
--

CREATE TABLE `notificacoes_solidarias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `mensagem` varchar(500) NOT NULL,
  `tipo` varchar(32) NOT NULL,
  `criada_em` varchar(35) NOT NULL,
  `lida_em` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `oportunidades`
--

CREATE TABLE `oportunidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED DEFAULT NULL,
  `titulo` varchar(180) NOT NULL,
  `tipo` enum('curso','jovem_aprendiz','bico','biblioteca','telecentro','maker','outro') NOT NULL,
  `descricao` text NOT NULL,
  `organizacao` varchar(160) NOT NULL DEFAULT '',
  `endereco` varchar(255) NOT NULL DEFAULT '',
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `distancia_escola_km` decimal(6,2) DEFAULT NULL,
  `turno` varchar(40) NOT NULL DEFAULT '',
  `bolsa` decimal(10,2) DEFAULT NULL,
  `gratuita` tinyint(1) NOT NULL DEFAULT 0,
  `acessivel` tinyint(1) NOT NULL DEFAULT 0,
  `turno_inverso` tinyint(1) NOT NULL DEFAULT 0,
  `ativa` tinyint(1) NOT NULL DEFAULT 1,
  `criada_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `participantes_reuniao`
--

CREATE TABLE `participantes_reuniao` (
  `meeting_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `participant_name` varchar(120) NOT NULL,
  `created_at` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `perfis`
--

CREATE TABLE `perfis` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `codigo` varchar(30) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `descricao` varchar(255) NOT NULL DEFAULT '',
  `permite_diagnostico` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `perfis`
--

INSERT INTO `perfis` (`id`, `codigo`, `nome`, `descricao`, `permite_diagnostico`, `criado_em`) VALUES
(1, 'admin', 'Administrador', 'Administração técnica e de acessos', 0, '2026-10-27 17:25:44'),
(2, 'aluno', 'Aluno', 'Estudante da escola', 1, '2026-10-27 17:25:44'),
(3, 'professor', 'Professor', 'Professor ou educador', 1, '2026-10-27 17:25:44'),
(4, 'escola', 'Gestão escolar', 'Gestão e coordenação da escola', 1, '2026-10-27 17:25:44'),
(5, 'assistente', 'Assistente social', 'Acompanhamento e rede de proteção', 1, '2026-10-27 17:25:44');

-- --------------------------------------------------------

--
-- Estrutura para tabela `professores`
--

CREATE TABLE `professores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `registro_profissional` varchar(60) NOT NULL DEFAULT '',
  `area_atuacao` varchar(120) NOT NULL DEFAULT '',
  `turmas_json` longtext NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `professores`
--

INSERT INTO `professores` (`id`, `usuario_id`, `escola_id`, `registro_profissional`, `area_atuacao`, `turmas_json`, `criado_em`) VALUES
(1, 3, 1, 'PROF-001', 'Educação básica', '[\"8º ano A\", \"9º ano B\"]', '2026-10-27 17:29:42');

-- --------------------------------------------------------

--
-- Estrutura para tabela `registros`
--

CREATE TABLE `registros` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(40) NOT NULL,
  `data_json` longtext NOT NULL,
  `created_at` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `registros`
--

INSERT INTO `registros` (`id`, `user_id`, `type`, `data_json`, `created_at`) VALUES
('0e250596c275d231442f571a968ebfc3', 6, 'student_request', '{\"category\":\"Empréstimo de notebook\",\"description\":\"Notebook para estudo\",\"requestedDate\":\"2026-12-14\"}', '2026-10-27T17:44:26+00:00'),
('0fa3424a8fdbe92022813c1452461b52', 2, 'student_request', '{\"category\":\"Auxílio transporte\",\"description\":\"Auxilio transporte\",\"requestedDate\":\"2026-09-12\"}', '2026-10-27T19:24:26+00:00'),
('2fb76a069b282e492c506f4fbca3a616', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:09+00:00'),
('4ea783da60e987789502d3dcdeed23c9', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":true,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:03+00:00'),
('5501a82f22006d6150349230ad1c57e0', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:44:59+00:00'),
('81cab0dc31d19f4c1ae6dcd72e1bc733', 2, 'student_diagnostic', '{\"answers\":{\"transport\":\"10\",\"internet\":\"20\",\"food\":\"10\",\"school\":\"10\"},\"score\":50,\"level\":\"moderado\"}', '2026-10-27T17:39:08+00:00'),
('87c28d9a08383fd7bb6d3523a66684e8', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:05+00:00'),
('91a9848356efe074d258290545fff8e8', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":true,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:00+00:00'),
('b05bae77d8fb77dd3eb12093f4aa3575', 6, 'profile_update', '{\"preferences\":{\"darkMode\":true,\"colorblindMode\":true,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:02+00:00'),
('ba60513d39cd300493f7fd9aebe867da', 3, 'class_checkin', '{\"className\":\"Minha turma\",\"details\":\"Ruim\"}', '2026-10-27T17:40:15+00:00'),
('f1cb6cb0000b3152c3ce3400ca763db9', 6, 'profile_update', '{\"preferences\":{\"darkMode\":true,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:45:06+00:00'),
('f69108b465686f0d433219a4cf9309b8', 6, 'profile_update', '{\"preferences\":{\"darkMode\":false,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:44:57+00:00'),
('f8dd2a34b81a65f327e8570e6dda7e92', 6, 'profile_update', '{\"preferences\":{\"darkMode\":true,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}}', '2026-10-27T17:44:58+00:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `respostas_diagnostico`
--

CREATE TABLE `respostas_diagnostico` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `diagnostico_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `chave_pergunta` varchar(60) NOT NULL,
  `pergunta` varchar(255) NOT NULL,
  `valor` tinyint(3) UNSIGNED NOT NULL,
  `resposta` varchar(255) NOT NULL,
  `respondida_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `reunioes`
--

CREATE TABLE `reunioes` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `school_key` varchar(64) NOT NULL,
  `title` varchar(160) NOT NULL,
  `description` text NOT NULL,
  `meeting_date` varchar(64) NOT NULL,
  `cancelled` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` varchar(35) NOT NULL,
  `cancelled_at` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `seguranca_oportunidades`
--

CREATE TABLE `seguranca_oportunidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `oportunidade_id` bigint(20) UNSIGNED NOT NULL,
  `iluminacao_nivel` enum('nao_informado','baixo','medio','alto') NOT NULL DEFAULT 'nao_informado',
  `rota_segura` tinyint(1) NOT NULL DEFAULT 0,
  `transporte_proximo` tinyint(1) NOT NULL DEFAULT 0,
  `paradas_proximas` varchar(255) NOT NULL DEFAULT '',
  `relatos_comunidade` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `sessoes_usuario`
--

CREATE TABLE `sessoes_usuario` (
  `id` char(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `usuario_id` bigint(20) UNSIGNED NOT NULL,
  `csrf_hash` char(64) NOT NULL,
  `ultimo_acesso_em` datetime NOT NULL,
  `expira_em` datetime NOT NULL,
  `revogada_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes`
--

CREATE TABLE `solicitacoes` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `aluno_id` bigint(20) UNSIGNED NOT NULL,
  `beneficio_id` bigint(20) UNSIGNED DEFAULT NULL,
  `escola_id` bigint(20) UNSIGNED NOT NULL,
  `categoria` varchar(80) NOT NULL,
  `descricao` text NOT NULL,
  `quantidade` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `data_preferencial` date DEFAULT NULL,
  `prioridade` enum('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
  `status` enum('recebida','em_analise','aprovada','recusada','entregue','cancelada') NOT NULL DEFAULT 'recebida',
  `analisada_por` bigint(20) UNSIGNED DEFAULT NULL,
  `criada_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `analisada_em` datetime DEFAULT NULL,
  `concluida_em` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `solicitacoes_auxilio`
--

CREATE TABLE `solicitacoes_auxilio` (
  `id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `school_key` varchar(64) NOT NULL,
  `quantidade` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `observacao` varchar(1000) NOT NULL DEFAULT '',
  `tipo` varchar(20) NOT NULL DEFAULT 'doacao',
  `prazo_devolucao` varchar(10) DEFAULT NULL,
  `data_retirada` varchar(10) DEFAULT NULL,
  `precisa_busca` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'pendente',
  `requested_at` varchar(35) NOT NULL,
  `reviewed_at` varchar(35) DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `delivered_at` varchar(35) DEFAULT NULL,
  `received_at` varchar(35) DEFAULT NULL,
  `returned_at` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escola_id` bigint(20) UNSIGNED DEFAULT NULL,
  `perfil_id` smallint(5) UNSIGNED DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `profile` varchar(20) NOT NULL,
  `name` varchar(120) NOT NULL,
  `phone` varchar(40) NOT NULL DEFAULT '',
  `details_json` longtext NOT NULL,
  `quiz_json` longtext NOT NULL,
  `preferences_json` longtext NOT NULL,
  `school_key` varchar(64) NOT NULL DEFAULT 'escola-municipal',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_login_em` datetime DEFAULT NULL,
  `created_at` varchar(35) NOT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `escola_id`, `perfil_id`, `email`, `password_hash`, `profile`, `name`, `phone`, `details_json`, `quiz_json`, `preferences_json`, `school_key`, `ativo`, `ultimo_login_em`, `created_at`, `criado_em`, `atualizado_em`) VALUES
(1, NULL, 1, 'admin@salvealuno.local', '$2b$10$m7yqjFTe2RCdnLn2jsY7NOJ04VM2.VehTbZwepl1tmTSwtWRwHVDG', 'admin', 'Administrador Salve Aluno', '', '{}', '{}', '{}', 'escola-municipal', 1, NULL, '2026-10-27T14:00:00Z', '2026-10-27 17:27:58', NULL),
(2, 1, 2, 'aluno@escola.edu.br', '$2b$10$zkuxGx29sS95RLyWhc/RMe6bVQ6Y7358fxr6YH8rykyp6JN8ovcIy', 'aluno', 'Aluno Padrão', '', '{}', '{}', '{}', 'escola-municipal', 1, NULL, '2026-10-27T14:00:00Z', '2026-10-27 17:27:58', NULL),
(3, 1, 3, 'professor@escola.edu.br', '$2b$10$GJIeCJhVlFIEQy6GE8IY3uBDEFJkeMcw0S6UH2tx2eA.USV0SUcXm', 'professor', 'Professor Padrão', '', '{}', '{}', '{}', 'escola-municipal', 1, NULL, '2026-10-27T14:00:00Z', '2026-10-27 17:27:58', NULL),
(4, 1, 4, 'gestao@escola.edu.br', '$2b$10$DBH/b48.XWTuUx9kUcKcNuLrMpo/VGWgRyqVSzdKLKbcu9bgTr5Bq', 'escola', 'Gestão Escolar', '', '{}', '{}', '{}', 'escola-municipal', 1, NULL, '2026-10-27T14:00:00Z', '2026-10-27 17:27:58', NULL),
(5, 1, 5, 'assistente@escola.edu.br', '$2b$10$gP4/kIZzjZV/cfSWwBQEp.APnVXZKdBZlptawadGhPvJOIX.yFh0y', 'assistente', 'Assistente Social', '', '{}', '{}', '{}', 'escola-municipal', 1, NULL, '2026-10-27T14:00:00Z', '2026-10-27 17:27:58', NULL),
(6, NULL, NULL, 'clarice@escola.edu.br', '$2y$10$cMrnzgxFr6s.bi5X8WfTceaC6kXLYx91KV.jOV./jIGJJITXLATXW', 'aluno', 'Clarice', '', '{\"institution\":\"Escola Municipal\"}', '{}', '{\"darkMode\":false,\"colorblindMode\":false,\"notifications\":true,\"opportunities\":true}', 'escola-municipal', 1, NULL, '2026-10-27T17:41:47+00:00', '2026-10-27 17:41:47', '2026-10-27 17:45:09');

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `vw_oportunidades_seguras`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `vw_oportunidades_seguras` (
`id` bigint(20) unsigned
,`escola_id` bigint(20) unsigned
,`titulo` varchar(180)
,`tipo` enum('curso','jovem_aprendiz','bico','biblioteca','telecentro','maker','outro')
,`descricao` text
,`organizacao` varchar(160)
,`endereco` varchar(255)
,`latitude` decimal(10,7)
,`longitude` decimal(10,7)
,`distancia_escola_km` decimal(6,2)
,`turno` varchar(40)
,`bolsa` decimal(10,2)
,`gratuita` tinyint(1)
,`acessivel` tinyint(1)
,`turno_inverso` tinyint(1)
,`ativa` tinyint(1)
,`criada_em` timestamp
,`iluminacao_nivel` enum('nao_informado','baixo','medio','alto')
,`rota_segura` tinyint(1)
,`transporte_proximo` tinyint(1)
,`possui_rampa` tinyint(1)
,`banheiro_adaptado` tinyint(1)
,`atendimento_prioritario` tinyint(1)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `vw_resumo_risco_escolar`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `vw_resumo_risco_escolar` (
`escola_id` bigint(20) unsigned
,`nivel_atencao` enum('estavel','acompanhar','prioritario')
,`total_diagnosticos` bigint(21)
,`ultimo_diagnostico` timestamp
);

-- --------------------------------------------------------

--
-- Estrutura para view `vw_oportunidades_seguras`
--
DROP TABLE IF EXISTS `vw_oportunidades_seguras`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_oportunidades_seguras`  AS SELECT `o`.`id` AS `id`, `o`.`escola_id` AS `escola_id`, `o`.`titulo` AS `titulo`, `o`.`tipo` AS `tipo`, `o`.`descricao` AS `descricao`, `o`.`organizacao` AS `organizacao`, `o`.`endereco` AS `endereco`, `o`.`latitude` AS `latitude`, `o`.`longitude` AS `longitude`, `o`.`distancia_escola_km` AS `distancia_escola_km`, `o`.`turno` AS `turno`, `o`.`bolsa` AS `bolsa`, `o`.`gratuita` AS `gratuita`, `o`.`acessivel` AS `acessivel`, `o`.`turno_inverso` AS `turno_inverso`, `o`.`ativa` AS `ativa`, `o`.`criada_em` AS `criada_em`, `s`.`iluminacao_nivel` AS `iluminacao_nivel`, `s`.`rota_segura` AS `rota_segura`, `s`.`transporte_proximo` AS `transporte_proximo`, `a`.`possui_rampa` AS `possui_rampa`, `a`.`banheiro_adaptado` AS `banheiro_adaptado`, `a`.`atendimento_prioritario` AS `atendimento_prioritario` FROM ((`oportunidades` `o` left join `seguranca_oportunidades` `s` on(`s`.`oportunidade_id` = `o`.`id`)) left join `acessibilidade_oportunidades` `a` on(`a`.`oportunidade_id` = `o`.`id`)) WHERE `o`.`ativa` = 1 ;

-- --------------------------------------------------------

--
-- Estrutura para view `vw_resumo_risco_escolar`
--
DROP TABLE IF EXISTS `vw_resumo_risco_escolar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_resumo_risco_escolar`  AS SELECT `d`.`escola_id` AS `escola_id`, `d`.`nivel_atencao` AS `nivel_atencao`, count(0) AS `total_diagnosticos`, max(`d`.`respondido_em`) AS `ultimo_diagnostico` FROM `diagnosticos` AS `d` GROUP BY `d`.`escola_id`, `d`.`nivel_atencao` ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `acessibilidade_oportunidades`
--
ALTER TABLE `acessibilidade_oportunidades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `acessibilidade_oportunidade_unica` (`oportunidade_id`);

--
-- Índices de tabela `alertas`
--
ALTER TABLE `alertas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alertas_escola_severidade` (`escola_id`,`severidade`,`criado_em`),
  ADD KEY `alertas_aluno_fk` (`aluno_id`),
  ADD KEY `alertas_diagnostico_fk` (`diagnostico_id`);

--
-- Índices de tabela `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `alunos_usuario_unico` (`usuario_id`),
  ADD KEY `alunos_escola_turma` (`escola_id`,`turma`);

--
-- Índices de tabela `anexos_solicitacoes`
--
ALTER TABLE `anexos_solicitacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `anexos_solicitacoes_fk` (`solicitacao_id`);

--
-- Índices de tabela `arquivos_registro`
--
ALTER TABLE `arquivos_registro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `arquivos_registro_fk` (`record_id`);

--
-- Índices de tabela `assistentes`
--
ALTER TABLE `assistentes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `assistentes_usuario_unico` (`usuario_id`),
  ADD KEY `assistentes_escola_fk` (`escola_id`);

--
-- Índices de tabela `atendimentos`
--
ALTER TABLE `atendimentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `atendimentos_escola_data` (`escola_id`,`inicio`),
  ADD KEY `atendimentos_aluno_status` (`aluno_id`,`status`),
  ADD KEY `atendimentos_assistente_fk` (`assistente_id`),
  ADD KEY `atendimentos_criador_fk` (`criado_por`);

--
-- Índices de tabela `auditoria_lgpd`
--
ALTER TABLE `auditoria_lgpd`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auditoria_entidade_data` (`entidade`,`entidade_id`,`criado_em`),
  ADD KEY `auditoria_usuario_data` (`usuario_id`,`criado_em`),
  ADD KEY `auditoria_escola_fk` (`escola_id`);

--
-- Índices de tabela `beneficios`
--
ALTER TABLE `beneficios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beneficios_escola_status` (`escola_id`,`status`),
  ADD KEY `beneficios_categoria_fk` (`categoria_id`),
  ADD KEY `beneficios_criador_fk` (`criado_por`);

--
-- Índices de tabela `categorias_auxilio`
--
ALTER TABLE `categorias_auxilio`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categorias_auxilio_slug_unico` (`slug`);

--
-- Índices de tabela `categorias_beneficios`
--
ALTER TABLE `categorias_beneficios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categorias_beneficios_slug_unico` (`slug`);

--
-- Índices de tabela `checkins`
--
ALTER TABLE `checkins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `checkins_escola_turma_data` (`escola_id`,`turma`,`realizado_em`),
  ADD KEY `checkins_professor_fk` (`professor_id`);

--
-- Índices de tabela `comunicados`
--
ALTER TABLE `comunicados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comunicados_escola_data` (`escola_id`,`publicado_em`),
  ADD KEY `comunicados_autor_fk` (`publicado_por`);

--
-- Índices de tabela `consentimentos_lgpd`
--
ALTER TABLE `consentimentos_lgpd`
  ADD PRIMARY KEY (`id`),
  ADD KEY `consentimentos_usuario_finalidade` (`usuario_id`,`finalidade`);

--
-- Índices de tabela `diagnosticos`
--
ALTER TABLE `diagnosticos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `diagnosticos_usuario_data` (`usuario_id`,`respondido_em`),
  ADD KEY `diagnosticos_escola_nivel` (`escola_id`,`nivel_atencao`),
  ADD KEY `diagnosticos_aluno_fk` (`aluno_id`);

--
-- Índices de tabela `encaminhamentos`
--
ALTER TABLE `encaminhamentos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `encaminhamentos_aluno_status` (`aluno_id`,`status`),
  ADD KEY `encaminhamentos_escola_fk` (`escola_id`),
  ADD KEY `encaminhamentos_criador_fk` (`criado_por`);

--
-- Índices de tabela `encerramentos_reuniao`
--
ALTER TABLE `encerramentos_reuniao`
  ADD PRIMARY KEY (`meeting_id`,`user_id`),
  ADD KEY `encerramentos_reuniao_usuario_fk` (`user_id`);

--
-- Índices de tabela `escolas`
--
ALTER TABLE `escolas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `escolas_codigo_unico` (`codigo`);

--
-- Índices de tabela `itens_solidarios`
--
ALTER TABLE `itens_solidarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `itens_solidarios_seed_escola` (`school_key`,`chave_seed`),
  ADD KEY `itens_solidarios_categoria_fk` (`categoria_id`),
  ADD KEY `itens_solidarios_criador_fk` (`criado_por`);

--
-- Índices de tabela `limites_tentativa`
--
ALTER TABLE `limites_tentativa`
  ADD PRIMARY KEY (`rate_key`);

--
-- Índices de tabela `mensagens_canal_seguro`
--
ALTER TABLE `mensagens_canal_seguro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mensagens_escola_data` (`escola_id`,`enviada_em`),
  ADD KEY `mensagens_remetente_fk` (`remetente_usuario_id`),
  ADD KEY `mensagens_aluno_fk` (`aluno_id`),
  ADD KEY `mensagens_destinatario_fk` (`destinatario_usuario_id`);

--
-- Índices de tabela `movimentacoes_auxilio`
--
ALTER TABLE `movimentacoes_auxilio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `movimentacoes_auxilio_item_fk` (`item_id`),
  ADD KEY `movimentacoes_auxilio_solicitacao_fk` (`solicitacao_id`),
  ADD KEY `movimentacoes_auxilio_usuario_fk` (`user_id`);

--
-- Índices de tabela `notificacoes_solidarias`
--
ALTER TABLE `notificacoes_solidarias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notificacoes_solidarias_usuario_data` (`user_id`,`criada_em`);

--
-- Índices de tabela `oportunidades`
--
ALTER TABLE `oportunidades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oportunidades_tipo_turno` (`tipo`,`turno`,`ativa`),
  ADD KEY `oportunidades_escola_fk` (`escola_id`);

--
-- Índices de tabela `participantes_reuniao`
--
ALTER TABLE `participantes_reuniao`
  ADD PRIMARY KEY (`meeting_id`,`user_id`),
  ADD KEY `participantes_reuniao_usuario_fk` (`user_id`);

--
-- Índices de tabela `perfis`
--
ALTER TABLE `perfis`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `perfis_codigo_unico` (`codigo`);

--
-- Índices de tabela `professores`
--
ALTER TABLE `professores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `professores_usuario_unico` (`usuario_id`),
  ADD KEY `professores_escola_fk` (`escola_id`);

--
-- Índices de tabela `registros`
--
ALTER TABLE `registros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `registros_usuario_tipo_data` (`user_id`,`type`,`created_at`);

--
-- Índices de tabela `respostas_diagnostico`
--
ALTER TABLE `respostas_diagnostico`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `respostas_diagnostico_unico` (`diagnostico_id`,`chave_pergunta`);

--
-- Índices de tabela `reunioes`
--
ALTER TABLE `reunioes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reunioes_escola_data` (`school_key`,`meeting_date`),
  ADD KEY `reunioes_criador_fk` (`created_by`);

--
-- Índices de tabela `seguranca_oportunidades`
--
ALTER TABLE `seguranca_oportunidades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `seguranca_oportunidade_unica` (`oportunidade_id`);

--
-- Índices de tabela `sessoes_usuario`
--
ALTER TABLE `sessoes_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessoes_usuario_fk` (`usuario_id`);

--
-- Índices de tabela `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitacoes_aluno_status` (`aluno_id`,`status`),
  ADD KEY `solicitacoes_escola_status` (`escola_id`,`status`),
  ADD KEY `solicitacoes_beneficio_fk` (`beneficio_id`),
  ADD KEY `solicitacoes_analisada_por_fk` (`analisada_por`);

--
-- Índices de tabela `solicitacoes_auxilio`
--
ALTER TABLE `solicitacoes_auxilio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitacoes_auxilio_aluno_data` (`user_id`,`requested_at`),
  ADD KEY `solicitacoes_auxilio_item_fk` (`item_id`),
  ADD KEY `solicitacoes_auxilio_revisor_fk` (`reviewed_by`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuarios_email_unico` (`email`),
  ADD KEY `usuarios_escola_perfil` (`escola_id`,`perfil_id`),
  ADD KEY `usuarios_perfil_fk` (`perfil_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `acessibilidade_oportunidades`
--
ALTER TABLE `acessibilidade_oportunidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `alertas`
--
ALTER TABLE `alertas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `alunos`
--
ALTER TABLE `alunos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `anexos_solicitacoes`
--
ALTER TABLE `anexos_solicitacoes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `arquivos_registro`
--
ALTER TABLE `arquivos_registro`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `assistentes`
--
ALTER TABLE `assistentes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `atendimentos`
--
ALTER TABLE `atendimentos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `auditoria_lgpd`
--
ALTER TABLE `auditoria_lgpd`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `beneficios`
--
ALTER TABLE `beneficios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `categorias_auxilio`
--
ALTER TABLE `categorias_auxilio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `categorias_beneficios`
--
ALTER TABLE `categorias_beneficios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `checkins`
--
ALTER TABLE `checkins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `comunicados`
--
ALTER TABLE `comunicados`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `consentimentos_lgpd`
--
ALTER TABLE `consentimentos_lgpd`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `encaminhamentos`
--
ALTER TABLE `encaminhamentos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `escolas`
--
ALTER TABLE `escolas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `itens_solidarios`
--
ALTER TABLE `itens_solidarios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `movimentacoes_auxilio`
--
ALTER TABLE `movimentacoes_auxilio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `notificacoes_solidarias`
--
ALTER TABLE `notificacoes_solidarias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `oportunidades`
--
ALTER TABLE `oportunidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `perfis`
--
ALTER TABLE `perfis`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `professores`
--
ALTER TABLE `professores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `respostas_diagnostico`
--
ALTER TABLE `respostas_diagnostico`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `seguranca_oportunidades`
--
ALTER TABLE `seguranca_oportunidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `acessibilidade_oportunidades`
--
ALTER TABLE `acessibilidade_oportunidades`
  ADD CONSTRAINT `acessibilidade_oportunidades_fk` FOREIGN KEY (`oportunidade_id`) REFERENCES `oportunidades` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `alertas`
--
ALTER TABLE `alertas`
  ADD CONSTRAINT `alertas_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `alertas_diagnostico_fk` FOREIGN KEY (`diagnostico_id`) REFERENCES `diagnosticos` (`id`),
  ADD CONSTRAINT `alertas_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `alunos_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `alunos_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `anexos_solicitacoes`
--
ALTER TABLE `anexos_solicitacoes`
  ADD CONSTRAINT `anexos_solicitacoes_fk` FOREIGN KEY (`solicitacao_id`) REFERENCES `solicitacoes` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `arquivos_registro`
--
ALTER TABLE `arquivos_registro`
  ADD CONSTRAINT `arquivos_registro_fk` FOREIGN KEY (`record_id`) REFERENCES `registros` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `assistentes`
--
ALTER TABLE `assistentes`
  ADD CONSTRAINT `assistentes_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `assistentes_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `atendimentos`
--
ALTER TABLE `atendimentos`
  ADD CONSTRAINT `atendimentos_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `atendimentos_assistente_fk` FOREIGN KEY (`assistente_id`) REFERENCES `assistentes` (`id`),
  ADD CONSTRAINT `atendimentos_criador_fk` FOREIGN KEY (`criado_por`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `atendimentos_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `auditoria_lgpd`
--
ALTER TABLE `auditoria_lgpd`
  ADD CONSTRAINT `auditoria_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `auditoria_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `beneficios`
--
ALTER TABLE `beneficios`
  ADD CONSTRAINT `beneficios_categoria_fk` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_beneficios` (`id`),
  ADD CONSTRAINT `beneficios_criador_fk` FOREIGN KEY (`criado_por`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `beneficios_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `checkins`
--
ALTER TABLE `checkins`
  ADD CONSTRAINT `checkins_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `checkins_professor_fk` FOREIGN KEY (`professor_id`) REFERENCES `professores` (`id`);

--
-- Restrições para tabelas `comunicados`
--
ALTER TABLE `comunicados`
  ADD CONSTRAINT `comunicados_autor_fk` FOREIGN KEY (`publicado_por`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `comunicados_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `consentimentos_lgpd`
--
ALTER TABLE `consentimentos_lgpd`
  ADD CONSTRAINT `consentimentos_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `diagnosticos`
--
ALTER TABLE `diagnosticos`
  ADD CONSTRAINT `diagnosticos_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `diagnosticos_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `diagnosticos_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `encaminhamentos`
--
ALTER TABLE `encaminhamentos`
  ADD CONSTRAINT `encaminhamentos_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `encaminhamentos_criador_fk` FOREIGN KEY (`criado_por`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `encaminhamentos_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `encerramentos_reuniao`
--
ALTER TABLE `encerramentos_reuniao`
  ADD CONSTRAINT `encerramentos_reuniao_reuniao_fk` FOREIGN KEY (`meeting_id`) REFERENCES `reunioes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `encerramentos_reuniao_usuario_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `itens_solidarios`
--
ALTER TABLE `itens_solidarios`
  ADD CONSTRAINT `itens_solidarios_categoria_fk` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_auxilio` (`id`),
  ADD CONSTRAINT `itens_solidarios_criador_fk` FOREIGN KEY (`criado_por`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `mensagens_canal_seguro`
--
ALTER TABLE `mensagens_canal_seguro`
  ADD CONSTRAINT `mensagens_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `mensagens_destinatario_fk` FOREIGN KEY (`destinatario_usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `mensagens_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `mensagens_remetente_fk` FOREIGN KEY (`remetente_usuario_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `movimentacoes_auxilio`
--
ALTER TABLE `movimentacoes_auxilio`
  ADD CONSTRAINT `movimentacoes_auxilio_item_fk` FOREIGN KEY (`item_id`) REFERENCES `itens_solidarios` (`id`),
  ADD CONSTRAINT `movimentacoes_auxilio_solicitacao_fk` FOREIGN KEY (`solicitacao_id`) REFERENCES `solicitacoes_auxilio` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `movimentacoes_auxilio_usuario_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `notificacoes_solidarias`
--
ALTER TABLE `notificacoes_solidarias`
  ADD CONSTRAINT `notificacoes_solidarias_usuario_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `oportunidades`
--
ALTER TABLE `oportunidades`
  ADD CONSTRAINT `oportunidades_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `participantes_reuniao`
--
ALTER TABLE `participantes_reuniao`
  ADD CONSTRAINT `participantes_reuniao_reuniao_fk` FOREIGN KEY (`meeting_id`) REFERENCES `reunioes` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `participantes_reuniao_usuario_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `professores`
--
ALTER TABLE `professores`
  ADD CONSTRAINT `professores_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `professores_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `registros`
--
ALTER TABLE `registros`
  ADD CONSTRAINT `registros_usuario_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `respostas_diagnostico`
--
ALTER TABLE `respostas_diagnostico`
  ADD CONSTRAINT `respostas_diagnostico_fk` FOREIGN KEY (`diagnostico_id`) REFERENCES `diagnosticos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `reunioes`
--
ALTER TABLE `reunioes`
  ADD CONSTRAINT `reunioes_criador_fk` FOREIGN KEY (`created_by`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `seguranca_oportunidades`
--
ALTER TABLE `seguranca_oportunidades`
  ADD CONSTRAINT `seguranca_oportunidades_fk` FOREIGN KEY (`oportunidade_id`) REFERENCES `oportunidades` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `sessoes_usuario`
--
ALTER TABLE `sessoes_usuario`
  ADD CONSTRAINT `sessoes_usuario_fk` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `solicitacoes`
--
ALTER TABLE `solicitacoes`
  ADD CONSTRAINT `solicitacoes_aluno_fk` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `solicitacoes_analisada_por_fk` FOREIGN KEY (`analisada_por`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `solicitacoes_beneficio_fk` FOREIGN KEY (`beneficio_id`) REFERENCES `beneficios` (`id`),
  ADD CONSTRAINT `solicitacoes_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`);

--
-- Restrições para tabelas `solicitacoes_auxilio`
--
ALTER TABLE `solicitacoes_auxilio`
  ADD CONSTRAINT `solicitacoes_auxilio_aluno_fk` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `solicitacoes_auxilio_item_fk` FOREIGN KEY (`item_id`) REFERENCES `itens_solidarios` (`id`),
  ADD CONSTRAINT `solicitacoes_auxilio_revisor_fk` FOREIGN KEY (`reviewed_by`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_escola_fk` FOREIGN KEY (`escola_id`) REFERENCES `escolas` (`id`),
  ADD CONSTRAINT `usuarios_perfil_fk` FOREIGN KEY (`perfil_id`) REFERENCES `perfis` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
