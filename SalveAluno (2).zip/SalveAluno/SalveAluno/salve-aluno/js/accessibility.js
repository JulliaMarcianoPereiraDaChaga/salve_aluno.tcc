(() => {
    const preferenceKey = 'salveAlunoAccessibilityPreferences';
    const defaults = {
        fontScale: 1,
        highContrast: false,
        invertedContrast: false,
        darkMode: false,
        lineSpacing: false,
        letterSpacing: false,
        emphasizeControls: false,
        dyslexiaFont: false,
        reducedMotion: false,
        largeCursor: false,
        focusHighlight: false
    };
    const message = 'Este site oferece recursos de tradução para Libras, leitura em áudio, alto contraste, ajuste de fonte e navegação por teclado. Escolha as opções que tornam sua experiência mais confortável.';
    let preferences = { ...defaults };
    let widgetLoaded = false;
    let speechChunks = [];
    let speechIndex = 0;
    let voices = [];

    const readPreferences = () => {
        try {
            const stored = JSON.parse(localStorage.getItem(preferenceKey) || '{}');
            if (stored && typeof stored === 'object' && !Array.isArray(stored)) {
                preferences = {
                    ...defaults,
                    ...Object.fromEntries(Object.keys(defaults)
                        .filter((key) => key in stored && key !== 'fontScale' && typeof stored[key] === 'boolean')
                        .map((key) => [key, stored[key]])),
                    fontScale: Number.isFinite(stored.fontScale)
                        ? Math.min(1.5, Math.max(0.8, stored.fontScale))
                        : defaults.fontScale
                };
            }
        } catch (error) {
            if (error instanceof SyntaxError) {
                try {
                    localStorage.removeItem(preferenceKey);
                } catch (storageError) {
                    console.error('Não foi possível remover preferências de acessibilidade inválidas.', storageError);
                }
            } else {
                console.error('Não foi possível ler preferências de acessibilidade.', error);
            }
        }
    };

    const persistPreferences = () => {
        try {
            localStorage.setItem(preferenceKey, JSON.stringify(preferences));
        } catch (error) {
            setStatus('Não foi possível salvar as preferências neste navegador.');
        }
    };

    const applyPreferences = () => {
        const root = document.documentElement;
        const body = document.body;
        root.style.setProperty('--access-font-scale', String(preferences.fontScale));
        [
            ['access-high-contrast', preferences.highContrast],
            ['access-inverted-contrast', preferences.invertedContrast],
            ['access-dark-mode', preferences.darkMode],
            ['access-line-spacing', preferences.lineSpacing],
            ['access-letter-spacing', preferences.letterSpacing],
            ['access-emphasize-controls', preferences.emphasizeControls],
            ['access-dyslexia-font', preferences.dyslexiaFont],
            ['access-reduced-motion', preferences.reducedMotion],
            ['access-large-cursor', preferences.largeCursor],
            ['access-focus-highlight', preferences.focusHighlight]
        ].forEach(([className, enabled]) => body.classList.toggle(className, Boolean(enabled)));
        document.querySelectorAll('[data-access-toggle]').forEach((button) => {
            button.setAttribute('aria-pressed', String(Boolean(preferences[button.dataset.accessToggle])));
        });
        const fontOutput = document.querySelector('#accessFontSize');
        if (fontOutput) fontOutput.textContent = `${Math.round(preferences.fontScale * 100)}%`;
    };

    const setStatus = (text) => {
        const status = document.querySelector('#accessibilityStatus');
        if (status) status.textContent = text;
    };

    const buildPanel = () => {
        const root = document.createElement('div');
        root.id = 'accessibilityWidget';
        root.innerHTML = `
            <a class="accessibility-skip-link" href="#accessibilityMainTarget">Pular para o conteúdo principal</a>
            <button type="button" class="accessibility-launcher" id="accessibilityLauncher" aria-expanded="false" aria-controls="accessibilityPanel">Acessibilidade em Libras</button>
            <section class="accessibility-panel" id="accessibilityPanel" aria-labelledby="accessibilityTitle" hidden>
                <header class="accessibility-panel-header">
                    <div><p class="accessibility-eyebrow">Salve Aluno</p><h2 id="accessibilityTitle">Opções de acessibilidade</h2></div>
                    <button type="button" class="accessibility-close" id="accessibilityClose" aria-label="Fechar opções de acessibilidade">×</button>
                </header>
                <p class="accessibility-intro">${message}</p>
                <p class="accessibility-help">Os ajustes visuais ficam salvos somente neste navegador. O intérprete Libras é carregado de um serviço externo apenas quando solicitado.</p>
                <div class="accessibility-group" aria-labelledby="accessibilityLibrasTitle">
                    <h3 id="accessibilityLibrasTitle">Acessibilidade em Libras</h3>
                    <button type="button" class="accessibility-action" id="accessibilityLibras">Ativar tradução em Libras</button>
                    <p class="accessibility-help">Abre o VLibras sob demanda. O avatar pode ser controlado no próprio widget; não há reprodução automática de áudio.</p>
                </div>
                <div class="accessibility-group" aria-labelledby="accessibilityAudioTitle">
                    <h3 id="accessibilityAudioTitle">Leitura em áudio</h3>
                    <div class="accessibility-button-row">
                        <button type="button" class="accessibility-action" id="accessibilityListen">Ouvir conteúdo</button>
                        <button type="button" id="accessibilityPause" disabled>Pausar</button>
                        <button type="button" id="accessibilityResume" disabled>Continuar</button>
                        <button type="button" id="accessibilityStop" disabled>Interromper</button>
                    </div>
                    <label class="accessibility-control-label" for="accessibilityRate">Velocidade da fala</label>
                    <select id="accessibilityRate">
                        <option value="0.8">Lenta</option><option value="1" selected>Normal</option><option value="1.2">Rápida</option>
                    </select>
                    <p class="accessibility-help">Leia a página em português do Brasil ou selecione um trecho e pressione “Ouvir conteúdo”.</p>
                </div>
                <div class="accessibility-group" aria-labelledby="accessibilityVisualTitle">
                    <h3 id="accessibilityVisualTitle">Opções de acessibilidade visual</h3>
                    <div class="accessibility-button-row">
                        <button type="button" id="accessibilityFontDown" aria-label="Reduzir tamanho da fonte">A−</button>
                        <output id="accessFontSize" aria-live="polite">100%</output>
                        <button type="button" id="accessibilityFontUp" aria-label="Aumentar tamanho da fonte">A+</button>
                        <button type="button" id="accessibilityReset" class="accessibility-action">Restaurar fonte</button>
                    </div>
                    <div class="accessibility-toggle-list">
                        <button type="button" data-access-toggle="highContrast" aria-pressed="false">Alto contraste</button>
                        <button type="button" data-access-toggle="invertedContrast" aria-pressed="false">Contraste invertido</button>
                        <button type="button" data-access-toggle="darkMode" aria-pressed="false">Modo escuro</button>
                        <button type="button" data-access-toggle="lineSpacing" aria-pressed="false">Aumentar espaçamento entre linhas</button>
                        <button type="button" data-access-toggle="letterSpacing" aria-pressed="false">Aumentar espaçamento entre letras</button>
                        <button type="button" data-access-toggle="emphasizeControls" aria-pressed="false">Destacar links e botões</button>
                        <button type="button" data-access-toggle="dyslexiaFont" aria-pressed="false">Fonte mais legível</button>
                        <button type="button" data-access-toggle="reducedMotion" aria-pressed="false">Reduzir animações</button>
                        <button type="button" data-access-toggle="largeCursor" aria-pressed="false">Aumentar cursor</button>
                        <button type="button" data-access-toggle="focusHighlight" aria-pressed="false">Destacar foco</button>
                    </div>
                    <button type="button" class="accessibility-reset-all" id="accessibilityResetAll">Restaurar todas as configurações padrão</button>
                </div>
                <details class="accessibility-guides">
                    <summary>Guias rápidos em texto</summary>
                    <p><strong>Como fazer login:</strong> escolha seu perfil, informe e-mail e senha e acione “Entrar no painel”.</p>
                    <p><strong>Como solicitar apoio:</strong> no painel do aluno, abra “Solicitações”, preencha o formulário e confira a mensagem de confirmação.</p>
                    <p><strong>Como usar o Banco Solidário:</strong> abra “Banco Solidário”, pesquise ou filtre os itens e siga as instruções para enviar uma solicitação.</p>
                    <p><strong>Como responder ao diagnóstico:</strong> abra “Diagnóstico inteligente”, responda aos campos e envie as respostas para consultar as orientações.</p>
                    <p><strong>Como falar com a equipe:</strong> use “Canal seguro” no painel ou “Falar com a equipe” na página inicial.</p>
                    <p><strong>Como cadastrar uma escola:</strong> solicite o cadastro pelo canal oficial da equipe; a área administrativa pode criar contas de gestão escolar.</p>
                    <p><strong>Como encontrar cursos e Jovem Aprendiz:</strong> abra “Oportunidades” no painel do aluno, pesquise e use os filtros. Confirme dados e prazos com a organização.</p>
                    <p>Estes guias textuais podem ser lidos em áudio e traduzidos pelo VLibras quando você ativar o serviço externo. Vídeos em Libras específicos não estão incluídos porque não foram fornecidos materiais verificados.</p>
                </details>
                <p class="accessibility-state" id="accessibilityStatus" role="status" aria-live="polite"></p>
            </section>
            <div class="accessibility-vlibras" id="accessibilityVlibras" hidden>
                <div vw class="enabled">
                    <div vw-access-button class="active" aria-label="Abrir controles do intérprete VLibras"></div>
                    <div vw-plugin-wrapper><div class="vw-plugin-top-wrapper"></div></div>
                </div>
            </div>`;
        document.body.prepend(root);
        const main = document.querySelector('main');
        if (main) {
            if (!main.id) main.id = 'accessibilityMainTarget';
            main.tabIndex = -1;
            root.querySelector('.accessibility-skip-link').href = `#${main.id}`;
        } else {
            root.querySelector('.accessibility-skip-link').remove();
        }
    };

    const loadVlibras = () => {
        const button = document.querySelector('#accessibilityLibras');
        const mount = document.querySelector('#accessibilityVlibras');
        if (widgetLoaded) {
            mount.hidden = false;
            setStatus('Intérprete Libras ativado. Use os controles do VLibras para iniciar ou pausar a tradução.');
            button.textContent = 'Fechar intérprete Libras';
            button.setAttribute('aria-pressed', 'true');
            return;
        }
        button.disabled = true;
        button.textContent = 'Carregando VLibras...';
        setStatus('Conectando ao serviço externo VLibras. A tradução depende de conexão com a internet.');
        mount.hidden = false;
        const script = document.createElement('script');
        script.src = 'https://vlibras.gov.br/app/vlibras-plugin.js';
        script.async = true;
        script.onload = () => {
            if (!window.VLibras?.Widget) {
                button.disabled = false;
                button.textContent = 'Tentar ativar Libras novamente';
                setStatus('O serviço VLibras foi carregado, mas não pôde ser inicializado.');
                return;
            }
            new window.VLibras.Widget('https://vlibras.gov.br/app');
            widgetLoaded = true;
            button.disabled = false;
            button.textContent = 'Fechar intérprete Libras';
            button.setAttribute('aria-pressed', 'true');
            setStatus('VLibras ativado. Os controles do widget permitem operar o avatar; use o botão de acesso para abrir a tradução.');
            mount.querySelector('[vw-access-button]')?.click();
        };
        script.onerror = () => {
            mount.hidden = true;
            button.disabled = false;
            button.textContent = 'Tentar ativar Libras novamente';
            setStatus('Não foi possível carregar o serviço externo VLibras. Verifique a conexão e tente novamente.');
        };
        document.head.append(script);
    };

    const collectSpeechChunks = () => {
        const selection = window.getSelection()?.toString().trim();
        if (selection) return [{ text: selection, element: null }];
        const content = document.querySelector('main') || document.body;
        return [...content.querySelectorAll('h1, h2, h3, h4, p, legend, label, li, summary, button, a')]
            .filter((element) => {
                if (element.closest('#accessibilityWidget, [hidden], [aria-hidden="true"]')) return false;
                return element.getClientRects().length > 0 && element.textContent.trim().length > 0;
            })
            .map((element) => ({ text: element.textContent.replace(/\s+/g, ' ').trim(), element }));
    };

    const updateSpeechControls = (active) => {
        document.querySelector('#accessibilityPause').disabled = !active;
        document.querySelector('#accessibilityResume').disabled = !active;
        document.querySelector('#accessibilityStop').disabled = !active;
    };

    const speakNext = () => {
        if (speechIndex >= speechChunks.length) {
            document.querySelector('#accessibilityListen').textContent = 'Ouvir conteúdo';
            updateSpeechControls(false);
            setStatus('Leitura em áudio concluída.');
            return;
        }
        const chunk = speechChunks[speechIndex];
        const utterance = new SpeechSynthesisUtterance(chunk.text);
        utterance.lang = 'pt-BR';
        utterance.rate = Number(document.querySelector('#accessibilityRate').value);
        const voice = voices.find((candidate) => candidate.lang.toLowerCase() === 'pt-br');
        if (voice) utterance.voice = voice;
        utterance.onstart = () => {
            document.querySelectorAll('.accessibility-reading-highlight').forEach((element) => element.classList.remove('accessibility-reading-highlight'));
            if (chunk.element) {
                chunk.element.classList.add('accessibility-reading-highlight');
                chunk.element.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            }
        };
        utterance.onend = () => {
            speechIndex += 1;
            speakNext();
        };
        utterance.onerror = (event) => {
            if (event.error === 'canceled' || event.error === 'interrupted') return;
            stopSpeech('Não foi possível continuar a leitura em áudio neste navegador.');
        };
        window.speechSynthesis.speak(utterance);
    };

    const startSpeech = () => {
        if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
            setStatus('A leitura em áudio não é compatível com este navegador.');
            return;
        }
        speechChunks = collectSpeechChunks();
        speechIndex = 0;
        if (!speechChunks.length) {
            setStatus('Selecione um trecho de texto ou abra uma página com conteúdo para leitura.');
            return;
        }
        window.speechSynthesis.cancel();
        document.querySelector('#accessibilityListen').textContent = 'Leitura ativa';
        updateSpeechControls(true);
        setStatus('Leitura em áudio ativa em português. Use pausar, continuar ou interromper.');
        speakNext();
    };

    const stopSpeech = (statusText = 'Leitura em áudio interrompida.') => {
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        document.querySelectorAll('.accessibility-reading-highlight').forEach((element) => element.classList.remove('accessibility-reading-highlight'));
        document.querySelector('#accessibilityListen').textContent = 'Ouvir conteúdo';
        updateSpeechControls(false);
        setStatus(statusText);
    };

    const bindEvents = () => {
        const launcher = document.querySelector('#accessibilityLauncher');
        const panel = document.querySelector('#accessibilityPanel');
        const closePanel = () => {
            panel.hidden = true;
            launcher.setAttribute('aria-expanded', 'false');
            launcher.focus();
        };
        launcher.addEventListener('click', () => {
            panel.hidden = !panel.hidden;
            launcher.setAttribute('aria-expanded', String(!panel.hidden));
            if (!panel.hidden) panel.querySelector('button')?.focus();
        });
        document.querySelector('#accessibilityClose').addEventListener('click', closePanel);
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && !panel.hidden) closePanel();
        });
        document.querySelector('#accessibilityLibras').addEventListener('click', (event) => {
            if (widgetLoaded) {
                document.querySelector('#accessibilityVlibras').hidden = true;
                event.currentTarget.textContent = 'Ativar tradução em Libras';
                event.currentTarget.setAttribute('aria-pressed', 'false');
                setStatus('Janela do intérprete Libras fechada.');
                return;
            }
            loadVlibras();
        });
        document.querySelector('#accessibilityListen').addEventListener('click', startSpeech);
        document.querySelector('#accessibilityPause').addEventListener('click', () => {
            window.speechSynthesis.pause();
            setStatus('Leitura em áudio pausada.');
        });
        document.querySelector('#accessibilityResume').addEventListener('click', () => {
            window.speechSynthesis.resume();
            setStatus('Leitura em áudio em andamento.');
        });
        document.querySelector('#accessibilityStop').addEventListener('click', () => stopSpeech());
        document.querySelectorAll('[data-access-toggle]').forEach((button) => {
            button.addEventListener('click', () => {
                const key = button.dataset.accessToggle;
                preferences[key] = !preferences[key];
                if (key === 'highContrast') preferences.invertedContrast = false;
                if (key === 'invertedContrast') preferences.highContrast = false;
                persistPreferences();
                applyPreferences();
                setStatus(`${button.textContent} ${preferences[key] ? 'ativado' : 'desativado'}.`);
            });
        });
        document.querySelector('#accessibilityFontUp').addEventListener('click', () => {
            preferences.fontScale = Math.min(1.5, Math.round((preferences.fontScale + 0.1) * 10) / 10);
            persistPreferences();
            applyPreferences();
            setStatus('Tamanho da fonte aumentado.');
        });
        document.querySelector('#accessibilityFontDown').addEventListener('click', () => {
            preferences.fontScale = Math.max(0.8, Math.round((preferences.fontScale - 0.1) * 10) / 10);
            persistPreferences();
            applyPreferences();
            setStatus('Tamanho da fonte reduzido.');
        });
        document.querySelector('#accessibilityReset').addEventListener('click', () => {
            preferences.fontScale = defaults.fontScale;
            persistPreferences();
            applyPreferences();
            setStatus('Tamanho padrão da fonte restaurado.');
        });
        document.querySelector('#accessibilityResetAll').addEventListener('click', () => {
            preferences = { ...defaults };
            persistPreferences();
            applyPreferences();
            setStatus('Todas as configurações visuais foram restauradas.');
        });
        document.addEventListener('focusin', (event) => {
            if (event.target.matches('input, select, textarea, button, a, [tabindex]:not([tabindex="-1"])')) {
                event.target.setAttribute('data-keyboard-focus', '');
            }
        });
        document.addEventListener('focusout', (event) => event.target.removeAttribute('data-keyboard-focus'));
        document.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach((field) => {
            if (field.hasAttribute('required')) field.setAttribute('aria-required', 'true');
            if (field.labels?.length || field.hasAttribute('aria-label') || field.hasAttribute('aria-labelledby')) return;
            const label = field.getAttribute('placeholder') || field.getAttribute('name') || field.id;
            if (label) field.setAttribute('aria-label', label.replace(/[_-]+/g, ' '));
        });
    };

    document.addEventListener('DOMContentLoaded', () => {
        readPreferences();
        buildPanel();
        applyPreferences();
        bindEvents();
        if ('speechSynthesis' in window) {
            voices = window.speechSynthesis.getVoices();
            window.speechSynthesis.addEventListener('voiceschanged', () => { voices = window.speechSynthesis.getVoices(); });
        }
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            document.body.classList.add('access-system-reduced-motion');
        }
    });
})();
