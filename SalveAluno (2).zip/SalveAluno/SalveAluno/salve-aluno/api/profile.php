<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

$db = api_db();
$user = api_user($db);

// Processa a leitura do perfil (Método GET)
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    api_json([
        'profile' => [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'details' => json_decode($user['details_json'], true) ?: []
        ]
    ]);
}

// Processa a atualização do perfil (Método POST/Outros)
api_csrf();

$data = api_input();
$name = trim((string)($data['name'] ?? ''));
$phone = trim((string)($data['phone'] ?? ''));

if ($name === '') {
    api_json(['error' => 'Informe o nome.'], 422);
}

$q = $db->prepare('UPDATE users SET name=:name,phone=:phone WHERE id=:id');
$q->execute([
    ':name' => $name,
    ':phone' => $phone,
    ':id' => $user['id']
]);

api_json([
    'ok' => true,
    'name' => $name,
    'phone' => $phone
]);

