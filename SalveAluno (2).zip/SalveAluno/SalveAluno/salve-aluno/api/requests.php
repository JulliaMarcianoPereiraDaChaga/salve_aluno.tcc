<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

$db = api_db();
$user = api_user($db);

// Processa a listagem de requisições (Método GET)
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $q = $db->prepare("SELECT id,type,data_json,created_at FROM records WHERE user_id=:id AND type='student_request' ORDER BY created_at DESC LIMIT 100");
    $q->execute([':id' => $user['id']]);
    
    $rows = array_map(fn($r) => [
        'id' => $r['id'],
        'data' => json_decode($r['data_json'], true) ?: [],
        'createdAt' => $r['created_at']
    ], $q->fetchAll());
    
    api_json(['requests' => $rows]);
}

// Processa a criação de uma nova requisição (Método POST/Outros)
api_csrf();

$d = api_input();
$id = bin2hex(random_bytes(16));

$payload = json_encode([
    'category' => trim((string)($d['category'] ?? '')),
    'description' => trim((string)($d['description'] ?? '')),
    'preferredDate' => (string)($d['preferredDate'] ?? '')
], JSON_UNESCAPED_UNICODE);

if (json_decode($payload, true)['category'] === '') {
    api_json(['error' => 'Informe a categoria.'], 422);
}

$q = $db->prepare("INSERT INTO records(id,user_id,type,data_json,created_at) VALUES(:id,:uid,'student_request',:data,:created)");
$q->execute([
    ':id' => $id,
    ':uid' => $user['id'],
    ':data' => $payload,
    ':created' => gmdate('c')
]);

api_json(['ok' => true, 'id' => $id], 201);
