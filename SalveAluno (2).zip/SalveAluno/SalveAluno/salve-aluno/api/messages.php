<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

$db = api_db();
$user = api_user($db);

// Processa a listagem de mensagens (Método GET)
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $q = $db->prepare('SELECT id,message,sent_at,read_at FROM secure_messages WHERE sender_user_id=:id ORDER BY sent_at DESC LIMIT 100');
    $q->execute([':id' => $user['id']]);
    
    api_json(['messages' => $q->fetchAll()]);
}

// Processa o envio de uma nova mensagem (Método POST/Outros)
api_csrf();

$d = api_input();
$message = trim((string)($d['message'] ?? ''));

if ($message === '') {
    api_json(['error' => 'Digite uma mensagem.'], 422);
}

$id = bin2hex(random_bytes(16));

$q = $db->prepare('INSERT INTO secure_messages(id,school_key,sender_user_id,source,sender_name,student_name,anonymous,message,sent_at) VALUES(:id,:school,:uid,:source,:name,:student,:anonymous,:message,:sent)');
$q->execute([
    ':id' => $id,
    ':school' => $user['school_key'],
    ':uid' => $user['id'],
    ':source' => 'student',
    ':name' => $user['name'],
    ':student' => $user['name'],
    ':anonymous' => (int)($d['anonymous'] ?? false),
    ':message' => $message,
    ':sent' => gmdate('c')
]);

api_json(['ok' => true, 'id' => $id], 201);

