<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    api_json(['error' => 'Método não permitido.'], 405);
}

api_json([
    'app' => 'salve-aluno',
    'status' => 'ok',
    'time' => gmdate('c'),
    'apis' => 9
]);
