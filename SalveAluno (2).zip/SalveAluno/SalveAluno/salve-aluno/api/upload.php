<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

api_user(api_db());

api_json([
    'ok' => true,
    'message' => 'Endpoint de upload ativo. Os anexos são aceitos pela API principal em record-create.'
]);
