<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

api_user(api_db());

api_json([
    'benefits' => [
        [
            'id' => 'transport',
            'name' => 'Auxílio transporte',
            'status' => 'available'
        ],
        [
            'id' => 'food',
            'name' => 'Auxílio alimentação',
            'status' => 'available'
        ],
        [
            'id' => 'notebook',
            'name' => 'Empréstimo de notebook',
            'status' => 'available'
        ]
    ]
]);
