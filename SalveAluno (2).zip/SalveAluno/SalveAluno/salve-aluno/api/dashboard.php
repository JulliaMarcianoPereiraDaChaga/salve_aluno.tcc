<?php

declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

api_session();

$db = api_db();
$user = api_user($db);

$q = $db->prepare('SELECT COUNT(*) FROM records WHERE user_id=:id');
$q->execute([':id' => $user['id']]);

api_json([
    'user' => [
        'name' => $user['name'],
        'profile' => $user['profile']
    ],
    'metrics' => [
        'records' => (int)$q->fetchColumn(),
        'notifications' => 0
    ]
]);
