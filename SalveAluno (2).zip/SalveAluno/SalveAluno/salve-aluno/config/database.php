<?php
declare(strict_types=1);

/**
 * Configuração do MySQL do Salve Aluno.
 * Em produção, defina SALVE_DB_HOST, SALVE_DB_NAME, SALVE_DB_USER e SALVE_DB_PASSWORD.
 */
function databaseConfig(): array
{
    static $config;
    if ($config !== null) {
        return $config;
    }

    $config = [
        'host' => getenv('SALVE_DB_HOST') ?: '127.0.0.1',
        'name' => getenv('SALVE_DB_NAME') ?: 'salve_aluno_apoio',
        'user' => getenv('SALVE_DB_USER') ?: 'root',
        'password' => getenv('SALVE_DB_PASSWORD') ?: '',
    ];

    return $config;
}