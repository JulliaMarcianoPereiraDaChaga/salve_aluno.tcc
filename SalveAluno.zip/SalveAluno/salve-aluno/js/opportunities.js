(() => {
    const categories = [
        { id: 'curso', name: 'Cursos', color: '#8b5cf6', icon: '📚' },
        { id: 'emprego', name: 'Empregos', color: '#10b981', icon: '💼' },
        { id: 'biblioteca', name: 'Bibliotecas', color: '#3b82f6', icon: '📖' },
        { id: 'servico', name: 'Serviços', color: '#f59e0b', icon: '🏛️' },
        { id: 'evento', name: 'Eventos', color: '#ec4899', icon: '🎯' }
    ];
    const origin = { lat: -23.5505, lng: -46.6333 };
    const dateAfterDays = (days) => {
        const date = new Date();
        date.setDate(date.getDate() + days);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    };
    const opportunities = [
        {
            id: 'demo-curso-tecnologia', category: 'curso', title: 'Curso de tecnologia básica',
            description: 'Exemplo de curso gratuito de introdução à tecnologia, com atividades práticas em laboratório.',
            address: 'Rua das Flores, 123 — endereço demonstrativo', lat: -23.5442, lng: -46.6382,
            hours: 'Seg-Sex: 8h-19h', openDays: [1, 2, 3, 4, 5], opensAt: '08:00', closesAt: '19:00',
            vacancies: 20, deadline: dateAfterDays(2), signupOpen: true, urgency: 'high',
            free: true, scholarship: false, foodIncluded: true, transportIncluded: false,
            schoolRoute: true, outsideClass: true, accessible: true, visitsPerWeek: 2, tags: ['tecnologia', 'gratuito']
        },
        {
            id: 'demo-emprego-aprendiz', category: 'emprego', title: 'Jovem Aprendiz — apoio administrativo',
            description: 'Exemplo de oportunidade de aprendizagem com atividades acompanhadas e bolsa-auxílio.',
            address: 'Avenida Central, 245 — endereço demonstrativo', lat: -23.5563, lng: -46.6278,
            hours: 'Seg-Qui: 13h-17h', openDays: [1, 2, 3, 4], opensAt: '13:00', closesAt: '17:00',
            vacancies: 3, deadline: dateAfterDays(9), signupOpen: true, urgency: 'high',
            free: true, scholarship: false, foodIncluded: false, transportIncluded: true,
            schoolRoute: false, outsideClass: true, accessible: true, visitsPerWeek: 5, tags: ['renda', 'aprendiz']
        },
        {
            id: 'demo-biblioteca-municipal', category: 'biblioteca', title: 'Biblioteca Municipal',
            description: 'Exemplo de biblioteca com espaço de estudo, empréstimo de livros e acesso à internet.',
            address: 'Praça da Leitura, 40 — endereço demonstrativo', lat: -23.5471, lng: -46.6259,
            hours: 'Seg-Sáb: 9h-18h', openDays: [1, 2, 3, 4, 5, 6], opensAt: '09:00', closesAt: '18:00',
            vacancies: null, deadline: null, signupOpen: false, urgency: 'normal',
            free: true, scholarship: false, foodIncluded: false, transportIncluded: false,
            schoolRoute: true, outsideClass: true, accessible: true, visitsPerWeek: 3, tags: ['estudo', 'internet']
        },
        {
            id: 'demo-servico-estudante', category: 'servico', title: 'Centro de Atendimento ao Estudante',
            description: 'Exemplo de serviço público de orientação sobre documentos e programas de apoio estudantil.',
            address: 'Rua da Cidadania, 80 — endereço demonstrativo', lat: -23.5592, lng: -46.6401,
            hours: 'Seg-Sex: 9h-16h', openDays: [1, 2, 3, 4, 5], opensAt: '09:00', closesAt: '16:00',
            vacancies: null, deadline: null, signupOpen: true, urgency: 'normal',
            free: true, scholarship: false, foodIncluded: false, transportIncluded: false,
            schoolRoute: false, outsideClass: true, accessible: true, visitsPerWeek: 1, tags: ['serviço público']
        },
        {
            id: 'demo-event-profissoes', category: 'evento', title: 'Feira de profissões e inclusão',
            description: 'Exemplo de evento gratuito para conhecer cursos, profissões e oportunidades de formação.',
            address: 'Centro Comunitário — endereço demonstrativo', lat: -23.5415, lng: -46.6264,
            hours: 'Sábado: 10h-16h', openDays: [6], opensAt: '10:00', closesAt: '16:00',
            vacancies: 45, deadline: dateAfterDays(12), signupOpen: true, urgency: 'normal',
            free: true, scholarship: false, foodIncluded: true, transportIncluded: false,
            schoolRoute: true, outsideClass: true, accessible: true, visitsPerWeek: 1, tags: ['carreira', 'inclusão']
        },
        {
            id: 'demo-curso-reforco', category: 'curso', title: 'Reforço escolar e preparação para vestibular',
            description: 'Exemplo de turma de apoio gratuito em matemática, leitura e preparação para provas.',
            address: 'Espaço Aprender — endereço demonstrativo', lat: -23.563, lng: -46.6192,
            hours: 'Ter-Qui: 14h-18h', openDays: [2, 3, 4], opensAt: '14:00', closesAt: '18:00',
            vacancies: 8, deadline: dateAfterDays(6), signupOpen: true, urgency: 'normal',
            free: true, scholarship: false, foodIncluded: false, transportIncluded: false,
            schoolRoute: false, outsideClass: true, accessible: true, visitsPerWeek: 2, tags: ['estudo', 'vestibular']
        },
        {
            id: 'demo-emprego-estagio', category: 'emprego', title: 'Estágio de apoio em biblioteca',
            description: 'Exemplo de estágio de meio período com bolsa e acompanhamento de equipe.',
            address: 'Biblioteca do Bairro — endereço demonstrativo', lat: -23.5358, lng: -46.6431,
            hours: 'Seg-Sex: 13h-17h', openDays: [1, 2, 3, 4, 5], opensAt: '13:00', closesAt: '17:00',
            vacancies: 2, deadline: dateAfterDays(14), signupOpen: true, urgency: 'normal',
            free: true, scholarship: true, foodIncluded: false, transportIncluded: true,
            schoolRoute: true, outsideClass: true, accessible: true, visitsPerWeek: 5, tags: ['renda', 'cultura']
        },
        {
            id: 'demo-servico-internet', category: 'servico', title: 'Ponto público de acesso à internet',
            description: 'Exemplo de espaço público com computadores para estudo e apoio digital.',
            address: 'Praça do Conecta — endereço demonstrativo', lat: -23.5534, lng: -46.6157,
            hours: 'Seg-Sex: 8h-17h', openDays: [1, 2, 3, 4, 5], opensAt: '08:00', closesAt: '17:00',
            vacancies: null, deadline: null, signupOpen: false, urgency: 'normal',
            free: true, scholarship: false, foodIncluded: false, transportIncluded: false,
            schoolRoute: true, outsideClass: true, accessible: true, visitsPerWeek: 2, tags: ['tecnologia', 'internet']
        }
    ];
    const storageKeys = {
        saved: 'salveAlunoOpportunitySaved',
        reviews: 'salveAlunoOpportunityReviews',
        reports: 'salveAlunoOpportunityReports'
    };

    const $ = (selector) => document.querySelector(selector);
    const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[character]));
    const formatDate = (value) => value
        ? new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'long' }).format(new Date(`${value}T12:00:00`))
        : 'Sem prazo informado';
    const distanceBetween = (first, second) => {
        const toRadians = (degrees) => degrees * Math.PI / 180;
        const latitudeDelta = toRadians(second.lat - first.lat);
        const longitudeDelta = toRadians(second.lng - first.lng);
        const a = Math.sin(latitudeDelta / 2) ** 2 +
            Math.cos(toRadians(first.lat)) * Math.cos(toRadians(second.lat)) *
            Math.sin(longitudeDelta / 2) ** 2;
        return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    let map;
    let markerLayer;
    let locationPosition = null;
    let selectedOpportunity = null;
    let savedOnly = false;
    let incognito = false;
    let saved = [];
    let reviews = {};
    let reports = [];

    const setMessage = (message) => {
        const hint = $('#opportunityStatus');
        if (hint) hint.textContent = message;
    };
    const readStoredArray = (key, fallback, description) => {
        try {
            const value = localStorage.getItem(key);
            if (!value) return fallback;
            const parsed = JSON.parse(value);
            if (!Array.isArray(parsed)) throw new Error('formato de dados inválido');
            return parsed;
        } catch (error) {
            setMessage(`Não foi possível carregar ${description}: ${error.message}.`);
            return fallback;
        }
    };
    const readStoredObject = (key, fallback, description) => {
        try {
            const value = localStorage.getItem(key);
            if (!value) return fallback;
            const parsed = JSON.parse(value);
            if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
                throw new Error('formato de dados inválido');
            }
            return parsed;
        } catch (error) {
            setMessage(`Não foi possível carregar ${description}: ${error.message}.`);
            return fallback;
        }
    };
    const storeValue = (key, value, description) => {
        if (incognito) return true;
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            setMessage(`Não foi possível salvar ${description}: ${error.message}.`);
            return false;
        }
    };

    const categoryFor = (id) => categories.find((category) => category.id === id);
    const currentDistance = (item) => locationPosition ? distanceBetween(locationPosition, item) : null;
    const monthlyTransitCost = (item) => {
        if (item.transportIncluded) return 0;
        const rawFare = $('#opportunityTransitFare')?.value.trim();
        if (!rawFare) return null;
        const fare = Number(rawFare);
        if (!Number.isFinite(fare) || fare < 0) return null;
        return fare * 2 * item.visitsPerWeek * 4.33;
    };
    const itemIsOpen = (item) => {
        const now = new Date();
        const day = now.getDay();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        return item.openDays.includes(day) && currentTime >= item.opensAt && currentTime < item.closesAt;
    };
    const daysUntil = (date) => {
        if (!date) return null;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const deadline = new Date(`${date}T00:00:00`);
        return Math.round((deadline - today) / 86400000);
    };

    const buildCategoryFilters = () => {
        const container = $('#opportunityCategoryFilters');
        if (!container) return;
        container.replaceChildren();
        categories.forEach((category) => {
            const label = document.createElement('label');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.name = 'opportunityCategory';
            input.value = category.id;
            input.checked = true;
            const icon = document.createElement('span');
            icon.className = 'opportunity-category-icon';
            icon.textContent = category.icon;
            const name = document.createElement('span');
            name.className = 'opportunity-category-name';
            name.textContent = category.name;
            const count = document.createElement('small');
            count.textContent = String(opportunities.filter((item) => item.category === category.id).length);
            label.append(input, icon, name, count);
            container.appendChild(label);
        });
    };

    const reviewSummary = (itemId) => {
        const entries = Array.isArray(reviews[itemId]) ? reviews[itemId] : [];
        if (!entries.length) return { count: 0, average: 0 };
        return {
            count: entries.length,
            average: entries.reduce((sum, entry) => sum + Number(entry.rating || 0), 0) / entries.length
        };
    };
    const selectedCategories = () => [...document.querySelectorAll('input[name="opportunityCategory"]:checked')]
        .map((input) => input.value);
    const filteredOpportunities = () => {
        const searchTerm = ($('#opportunitySearch')?.value || '').trim().toLocaleLowerCase('pt-BR');
        const radius = Number(document.querySelector('input[name="opportunityRadius"]:checked')?.value || 1);
        const radiusEnabled = Boolean(locationPosition);
        const budgetEnabled = $('#opportunityTransitFits')?.checked;
        const budget = Number($('#opportunityTransitBudget')?.value);
        const categoriesSelected = selectedCategories();
        if (budgetEnabled && (!Number.isFinite(budget) || budget <= 0 ||
            $('#opportunityTransitFare')?.value.trim() === '' ||
            !Number.isFinite(Number($('#opportunityTransitFare')?.value)) ||
            Number($('#opportunityTransitFare')?.value) < 0)) {
            setMessage('Informe o saldo mensal e a tarifa por trecho para filtrar pelo vale-transporte.');
            return [];
        }
        return opportunities.filter((item) => {
            const category = categoryFor(item.category);
            const searchable = `${item.title} ${item.description} ${item.address} ${category?.name || ''}`.toLocaleLowerCase('pt-BR');
            if (!categoriesSelected.includes(item.category) || (searchTerm && !searchable.includes(searchTerm))) return false;
            if ($('#opportunityOpenNow')?.checked && !itemIsOpen(item)) return false;
            if ($('#opportunityRegistrationOpen')?.checked && !item.signupOpen) return false;
            if ($('#opportunityHasVacancies')?.checked && !(item.vacancies > 0)) return false;
            if ($('#opportunityNearSchool')?.checked && !item.schoolRoute) return false;
            if ($('#opportunityTransitIncluded')?.checked && !item.transportIncluded) return false;
            if ($('#opportunityOutsideClass')?.checked && !item.outsideClass) return false;
            if ($('#opportunityFreeOnly')?.checked && !(item.free || item.scholarship)) return false;
            if (radiusEnabled && currentDistance(item) > radius) return false;
            if (budgetEnabled) {
                const monthlyCost = monthlyTransitCost(item);
                if (monthlyCost === null || monthlyCost > budget) return false;
            }
            if (savedOnly && !saved.includes(item.id)) return false;
            return true;
        });
    };

    const createElement = (tag, className, text) => {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (text !== undefined) element.textContent = text;
        return element;
    };
    const routeUrl = (item) => `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${item.lat},${item.lng}`)}`;
    const buildOpportunityCard = (item) => {
        const category = categoryFor(item.category);
        const card = createElement('article', 'opportunity-card');
        card.dataset.opportunityId = item.id;
        const top = createElement('div', 'opportunity-card-top');
        const categoryBadge = createElement('span', 'opportunity-card-category', `${category.icon} ${category.name}`);
        categoryBadge.style.setProperty('--category-color', category.color);
        top.appendChild(categoryBadge);
        const urgency = item.urgency === 'high'
            ? createElement('span', 'opportunity-urgency', 'Vagas limitadas')
            : createElement('span', 'opportunity-example-label', 'Exemplo');
        top.appendChild(urgency);
        const title = createElement('h3', '', item.title);
        const description = createElement('p', 'opportunity-card-description', item.description);
        const location = createElement('p', 'opportunity-card-location', item.address);
        const distance = currentDistance(item);
        const distanceLabel = distance === null ? 'Distância disponível após compartilhar localização' :
            `${distance < 1 ? `${Math.round(distance * 1000)} m` : `${distance.toFixed(1).replace('.', ',')} km`} em linha reta`;
        const meta = createElement('div', 'opportunity-card-meta');
        [item.hours, distanceLabel, item.deadline ? `Inscrições até ${formatDate(item.deadline)}` : 'Prazo não informado',
            item.vacancies > 0 ? `${item.vacancies} vagas demonstrativas` : 'Sem vagas informadas']
            .forEach((value) => meta.appendChild(createElement('span', '', value)));
        const inclusions = createElement('div', 'opportunity-inclusions');
        if (item.free || item.scholarship) inclusions.appendChild(createElement('span', 'opportunity-inclusion', item.free ? 'Gratuito' : 'Com bolsa'));
        if (item.foodIncluded) inclusions.appendChild(createElement('span', 'opportunity-inclusion', 'Alimentação incluída'));
        if (item.transportIncluded) inclusions.appendChild(createElement('span', 'opportunity-inclusion', 'Transporte incluído'));
        if (item.accessible) inclusions.appendChild(createElement('span', 'opportunity-inclusion', 'Acessível'));
        const monthlyCost = monthlyTransitCost(item);
        if (monthlyCost !== null && !item.transportIncluded) {
            inclusions.appendChild(createElement('span', 'opportunity-inclusion', `Transporte estimado: R$ ${monthlyCost.toFixed(2).replace('.', ',')}/mês`));
        }
        const review = reviewSummary(item.id);
        const rating = createElement('p', 'opportunity-rating');
        rating.textContent = review.count
            ? `★ ${review.average.toFixed(1).replace('.', ',')} · ${review.count} avaliação(ões) neste navegador${review.count >= 3 && review.average >= 4.5 ? ' · Bem avaliado' : ''}`
            : 'Ainda sem avaliações neste navegador';
        const actions = createElement('div', 'opportunity-card-actions');
        const details = createElement('button', 'button button-light', 'Ver detalhes');
        details.type = 'button';
        details.dataset.opportunityAction = 'details';
        const save = createElement('button', 'button button-light', saved.includes(item.id) ? 'Salvo' : 'Salvar');
        save.type = 'button';
        save.dataset.opportunityAction = 'save';
        save.setAttribute('aria-pressed', String(saved.includes(item.id)));
        const route = document.createElement('a');
        route.className = 'button button-primary opportunity-route';
        route.href = routeUrl(item);
        route.target = '_blank';
        route.rel = 'noopener noreferrer';
        route.textContent = 'Traçar rota';
        actions.append(details, save, route);
        card.append(top, title, description, location, meta, inclusions, rating, actions);
        return card;
    };

    const markerPopup = (item) => {
        const category = categoryFor(item.category);
        const deadline = item.deadline ? `Inscrições até ${formatDate(item.deadline)}` : 'Prazo não informado';
        return `<div class="opportunity-popup"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.description)}</p><span>${escapeHtml(category.name)} · ${escapeHtml(deadline)}</span><div><button type="button" data-map-details="${escapeHtml(item.id)}">Ver detalhes</button><a href="${routeUrl(item)}" target="_blank" rel="noopener noreferrer">Traçar rota</a></div></div>`;
    };
    const renderMapMarkers = (items) => {
        if (!map || !markerLayer) return;
        markerLayer.clearLayers();
        items.forEach((item) => {
            const category = categoryFor(item.category);
            const icon = L.divIcon({
                className: 'opportunity-map-marker',
                html: `<span style="--marker-color:${category.color}" aria-label="${escapeHtml(category.name)}">${category.icon}</span>`,
                iconSize: [38, 42],
                iconAnchor: [19, 38],
                popupAnchor: [0, -34]
            });
            L.marker([item.lat, item.lng], { icon, title: item.title, alt: category.name })
                .bindPopup(markerPopup(item))
                .addTo(markerLayer);
        });
    };
    const renderLegend = () => {
        const legend = $('#opportunityMapLegend');
        if (!legend) return;
        legend.replaceChildren();
        categories.forEach((category) => {
            const entry = createElement('span', 'opportunity-legend-item');
            const icon = createElement('i', '', category.icon);
            icon.style.setProperty('--category-color', category.color);
            entry.append(icon, document.createTextNode(category.name));
            legend.appendChild(entry);
        });
    };
    const renderAlerts = (items) => {
        const container = $('#opportunityAlerts');
        if (!container) return;
        container.replaceChildren();
        const alerts = [];
        items.forEach((item) => {
            const days = daysUntil(item.deadline);
            if (days !== null && days >= 0 && days <= 2 && item.signupOpen) {
                alerts.push(`Faltam ${days === 0 ? 'menos de 1 dia' : `${days} dias`} para o fim das inscrições no exemplo "${item.title}".`);
            }
            const distance = currentDistance(item);
            if (distance !== null && distance <= 0.2) {
                alerts.push(`Você está a aproximadamente ${Math.round(distance * 1000)} m do exemplo "${item.title}".`);
            }
        });
        alerts.forEach((message) => container.appendChild(createElement('p', 'opportunity-alert', message)));
    };
    const render = () => {
        const list = $('#opportunityList');
        if (!list) return;
        const filtered = filteredOpportunities();
        const sort = $('#opportunitySort')?.value || 'recommended';
        if (sort === 'distance' && locationPosition) {
            filtered.sort((first, second) => currentDistance(first) - currentDistance(second));
        } else if (sort === 'deadline') {
            filtered.sort((first, second) => (daysUntil(first.deadline) ?? Infinity) - (daysUntil(second.deadline) ?? Infinity));
        } else {
            filtered.sort((first, second) => Number(second.urgency === 'high') - Number(first.urgency === 'high'));
        }
        list.replaceChildren();
        filtered.forEach((item) => list.appendChild(buildOpportunityCard(item)));
        $('#opportunityResultsCount').textContent = `${filtered.length} oportunidade(s) de demonstração`;
        if (!filtered.length) {
            list.appendChild(createElement('p', 'opportunity-empty', 'Nenhuma oportunidade corresponde aos filtros selecionados. Ajuste os filtros e tente novamente.'));
        }
        renderMapMarkers(filtered);
        renderAlerts(filtered);
        const radiusHint = $('#opportunityRadiusHint');
        if (radiusHint) radiusHint.textContent = locationPosition
            ? 'Distâncias em linha reta; o raio considera a posição compartilhada nesta página.'
            : 'Compartilhe sua localização para aplicar o raio.';
        const mapStatus = $('#opportunityMapStatus');
        if (mapStatus) mapStatus.textContent = locationPosition
            ? 'Distâncias calculadas temporariamente; sua localização não é armazenada.'
            : 'Visualização demonstrativa em São Paulo. Ative a localização para calcular distâncias.';
        const savedToggle = $('#opportunitySavedToggle');
        if (savedToggle) {
            savedToggle.setAttribute('aria-pressed', String(savedOnly));
            savedToggle.textContent = savedOnly ? 'Ver todas' : `Salvas (${saved.length})`;
        }
    };

    const openMap = () => {
        const mapElement = $('#opportunityMap');
        if (!mapElement || map) return;
        if (typeof L === 'undefined') {
            $('#opportunityMapStatus').textContent = 'O mapa externo não foi carregado. Use a lista de oportunidades ou tente novamente com conexão à internet.';
            mapElement.classList.add('opportunity-map-unavailable');
            return;
        }
        try {
            map = L.map(mapElement, { scrollWheelZoom: false }).setView([origin.lat, origin.lng], 14);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                referrerPolicy: 'no-referrer',
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>'
            }).addTo(map);
            markerLayer = L.layerGroup().addTo(map);
            renderMapMarkers(filteredOpportunities());
            window.setTimeout(() => map?.invalidateSize(), 100);
        } catch (error) {
            $('#opportunityMapStatus').textContent = `Não foi possível iniciar o mapa: ${error.message}`;
            mapElement.classList.add('opportunity-map-unavailable');
        }
    };
    const detailParagraph = (label, text) => {
        const paragraph = createElement('p', 'opportunity-detail-line');
        const strong = createElement('strong', '', `${label}: `);
        paragraph.append(strong, document.createTextNode(text));
        return paragraph;
    };
    const openDetails = (item) => {
        if (!item) return;
        selectedOpportunity = item;
        const dialog = $('#opportunityDialog');
        $('#opportunityDialogTitle').textContent = item.title;
        const content = $('#opportunityDialogContent');
        content.replaceChildren(
            detailParagraph('Descrição', item.description),
            detailParagraph('Endereço demonstrativo', item.address),
            detailParagraph('Horários', item.hours),
            detailParagraph('Inscrições', item.signupOpen ? `Abertas até ${formatDate(item.deadline)}` : 'Não informado'),
            detailParagraph('Vagas', item.vacancies > 0 ? `${item.vacancies} (exemplo)` : 'Não informado'),
            detailParagraph('Custo', item.free ? 'Gratuito (exemplo)' : item.scholarship ? 'Bolsa (exemplo)' : 'Não informado'),
            detailParagraph('Apoios incluídos', [item.foodIncluded ? 'alimentação' : '', item.transportIncluded ? 'transporte' : ''].filter(Boolean).join(', ') || 'não informados'),
            detailParagraph('Acessibilidade', item.accessible ? 'Acessibilidade indicada no exemplo; confirme com o local.' : 'Não informada')
        );
        $('#opportunityDialogMessage').textContent = '';
        $('#opportunityReviewFields').hidden = true;
        $('#opportunityReviewButton').hidden = false;
        $('#opportunityReviewSubmit').hidden = true;
        if (!dialog.open) dialog.showModal();
    };
    const saveReviews = (nextReviews) => {
        if (!storeValue(storageKeys.reviews, nextReviews, 'sua avaliação')) return false;
        reviews = nextReviews;
        return true;
    };
    const saveReports = (nextReports) => {
        if (!storeValue(storageKeys.reports, nextReports, 'sua denúncia')) return false;
        reports = nextReports;
        return true;
    };
    const saveBookmarks = (nextSaved) => {
        if (!storeValue(storageKeys.saved, nextSaved, 'seus favoritos')) return false;
        saved = nextSaved;
        render();
        return true;
    };
    const useMyLocation = () => {
        if (!navigator.geolocation) {
            setMessage('Este navegador não oferece acesso à localização. Você ainda pode explorar todas as oportunidades.');
            return;
        }
        const button = $('#opportunityLocationButton');
        button.disabled = true;
        button.textContent = 'Solicitando permissão...';
        navigator.geolocation.getCurrentPosition((position) => {
            locationPosition = { lat: position.coords.latitude, lng: position.coords.longitude };
            button.disabled = false;
            button.innerHTML = 'Atualizar localização <span aria-hidden="true">⌖</span>';
            setMessage('Localização usada apenas temporariamente para calcular distâncias. Ela não é armazenada.');
            if (map) map.setView([locationPosition.lat, locationPosition.lng], 14);
            render();
        }, (error) => {
            button.disabled = false;
            button.innerHTML = 'Usar minha localização <span aria-hidden="true">⌖</span>';
            const message = error.code === error.PERMISSION_DENIED
                ? 'A permissão de localização não foi concedida. Você pode continuar navegando sem compartilhar sua posição.'
                : error.code === error.POSITION_UNAVAILABLE
                    ? 'Não foi possível obter sua localização. Tente novamente ou continue sem ela.'
                    : 'A solicitação de localização expirou. Tente novamente ou continue sem ela.';
            setMessage(message);
        }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
    };
    const setIncognito = (enabled) => {
        if (enabled) {
            const hasSavedData = saved.length || Object.keys(reviews).length || reports.length;
            if (hasSavedData && !window.confirm('Ativar o modo incógnito também apagará os favoritos, avaliações e denúncias salvos neste navegador. Deseja continuar?')) {
                $('#opportunityIncognito').checked = false;
                return;
            }
            if (hasSavedData) {
                try {
                    Object.values(storageKeys).forEach((key) => localStorage.removeItem(key));
                } catch (error) {
                    $('#opportunityIncognito').checked = false;
                    setMessage(`Não foi possível apagar os dados salvos; o modo incógnito não foi ativado: ${error.message}`);
                    return;
                }
                saved = [];
                reviews = {};
                reports = [];
                savedOnly = false;
            }
        }
        incognito = enabled;
        setMessage(incognito
            ? 'Modo incógnito ativo: favoritos, avaliações e denúncias permanecerão apenas até esta página ser fechada.'
            : 'Modo incógnito desativado: ações explícitas de salvar e avaliar podem ser armazenadas neste navegador.');
        render();
    };
    const clearFilters = () => {
        $('#opportunitySearch').value = '';
        document.querySelectorAll('input[name="opportunityCategory"]').forEach((input) => { input.checked = true; });
        ['opportunityOpenNow', 'opportunityRegistrationOpen', 'opportunityHasVacancies',
            'opportunityNearSchool', 'opportunityTransitIncluded', 'opportunityOutsideClass',
            'opportunityFreeOnly', 'opportunityTransitFits'].forEach((id) => { $(`#${id}`).checked = false; });
        $('input[name="opportunityRadius"][value="1"]').checked = true;
        $('#opportunityTransitBudget').value = '';
        $('#opportunityTransitFare').value = '';
        $('#opportunitySort').value = 'recommended';
        savedOnly = false;
        render();
    };
    const bindEvents = () => {
        const filterInputs = [
            '#opportunitySearch', '#opportunityOpenNow', '#opportunityRegistrationOpen',
            '#opportunityHasVacancies', '#opportunityNearSchool', '#opportunityTransitIncluded',
            '#opportunityOutsideClass', '#opportunityFreeOnly', '#opportunityTransitFits',
            '#opportunityTransitBudget', '#opportunityTransitFare', '#opportunitySort'
        ];
        filterInputs.forEach((selector) => {
            const input = $(selector);
            input?.addEventListener('input', render);
            input?.addEventListener('change', render);
        });
        document.querySelectorAll('input[name="opportunityRadius"]').forEach((input) => input.addEventListener('change', render));
        $('#opportunityCategoryFilters')?.addEventListener('change', render);
        $('#opportunityClearFilters')?.addEventListener('click', clearFilters);
        $('#opportunityLocationButton')?.addEventListener('click', useMyLocation);
        $('#opportunitySavedToggle')?.addEventListener('click', () => {
            savedOnly = !savedOnly;
            render();
        });
        $('#opportunityIncognito')?.addEventListener('change', (event) => setIncognito(event.target.checked));
        $('#opportunityFilterToggle')?.addEventListener('click', (event) => {
            const panel = $('#opportunityFilters');
            const expanded = !panel.classList.contains('is-open');
            panel.classList.toggle('is-open', expanded);
            event.currentTarget.setAttribute('aria-expanded', String(expanded));
            if (expanded) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        $('#opportunityList')?.addEventListener('click', (event) => {
            const button = event.target.closest('[data-opportunity-action]');
            if (!button) return;
            const item = opportunities.find((candidate) => candidate.id === button.closest('[data-opportunity-id]')?.dataset.opportunityId);
            if (!item) return;
            if (button.dataset.opportunityAction === 'details') openDetails(item);
            if (button.dataset.opportunityAction === 'save') {
                const nextSaved = saved.includes(item.id) ? saved.filter((id) => id !== item.id) : [...saved, item.id];
                saveBookmarks(nextSaved);
            }
        });
        $('#opportunityMap')?.addEventListener('click', (event) => {
            const button = event.target.closest('[data-map-details]');
            if (button) openDetails(opportunities.find((item) => item.id === button.dataset.mapDetails));
        });
        const dialog = $('#opportunityDialog');
        dialog?.querySelectorAll('.opportunity-dialog-close, .opportunity-dialog-cancel').forEach((button) => {
            button.addEventListener('click', () => dialog.close());
        });
        $('#opportunityReviewButton')?.addEventListener('click', () => {
            $('#opportunityReviewFields').hidden = false;
            $('#opportunityReviewButton').hidden = true;
            $('#opportunityReviewSubmit').hidden = false;
        });
        $('#opportunityReviewForm')?.addEventListener('submit', (event) => {
            event.preventDefault();
            if (!selectedOpportunity) return;
            const nextReviews = { ...reviews };
            const entries = Array.isArray(nextReviews[selectedOpportunity.id]) ? [...nextReviews[selectedOpportunity.id]] : [];
            entries.push({ rating: Number($('#opportunityRating').value), comment: $('#opportunityReviewText').value.trim(), date: new Date().toISOString() });
            nextReviews[selectedOpportunity.id] = entries;
            if (!saveReviews(nextReviews)) return;
            $('#opportunityDialogMessage').textContent = incognito
                ? 'Avaliação mantida apenas enquanto esta página estiver aberta.'
                : 'Avaliação salva somente neste navegador; ela não é compartilhada com outras pessoas.';
            $('#opportunityReviewText').value = '';
            render();
        });
        $('#opportunityReportButton')?.addEventListener('click', () => {
            if (!selectedOpportunity) return;
            const reason = window.prompt('Qual informação parece incorreta? Sua denúncia ficará somente neste navegador.');
            if (!reason?.trim()) return;
            const nextReports = [...reports, { id: selectedOpportunity.id, reason: reason.trim().slice(0, 500), date: new Date().toISOString() }];
            if (!saveReports(nextReports)) return;
            $('#opportunityDialogMessage').textContent = incognito
                ? 'Denúncia anotada apenas durante esta sessão. Como não há envio ao servidor, entre em contato com a equipe para reportar oficialmente.'
                : 'Denúncia anotada somente neste navegador. Como não há envio ao servidor, entre em contato com a equipe para reportar oficialmente.';
        });
        document.body.addEventListener('click', (event) => {
            const opportunityNav = event.target.closest('[data-view="oportunidades"], [data-view-target="oportunidades"]');
            if (opportunityNav) window.setTimeout(() => {
                openMap();
                map?.invalidateSize();
            }, 120);
        });
    };
    const initialize = () => {
        if (!$('#opportunityMap')) return;
        saved = readStoredArray(storageKeys.saved, [], 'favoritos');
        reviews = readStoredObject(storageKeys.reviews, {}, 'avaliações');
        reports = readStoredArray(storageKeys.reports, [], 'denúncias');
        buildCategoryFilters();
        renderLegend();
        bindEvents();
        render();
        openMap();
    };
    document.addEventListener('DOMContentLoaded', initialize);
})();
