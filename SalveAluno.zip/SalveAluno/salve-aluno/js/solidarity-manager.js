(() => {
    const statusLabel = { pendente: 'Em análise', aprovado: 'Aprovado', entregue: 'Entregue', devolvido: 'Devolvido', recusado: 'Recusado' };
    const form = () => document.querySelector('#solidarityItemForm');
    const categoryVisuals = {
        roupas: ['👕', '#3b82f6'],
        uniformes: ['🎽', '#06b6d4'],
        materiais: ['📚', '#10b981'],
        tecnologia: ['💻', '#8b5cf6'],
        livros: ['📖', '#f59e0b'],
        calcados: ['👟', '#ec4899'],
        alimentacao: ['🥫', '#f97316'],
        transporte: ['🚌', '#0ea5e9'],
        outros: ['📦', '#6b7280']
    };
    const imageLibrary = window.SolidarityImages
        ? Promise.resolve(window.SolidarityImages)
        : import('./solidarity-images.js').then(() => {
            if (!window.SolidarityImages) throw new Error('O módulo de imagens do Banco Solidário não ficou disponível.');
            return window.SolidarityImages;
        });
    let previewUrl = '';

    const create = (tag, className, text) => {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (text !== undefined) element.textContent = text;
        return element;
    };

    function formatDate(value) {
        if (!value) return 'Data não informada';
        const date = new Date(`${value.slice(0, 10)}T12:00:00`);
        return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('pt-BR').format(date);
    }

    async function runAction(button, action) {
        button.disabled = true;
        try {
            await action();
            await loadManager();
        } catch (error) {
            document.querySelector('#solidarityManagerStatus').textContent = error.message;
            button.disabled = false;
        }
    }

    function renderNotifications(notifications) {
        const list = document.querySelector('#solidarityNotifications');
        list.replaceChildren();
        if (!notifications.length) return;
        notifications.slice(0, 5).forEach(({ message }) => {
            const item = create('div', 'role-list-item');
            item.append(create('div', 'avatar', '♧'), create('div', '', message));
            list.appendChild(item);
        });
    }

    function renderRequests(requests) {
        const list = document.querySelector('#solidarityRequests');
        list.replaceChildren();
        if (!requests.length) {
            list.appendChild(create('p', 'role-empty', 'Nenhuma solicitação no acompanhamento.'));
            return;
        }
        requests.forEach((request) => {
            const item = create('article', 'role-list-item');
            const avatar = create('div', 'avatar', request.studentName.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase());
            const content = create('div');
            content.append(
                create('strong', '', `${request.itemTitle} · ${request.studentName}`),
                create('small', '', `${request.category} · ${request.quantity} unidade(s) · ${statusLabel[request.status] || request.status}`)
            );
            const details = create('small');
            const requestType = request.requestType === 'emprestimo' ? 'Empréstimo' : 'Doação permanente';
            const detailsText = [`${requestType}`, `Motivo: ${request.note || 'Não informado'}`];
            if (request.pickupDate) detailsText.push(`Retirada preferencial: ${formatDate(request.pickupDate)}`);
            if (request.dueDate) detailsText.push(`Devolução até: ${formatDate(request.dueDate)}`);
            if (Number(request.needPickup)) detailsText.push('Solicitou ajuda para buscar');
            details.textContent = detailsText.join(' · ');
            content.appendChild(details);
            const actions = create('div', 'role-actions');
            if (request.status === 'pendente') {
                [['aprovado', 'Aprovar'], ['recusado', 'Rejeitar']].forEach(([decision, label]) => {
                    const button = create('button', `role-button${decision === 'recusado' ? ' alt' : ''}`, label);
                    button.type = 'button';
                    button.addEventListener('click', () => runAction(button, () =>
                        SalveDatabase.request('banco-revisar-solicitacao', { method: 'POST', data: { id: request.id, decision } })));
                    actions.appendChild(button);
                });
            }
            if (request.status === 'aprovado') {
                const button = create('button', 'role-button', 'Registrar retirada');
                button.type = 'button';
                button.addEventListener('click', () => runAction(button, () =>
                    SalveDatabase.request('banco-revisar-solicitacao', { method: 'POST', data: { id: request.id, decision: 'entregue' } })));
                actions.appendChild(button);
            }
            if (request.status === 'entregue' && request.requestType === 'emprestimo') {
                const button = create('button', 'role-button', 'Registrar devolução');
                button.type = 'button';
                button.addEventListener('click', () => runAction(button, () =>
                    SalveDatabase.request('banco-devolver-item', { method: 'POST', data: { id: request.id } })));
                actions.appendChild(button);
            }
            if (request.status === 'entregue' && request.receivedAt) {
                actions.appendChild(create('span', 'status ok', 'Recebimento confirmado'));
            }
            item.append(avatar, content, actions);
            list.appendChild(item);
        });
    }

    function fillCategoryOptions(categories) {
        const select = form().elements.categoryId;
        const selected = select.value;
        select.replaceChildren();
        categories.forEach((category) => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            option.dataset.slug = category.slug;
            select.appendChild(option);
        });
        if (selected) select.value = selected;
        buildCategoryPicker(categories);
        if (!form().elements.itemId.value) updateCategoryPreview();
    }

    function buildCategoryPicker(categories) {
        const categorySelect = form().elements.categoryId;
        let picker = document.querySelector('#solidarityCategoryPicker');
        if (!picker) {
            picker = create('div', 'solidarity-category-picker');
            picker.id = 'solidarityCategoryPicker';
            picker.setAttribute('role', 'group');
            picker.setAttribute('aria-label', 'Escolha uma categoria');
            categorySelect.closest('label').insertAdjacentElement('afterend', picker);
        }
        picker.replaceChildren();
        categories.forEach((category) => {
            const [emoji, color] = categoryVisuals[category.slug] || categoryVisuals.outros;
            const button = create('button', 'solidarity-category-choice');
            button.type = 'button';
            button.dataset.categoryId = String(category.id);
            button.setAttribute('aria-pressed', String(String(category.id) === categorySelect.value));
            button.style.setProperty('--category-color', color);
            const image = create('img', 'solidarity-category-image');
            image.src = window.SolidarityImages.forCategory(category.slug);
            image.alt = '';
            image.loading = 'lazy';
            window.SolidarityImages.applyLocalFallback(image, category.slug);
            const icon = create('span', 'solidarity-category-emoji', emoji);
            icon.setAttribute('aria-hidden', 'true');
            const name = create('span', 'solidarity-category-name', category.name);
            button.append(image, icon, name);
            button.addEventListener('click', () => {
                categorySelect.value = String(category.id);
                categorySelect.dispatchEvent(new Event('change', { bubbles: true }));
            });
            picker.appendChild(button);
        });
        updateCategoryPickerSelection();
    }

    function updateCategoryPickerSelection() {
        const selected = String(form().elements.categoryId.value);
        document.querySelectorAll('.solidarity-category-choice').forEach((button) => {
            button.setAttribute('aria-pressed', String(button.dataset.categoryId === selected));
        });
    }

    function updateCategoryPreview() {
        const itemForm = form();
        updateCategoryPickerSelection();
        if (itemForm.elements.itemId.value || itemForm.elements.solidarityImage.files.length) return;
        const category = itemForm.elements.categoryId.selectedOptions[0]?.dataset.slug || 'materiais';
        const image = document.querySelector('#solidarityImagePreview');
        image.alt = `Imagem ilustrativa da categoria ${itemForm.elements.categoryId.selectedOptions[0]?.textContent || 'do item'}`;
        showPreview(window.SolidarityImages.forCategory(category, itemForm.elements.title.value));
        document.querySelector('#solidarityItemFormStatus').textContent =
            'Prévia ilustrativa da categoria. Envie uma foto própria para substituir esta imagem no catálogo.';
    }

    function editItem(item) {
        const itemForm = form();
        itemForm.elements.itemId.value = item.id;
        itemForm.elements.title.value = item.title;
        itemForm.elements.categoryId.value = String(item.categoryId);
        itemForm.elements.itemType.value = item.itemType;
        itemForm.elements.quantity.value = item.totalQuantity;
        itemForm.elements.size.value = item.size || '';
        const conditionSelect = itemForm.elements.condition;
        if (item.condition && !Array.from(conditionSelect.options).some((option) => option.value === item.condition)) {
            const option = document.createElement('option');
            option.value = item.condition;
            option.textContent = item.condition;
            conditionSelect.appendChild(option);
        }
        conditionSelect.value = item.condition || 'Novo';
        itemForm.elements.donor.value = item.donor || '';
        itemForm.elements.donatedAt.value = item.donatedAt || '';
        itemForm.elements.description.value = item.description || '';
        itemForm.elements.solidarityImage.value = '';
        const previewSource = window.SolidarityImages.forItem(item);
        const illustrative = window.SolidarityImages.isIllustrative(item.imagePath);
        document.querySelector('#solidarityImagePreview').alt = illustrative
            ? `Imagem ilustrativa da categoria ${item.category}`
            : `Imagem enviada para ${item.title}`;
        showPreview(previewSource, item.categorySlug);
        document.querySelector('#solidarityItemFormStatus').textContent = illustrative
            ? 'Este item usa uma imagem ilustrativa. Envie uma foto própria para substituí-la.'
            : 'Foto enviada para este item. Selecione outra imagem para trocá-la.';
        document.querySelector('#saveSolidarityItem').textContent = 'Salvar alterações';
        document.querySelector('#cancelSolidarityEdit').hidden = false;
        itemForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
        itemForm.elements.title.focus();
    }

    function showPreview(source, category = '') {
        const preview = document.querySelector('#solidarityImagePreview');
        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            previewUrl = '';
        }
        if (!source) {
            preview.removeAttribute('src');
            preview.hidden = true;
            return;
        }
        preview.src = source;
        if (!source.startsWith('blob:')) window.SolidarityImages.applyLocalFallback(preview, category);
        if (source.startsWith('blob:')) previewUrl = source;
        preview.hidden = false;
    }

    function resetForm() {
        const itemForm = form();
        itemForm.reset();
        itemForm.elements.itemId.value = '';
        document.querySelector('#saveSolidarityItem').textContent = 'Adicionar item';
        document.querySelector('#cancelSolidarityEdit').hidden = true;
        updateCategoryPreview();
    }

    function renderItems(items) {
        const list = document.querySelector('#solidarityManagerItems');
        list.replaceChildren();
        if (!items.length) {
            list.appendChild(create('p', 'role-empty', 'Ainda não há itens cadastrados no catálogo.'));
            return;
        }
        items.forEach((item) => {
            const row = create('article', 'role-list-item');
            const content = create('div');
            const image = create('img', 'solidarity-manager-thumbnail');
            image.src = window.SolidarityImages.forItem(item);
            image.alt = `${window.SolidarityImages.isIllustrative(item.imagePath) ? 'Imagem ilustrativa' : 'Imagem'}: ${item.title}`;
            image.loading = 'lazy';
            window.SolidarityImages.applyLocalFallback(image, item.categorySlug);
            row.appendChild(image);
            content.append(
                create('strong', '', item.title),
                create('small', '', `${item.category} · ${item.availableQuantity}/${item.totalQuantity} disponíveis · ${item.itemType === 'emprestimo' ? 'Empréstimo' : 'Doação'} · ${item.status}`)
            );
            const actions = create('div', 'solidarity-manager-item-actions');
            const edit = create('button', 'role-button alt', 'Editar');
            edit.type = 'button';
            edit.addEventListener('click', () => editItem(item));
            actions.appendChild(edit);
            if (item.status !== 'indisponivel' && item.status !== 'arquivado') {
                const unavailable = create('button', 'role-button alt', 'Indisponibilizar');
                unavailable.type = 'button';
                unavailable.addEventListener('click', () => runAction(unavailable, () =>
                    SalveDatabase.request('banco-indisponibilizar-item', { method: 'POST', data: { itemId: item.id } })));
                actions.appendChild(unavailable);
            }

            row.append(content, actions);
            list.appendChild(row);
        });
    }

    async function loadManager() {
        const status = document.querySelector('#solidarityManagerStatus');
        status.textContent = 'Atualizando o Banco Solidário...';
        try {
            const [catalog, requestsResult, notificationResult] = await Promise.all([
                SalveDatabase.request('banco-itens'),
                SalveDatabase.request('banco-pedidos'),
                SalveDatabase.request('banco-notificacoes')
            ]);
            fillCategoryOptions(catalog.categories);
            renderItems(catalog.items);
            renderRequests(requestsResult.requests);
            renderNotifications(notificationResult.notifications || []);
            const pending = requestsResult.requests.filter((request) => request.status === 'pendente').length;
            status.textContent = `${catalog.items.length} item(ns) no catálogo · ${pending} solicitação(ões) aguardando análise.`;
        } catch (error) {
            status.textContent = `Não foi possível carregar o Banco Solidário: ${error.message}`;
        }
    }

    function downloadReport(items) {
        const headers = ['Item', 'Categoria', 'Modalidade', 'Doador', 'Data da doação', 'Condição', 'Quantidade total', 'Disponível', 'Solicitações', 'Unidades entregues', 'Status'];
        const rows = items.map((item) => [
            item.title, item.category, item.itemType === 'emprestimo' ? 'Empréstimo' : 'Doação permanente',
            item.donor, item.donatedAt, item.conditionLabel, item.totalQuantity, item.availableQuantity,
            item.requestCount, item.deliveredQuantity, item.status
        ]);
        const escape = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
        const csv = [headers, ...rows].map((row) => row.map(escape).join(';')).join('\r\n');
        const blob = new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `relatorio-banco-solidario-${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    document.addEventListener('DOMContentLoaded', async () => {
        const itemForm = form();
        const itemStatus = document.querySelector('#solidarityItemFormStatus');
        try {
            await imageLibrary;
        } catch (error) {
            itemStatus.textContent = `Não foi possível carregar as imagens do Banco Solidário: ${error.message}`;
            return;
        }
        itemForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            if (!itemForm.reportValidity()) return;
            const data = new FormData(itemForm);
            const itemId = data.get('itemId');
            const imageFile = data.get('solidarityImage');
            const button = document.querySelector('#saveSolidarityItem');
            button.disabled = true;
            itemStatus.textContent = '';
            try {
                const payload = {
                    ...(itemId ? { itemId: Number(itemId) } : {}),
                    title: String(data.get('title')).trim(),
                    categoryId: Number(data.get('categoryId')),
                    itemType: data.get('itemType'),
                    quantity: Number(data.get('quantity')),
                    size: String(data.get('size') || '').trim(),
                    condition: String(data.get('condition') || '').trim(),
                    donor: String(data.get('donor') || '').trim(),
                    donatedAt: data.get('donatedAt') || '',
                    description: String(data.get('description')).trim()
                };
                const uploadData = new FormData();
                uploadData.append('data', JSON.stringify(payload));
                if (imageFile instanceof File && imageFile.size) uploadData.append('solidarityImage', imageFile);
                await SalveDatabase.request(itemId ? 'banco-editar-item' : 'banco-cadastrar-item', {
                    method: 'POST',
                    formData: uploadData
                });
                itemStatus.textContent = itemId ? 'Item atualizado.' : 'Item adicionado ao Banco Solidário.';
                resetForm();
                await loadManager();
            } catch (error) {
                itemStatus.textContent = error.message;
            } finally {
                button.disabled = false;
            }
        });
        document.querySelector('#cancelSolidarityEdit').addEventListener('click', resetForm);
        itemForm.elements.solidarityImage.addEventListener('change', () => {
            const [file] = itemForm.elements.solidarityImage.files;
            if (!file) return;
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
                itemForm.elements.solidarityImage.value = '';
                itemStatus.textContent = 'Escolha uma imagem JPG, PNG ou WEBP com até 5 MB.';
                return;
            }
            showPreview(URL.createObjectURL(file));
            document.querySelector('#solidarityImagePreview').alt = `Prévia da imagem enviada para ${itemForm.elements.title.value || 'o item'}`;
            itemStatus.textContent = 'Prévia da imagem selecionada. Ela substituirá a imagem atual ao salvar.';
        });
        itemForm.elements.categoryId.addEventListener('change', updateCategoryPreview);
        itemForm.elements.title.addEventListener('input', updateCategoryPreview);
        document.querySelector('#refreshSolidarityRequests').addEventListener('click', loadManager);
        document.querySelector('#exportSolidarityReport').addEventListener('click', async (event) => {
            const button = event.currentTarget;
            button.disabled = true;
            try {
                const report = await SalveDatabase.request('banco-relatorio');
                downloadReport(report.items);
            } catch (error) {
                document.querySelector('#solidarityManagerStatus').textContent = `Não foi possível exportar o relatório: ${error.message}`;
            } finally {
                button.disabled = false;
            }
        });
        loadManager();
    });
})();
