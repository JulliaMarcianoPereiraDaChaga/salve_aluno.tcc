(() => {
    const categories = [
        { id: 'roupas', name: 'Roupas', icon: '👕' },
        { id: 'uniformes', name: 'Uniformes', icon: '🎽' },
        { id: 'materiais', name: 'Materiais Escolares', icon: '📚' },
        { id: 'tecnologia', name: 'Tecnologia', icon: '💻' },
        { id: 'livros', name: 'Livros', icon: '📖' },
        { id: 'calcados', name: 'Calçados', icon: '👟' },
        { id: 'outros', name: 'Outros', icon: '📦' },
        { id: 'alimentacao', name: 'Alimentação e higiene', icon: '🥫' },
        { id: 'transporte', name: 'Transporte', icon: '🚌' }
    ];
    const statusLabels = {
        pendente: 'Em análise',
        aprovado: 'Aprovado',
        entregue: 'Entregue',
        devolvido: 'Devolvido',
        recusado: 'Precisa de outra solução'
    };
    const filters = { category: '', selectedCategories: new Set(), conditions: new Set(), types: new Set() };
    let items = [];
    let requestHistory = [];

    const byId = (id) => document.getElementById(id);
    const create = (tag, className, text) => {
        const element = document.createElement(tag);
        if (className) element.className = className;
        if (text !== undefined) element.textContent = text;
        return element;
    };

    function renderFilterGroup(containerId, values, set, labelFor) {
        const container = byId(containerId);
        container.replaceChildren();
        values.forEach((value) => {
            const label = create('label', 'solidarity-check');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.value = value;
            input.checked = set.has(value);
            input.addEventListener('change', () => {
                if (input.checked) set.add(value);
                else set.delete(value);
                renderItems();
            });
            label.append(input, create('span', '', labelFor(value)));
            container.appendChild(label);
        });
    }

    function renderFilters() {
        const categoryFilters = byId('solidarityCategoryFilters');
        categoryFilters.replaceChildren();
        categories.forEach((category) => {
            const label = create('label', 'solidarity-check');
            const input = document.createElement('input');
            input.type = 'checkbox';
            input.value = category.id;
            input.checked = filters.selectedCategories.has(category.id);
            input.addEventListener('change', () => {
                if (input.checked) filters.selectedCategories.add(category.id);
                else filters.selectedCategories.delete(category.id);
                filters.category = '';
                renderTabs();
                renderItems();
            });
            label.append(input, create('span', '', category.name));
            categoryFilters.appendChild(label);
        });
        renderFilterGroup('solidarityConditionFilters', ['novo', 'seminovo', 'usado_bom_estado'], filters.conditions, (value) => ({
            novo: 'Novo',
            seminovo: 'Seminovo',
            usado_bom_estado: 'Usado em bom estado'
        })[value]);
        renderFilterGroup('solidarityTypeFilters', ['doacao', 'emprestimo'], filters.types, (value) =>
            value === 'doacao' ? 'Doação permanente' : 'Empréstimo temporário');
    }

    function renderTabs() {
        const tabs = byId('solidarityCategoryTabs');
        tabs.replaceChildren();
        const all = create('button', 'solidarity-tab', 'Todos os itens');
        all.type = 'button';
        all.setAttribute('role', 'tab');
        all.setAttribute('aria-selected', String(!filters.category));
        all.addEventListener('click', () => {
            filters.category = '';
            filters.selectedCategories.clear();
            renderFilters();
            renderTabs();
            renderItems();
        });
        tabs.appendChild(all);
        categories.forEach((category) => {
            if (!items.some((item) => item.categorySlug === category.id)) return;
            const button = create('button', 'solidarity-tab', `${category.icon} ${category.name}`);
            button.type = 'button';
            button.setAttribute('role', 'tab');
            button.setAttribute('aria-selected', String(filters.category === category.id));
            button.addEventListener('click', () => {
                filters.category = filters.category === category.id ? '' : category.id;
                filters.selectedCategories.clear();
                renderFilters();
                renderTabs();
                renderItems();
            });
            tabs.appendChild(button);
        });
    }

    function matchesFilters(item) {
        const query = byId('solidaritySearch').value.trim().toLocaleLowerCase('pt-BR');
        const categoryMatch = (!filters.category || item.categorySlug === filters.category) &&
            (!filters.selectedCategories.size || filters.selectedCategories.has(item.categorySlug));
        const conditionText = String(item.condition || '').toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const condition = conditionText.includes('seminovo') ? 'seminovo'
            : conditionText.includes('usado') ? 'usado_bom_estado'
                : conditionText.includes('novo') ? 'novo' : '';
        const conditionMatch = !filters.conditions.size || filters.conditions.has(condition);
        const typeMatch = !filters.types.size || filters.types.has(item.itemType);
        const availableMatch = !byId('solidarityAvailableOnly').checked ||
            (item.status === 'disponivel' && Number(item.availableQuantity) > 0);
        const text = `${item.title} ${item.description} ${item.category} ${item.size}`.toLocaleLowerCase('pt-BR');
        return categoryMatch && conditionMatch && typeMatch && availableMatch && text.includes(query);
    }

    function openRequest(item) {
        const dialog = byId('solidarityRequestDialog');
        const form = byId('solidarityRequestForm');
        form.reset();
        form.elements.itemId.value = item.id;
        byId('solidarityDialogTitle').textContent = `Solicitar ${item.title}`;
        byId('solidarityRequestMessage').textContent = '';
        form.querySelector('[type="submit"]').textContent = 'Enviar solicitação →';
        const donationOption = form.querySelector('[value="doacao"]');
        const loanOption = form.querySelector('[value="emprestimo"]');
        donationOption.closest('label').hidden = item.itemType !== 'doacao';
        loanOption.closest('label').hidden = item.itemType !== 'emprestimo';
        form.querySelector(`input[name="requestType"][value="${item.itemType}"]`).checked = true;
        byId('solidarityDueDateWrap').hidden = item.itemType !== 'emprestimo';
        const dueDate = form.elements.dueDate;
        dueDate.required = item.itemType === 'emprestimo';
        dueDate.min = new Date().toISOString().slice(0, 10);
        form.elements.pickupDate.min = new Date().toISOString().slice(0, 10);
        dialog.showModal();
        form.elements.reason.focus();
    }

    function renderItems() {
        const grid = byId('solidarityItems');
        const filtered = items.filter(matchesFilters);
        grid.replaceChildren();
        byId('solidarityStatus').textContent = `${filtered.length} ${filtered.length === 1 ? 'item disponível' : 'itens disponíveis'} para os filtros selecionados.`;
        if (!filtered.length) {
            grid.appendChild(create('p', 'solidarity-empty', 'Não encontramos itens com esses filtros. Tente alterar a busca ou confira novamente mais tarde.'));
            return;
        }
        filtered.forEach((item) => {
            const card = create('article', 'benefit-card solidarity-card');
            const imageWrap = create('div', 'solidarity-card-image-wrap');
            const image = document.createElement('img');
            const imageSource = window.SolidarityImages.forItem(item);
            const isIllustrative = window.SolidarityImages.isIllustrative(item.imagePath);
            image.src = imageSource;
            image.alt = `${isIllustrative ? 'Imagem ilustrativa' : 'Imagem do item'}: ${item.category}`;
            image.loading = 'lazy';
            window.SolidarityImages.applyLocalFallback(image, item.categorySlug);
            imageWrap.appendChild(image);
            if (isIllustrative) imageWrap.appendChild(create('span', 'solidarity-image-label', 'Imagem ilustrativa'));
            const stock = create('span', 'benefit-tag', `${item.availableQuantity} disponível(is)`);
            const title = create('h2', '', item.title);
            const description = create('p', '', `${item.description}${item.size ? ` · Tamanho: ${item.size}` : ''}`);
            const meta = create('div', 'solidarity-card-meta');
            meta.append(
                create('span', 'solidarity-meta-tag', item.category),
                create('span', 'solidarity-meta-tag', item.condition || 'Condição não informada'),
                create('span', 'solidarity-meta-tag', item.itemType === 'emprestimo' ? 'Empréstimo' : 'Doação permanente'),
                create('span', 'solidarity-meta-tag', `Doador: ${item.donor || 'Anônimo'}`),
                ...(item.donatedAt ? [create('span', 'solidarity-meta-tag', `Doado em ${formatDate(item.donatedAt)}`)] : [])
            );
            const button = create('button', 'button button-primary', 'Pedir este apoio →');
            button.type = 'button';
            button.addEventListener('click', () => openRequest(item));
            card.append(imageWrap, stock, title, description, meta, button);
            grid.appendChild(card);
        });
    }

    function formatDate(value) {
        if (!value) return 'A combinar';
        const date = new Date(`${value.slice(0, 10)}T12:00:00`);
        return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat('pt-BR').format(date);
    }

    function renderHistory() {
        const container = byId('solidarityRequests');
        container.replaceChildren();
        if (!requestHistory.length) {
            container.appendChild(create('p', 'solidarity-empty', 'Você ainda não enviou solicitações pelo Banco Solidário.'));
            return;
        }
        requestHistory.forEach((request) => {
            const row = create('article', 'solidarity-request-row');
            const main = create('div');
            main.append(create('strong', '', request.itemTitle), create('small', '', `${request.category} · ${request.requestType === 'emprestimo' ? 'Empréstimo' : 'Doação permanente'}`));
            const status = create('span', 'solidarity-status-tag', statusLabels[request.status] || request.status);
            const details = create('div');
            details.append(create('small', '', `Solicitado em ${formatDate(request.requestedAt)}`));
            if (request.dueDate) details.append(create('small', '', `Devolver até ${formatDate(request.dueDate)}`));
            const actions = create('div');
            if (request.status === 'entregue' && !request.receivedAt) {
                const button = create('button', 'role-button', 'Confirmar recebimento');
                button.type = 'button';
                button.addEventListener('click', async () => {
                    button.disabled = true;
                    try {
                        await SalveDatabase.request('banco-confirmar-recebimento', { method: 'POST', data: { id: request.id } });
                        await loadData();
                    } catch (error) {
                        button.disabled = false;
                        byId('solidarityStatus').textContent = error.message;
                    }
                });
                actions.appendChild(button);
            } else if (request.receivedAt) actions.appendChild(create('small', '', 'Recebimento confirmado'));
            row.append(main, status, details, actions);
            container.appendChild(row);
        });
    }

    function renderNotifications(notifications) {
        const container = byId('solidarityNotifications');
        container.replaceChildren();
        if (!notifications.length) return;
        container.appendChild(create('h3', '', 'Atualizações recentes'));
        notifications.slice(0, 4).forEach((notification) => {
            container.appendChild(create('p', '', notification.message));
        });
    }

    async function loadData() {
        const status = byId('solidarityStatus');
        status.textContent = 'Carregando itens disponíveis...';
        try {
            const [catalog, history, alerts] = await Promise.all([
                SalveDatabase.request('banco-itens'),
                SalveDatabase.request('banco-meus-pedidos'),
                SalveDatabase.request('banco-notificacoes')
            ]);
            items = catalog.items;
            requestHistory = history.requests || [];
            renderFilters();
            renderTabs();
            renderItems();
            renderHistory();
            renderNotifications(alerts.notifications || []);
        } catch (error) {
            status.textContent = `Não foi possível carregar o Banco Solidário: ${error.message}`;
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const dialog = byId('solidarityRequestDialog');
        const form = byId('solidarityRequestForm');
        document.querySelectorAll('[data-close-request]').forEach((button) => button.addEventListener('click', () => dialog.close()));
        form.querySelectorAll('input[name="requestType"]').forEach((input) => input.addEventListener('change', () => {
            const loan = input.value === 'emprestimo' && input.checked;
            byId('solidarityDueDateWrap').hidden = !loan;
            form.elements.dueDate.required = loan;
        }));
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            if (!form.reportValidity()) return;
            const button = form.querySelector('[type="submit"]');
            const data = new FormData(form);
            button.disabled = true;
            try {
                await SalveDatabase.request('banco-solicitar', {
                    method: 'POST',
                    data: {
                        itemId: Number(data.get('itemId')),
                        quantity: 1,
                        note: String(data.get('reason') || '').trim(),
                        requestType: data.get('requestType'),
                        dueDate: data.get('dueDate') || '',
                        pickupDate: data.get('pickupDate') || '',
                        needPickup: data.has('needPickup')
                    }
                });
                byId('solidarityRequestMessage').textContent = 'Pedido enviado! A equipe de assistência social recebeu uma notificação e vai acompanhar os próximos passos.';
                form.querySelector('[type="submit"]').textContent = 'Solicitação enviada ✓';
                await loadData();
                window.setTimeout(() => dialog.close(), 1100);
            } catch (error) {
                byId('solidarityRequestMessage').textContent = error.message;
            } finally {
                button.disabled = false;
            }
        });
        byId('solidaritySearch').addEventListener('input', renderItems);
        byId('solidarityAvailableOnly').addEventListener('change', renderItems);
        byId('solidarityClearFilters').addEventListener('click', () => {
            filters.category = '';
            filters.selectedCategories.clear();
            filters.conditions.clear();
            filters.types.clear();
            byId('solidaritySearch').value = '';
            byId('solidarityAvailableOnly').checked = true;
            renderFilters();
            renderTabs();
            renderItems();
        });
        byId('solidarityFilterToggle').addEventListener('click', (event) => {
            const filtersPanel = byId('solidarityFilters');
            const open = filtersPanel.classList.toggle('is-open');
            event.currentTarget.setAttribute('aria-expanded', String(open));
        });
        byId('solidarityHistoryToggle').addEventListener('click', (event) => {
            const panel = byId('solidarityHistory');
            panel.hidden = !panel.hidden;
            event.currentTarget.setAttribute('aria-expanded', String(!panel.hidden));
            if (!panel.hidden) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
        loadData();
    });
})();
