(() => {
    const riskData = [
        { label: 'Presença', value: 84 }, { label: 'Apoio', value: 72 },
        { label: 'Materiais', value: 61 }, { label: 'Transporte', value: 48 },
        { label: 'Conexão', value: 78 }
    ];
    const renderBars = () => {
        const chart = document.querySelector('#riskChart');
        if (!chart) return;
        chart.innerHTML = riskData.map(item => `<div class="chart-bar" title="${item.value}%"><i style="height:${item.value}%"></i><b>${item.value}%</b><small>${item.label}</small></div>`).join('');
    };
    const setupImpact = () => {
        const form = document.querySelector('#impactForm');
        const result = document.querySelector('#impactResult');
        if (!form || !result) return;
        const calculate = () => {
            const values = Object.fromEntries(new FormData(form));
            const students = Math.max(1, Number(values.students) || 10);
            const monthly = Math.max(0, Number(values.monthly) || 200);
            const months = Math.max(1, Number(values.months) || 10);
            const investment = students * monthly * months;
            const avoided = Math.round(investment * 3.8);
            const benefit = Math.max(0, avoided - investment);
            result.innerHTML = `<strong>R$ ${avoided.toLocaleString('pt-BR')}</strong><p>Impacto estimado protegido em um ano para ${students} aluno(s). Um investimento de R$ ${investment.toLocaleString('pt-BR')} pode evitar cerca de R$ ${benefit.toLocaleString('pt-BR')} em custo social e pedagógico associado à interrupção da trajetória.</p>`;
        };
        form.addEventListener('submit', event => { event.preventDefault(); calculate(); });
        calculate();
    };
    const setupDark = () => {
        const body = document.body;
        const stored = JSON.parse(localStorage.getItem('salve-theme') || 'null');
        if (stored === 'dark') body.classList.add('dark-mode');
        let button = document.querySelector('#themeToggle');
        if (!button) {
            button = document.createElement('button'); button.id = 'themeToggle'; button.className = 'theme-toggle'; button.type = 'button'; button.setAttribute('aria-label', 'Alternar modo claro e escuro'); button.textContent = body.classList.contains('dark-mode') ? '☀' : '◐';
            document.querySelector('.role-topbar')?.appendChild(button);
        }
        button.addEventListener('click', () => { const dark = body.classList.toggle('dark-mode'); localStorage.setItem('salve-theme', dark ? 'dark' : 'light'); button.textContent = dark ? '☀' : '◐'; });
    };
    const setupTeamDiagnostic = async () => {
        const mount = document.querySelector('#teamDiagnostic');
        if (!mount || !window.SalveDatabase) return;
        try {
            const data = await SalveDatabase.request('diagnostico-perguntas');
            mount.innerHTML = `<p>${data.notice}</p><form id="teamDiagnosticForm">${data.questions.map(question => `<fieldset><legend>${question.question}</legend>${question.options.map(option => `<label><input type="radio" name="${question.key}" value="${option.value}" required>${option.label}</label>`).join('')}</fieldset>`).join('')}<button class="role-button" type="submit">Salvar leitura da rede</button></form><div class="team-diagnostic-result" id="teamDiagnosticResult"></div>`;
            mount.querySelector('form').addEventListener('submit', async event => {
                event.preventDefault(); const answers = Object.fromEntries([...new FormData(event.currentTarget)].map(([key, value]) => [key, Number(value)])); const result = mount.querySelector('#teamDiagnosticResult');
                try { const response = await SalveDatabase.request('diagnostico-enviar', { method: 'POST', data: { answers } }); result.textContent = `${response.diagnostic.title}. ${response.diagnostic.summary} ${response.diagnostic.disclaimer}`; } catch (error) { result.textContent = error.message; }
            });
        } catch (error) { mount.innerHTML = `<p>${error.message}</p>`; }
    };
    document.addEventListener('DOMContentLoaded', () => { renderBars(); setupImpact(); setupDark(); setupTeamDiagnostic(); });
})();
