(() => {
    const unsplash = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=900&q=80`;
    const categoryImages = {
        roupas: {
            default: unsplash('photo-1553062407-98eeb64c6a62'),
            matches: [
                { terms: ['agasalh', 'casaco', 'blusa'], image: unsplash('photo-1556821840-3a63f95609a7') }
            ]
        },
        uniformes: { default: unsplash('photo-1580582932707-520aed937b7b') },
        materiais: {
            default: unsplash('photo-1513542789411-b6a5d4f31634'),
            matches: [{ terms: ['kit'], image: unsplash('photo-1452860606245-08befc0ff44b') }]
        },
        tecnologia: {
            default: unsplash('photo-1496181133206-80ce9b88a853'),
            matches: [{ terms: ['calculador'], image: unsplash('photo-1587145820266-a5951ee96835') }]
        },
        livros: {
            default: unsplash('photo-1512820790803-83ca734da794'),
            matches: [{ terms: ['didatic'], image: unsplash('photo-1497633762265-9d179a990aa6') }]
        },
        calcados: { default: 'assets/images/doacao-roupas.jpg' },
        outros: { default: unsplash('photo-1452860606245-08befc0ff44b') },
        alimentacao: { default: 'assets/images/salve-hero.jpg' },
        transporte: { default: 'assets/images/salve-hero.jpg' }
    };
    const genericImages = new Set([
        'assets/images/doacao-materiais.jpg',
        'assets/images/doacao-roupas.jpg',
        'assets/images/salve-hero.jpg'
    ]);
    const localFallbacks = {
        roupas: 'assets/images/doacao-roupas.jpg',
        uniformes: 'assets/images/doacao-roupas.jpg',
        calcados: 'assets/images/doacao-roupas.jpg',
        alimentacao: 'assets/images/salve-hero.jpg',
        transporte: 'assets/images/salve-hero.jpg'
    };
    const normalized = (value) => String(value || '').toLocaleLowerCase('pt-BR')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const forCategory = (category, title = '') => {
        const entry = categoryImages[category] || categoryImages.outros;
        const name = normalized(title);
        const matched = (entry.matches || []).find((candidate) =>
            candidate.terms.some((term) => name.includes(term)));
        return matched?.image || entry.default;
    };
    const isIllustrative = (source) => !source || source.startsWith('https://images.unsplash.com/') ||
        genericImages.has(source);
    const forItem = (item) => isIllustrative(item.imagePath)
        ? forCategory(item.categorySlug, item.title)
        : item.imagePath;
    const localFallback = (category) => localFallbacks[category] || 'assets/images/doacao-materiais.jpg';
    const applyLocalFallback = (image, category) => {
        image.dataset.localFallbackApplied = 'false';
        image.onerror = () => {
            if (image.dataset.localFallbackApplied === 'true') return;
            image.dataset.localFallbackApplied = 'true';
            image.src = localFallback(category);
        };
    };
    window.SolidarityImages = Object.freeze({ forCategory, forItem, isIllustrative, localFallback, applyLocalFallback });
})();
