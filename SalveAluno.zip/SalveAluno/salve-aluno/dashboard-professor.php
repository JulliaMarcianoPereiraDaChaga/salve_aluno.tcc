<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Painel do professor Salve Aluno">
	<title>Painel do Professor | Salve Aluno</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/role-dashboards.css"><link rel="stylesheet" href="css/insights.css"><link rel="stylesheet" href="css/brand-theme.css">
	<link rel="stylesheet" href="css/meetings.css">
</head>
<body class="role-app" data-required-role="professor">
	<header class="role-topbar">
		<a class="role-brand" href="index.php"><span class="role-mark">S</span>salve.aluno</a>
		<div class="role-user">
			<div><strong id="professorName">Professor</strong><small>Rede pedagógica</small></div>
			<button type="button" onclick="logout()">Sair</button>
		</div>
	</header>
	<main class="role-main">
		<div class="role-heading">
			<div>
				<p class="eyebrow">Acompanhamento pedagógico</p>
				<h1>Painel do professor</h1>
				<p>Observe sua turma, registre sinais e conecte cada estudante ao apoio certo.</p>
			</div>
			<div class="role-actions"><button class="role-button alt" type="button" id="newReferral">Novo encaminhamento</button></div>
		</div>
		<section class="role-grid">
			<article class="role-stat"><span>Turmas acompanhadas</span><strong>03</strong><span class="trend">95 alunos vinculados</span></article>
			<article class="role-stat"><span>Estudantes em atenção</span><strong>08</strong><span class="status high">Acompanhar hoje</span></article>
			<article class="role-stat"><span>Check-ins da semana</span><strong>76%</strong><span class="trend">+8% desde a semana passada</span></article>
			<article class="role-stat"><span>Encaminhamentos</span><strong>04</strong><span class="trend">3 em andamento</span></article>
		</section>
		<div class="insight-grid"><article class="insight-card"><h2>Ritmo da turma</h2><p>Indicadores coloridos para localizar rapidamente quedas de presença, engajamento e encaminhamentos.</p><div id="riskChart" class="chart-bars"></div><div class="legend-row"><span>Presença e apoio</span><span>Necessidades materiais</span><span>Conexão da rede</span></div></article><article class="insight-card"><h2>Próximo passo</h2><p>Quando um sinal aparece, combine uma conversa, um encaminhamento e uma data de retorno.</p><div class="role-notice"><span>✦</span><div><strong>Priorize os 8 estudantes em atenção</strong><p>Comece pelos casos com faltas recorrentes e verifique se existe uma barreira material no caminho.</p></div></div></article></div>
        <section class="role-card diagnostic-team"><h2>Check-in do professor</h2><p>O quiz ajuda a registrar como está sua capacidade de acolher e encaminhar a turma.</p><div id="teamDiagnostic"></div></section>
		<div class="role-columns">
			<section class="role-card">
				<h2>Minhas turmas</h2>
				<p>Engajamento e sinais recentes por turma.</p>
				<div id="myClasses" class="role-list"></div>
			</section>
			<section class="role-card">
				<h2>Estudantes em atenção</h2>
				<p>Priorize uma conversa ou encaminhamento.</p>
				<div class="role-filter"><input id="studentSearch" type="search" placeholder="Buscar estudante ou turma"></div>
				<div id="attentionStudents" class="role-list"></div>
			</section>
			<section class="role-card">
				<h2>Encaminhamentos pedagógicos</h2>
				<p>Acompanhe os próximos passos combinados.</p>
				<div id="pedagogicalReferrals" class="role-list"></div>
			</section>
			<section class="role-card" data-meetings-view="teacher">
				<h2>Reuniões agendadas</h2>
				<p>Informe seu nome para confirmar sua participação.</p>
				<p class="meeting-storage-note">As reuniões e confirmações ficam salvas no banco de dados da escola.</p>
				<p class="meeting-message" data-meetings-message aria-live="polite"></p>
				<div class="meeting-list" data-meetings-list aria-live="polite"></div>
			</section>
			<section class="role-card">
				<h2>Próxima ação</h2>
				<p>Uma pequena atualização mantém a rede conectada.</p>
				<div class="role-notice">
					<span>✦</span>
					<div><strong>Registrar um check-in</strong><p>Compartilhe como sua turma está hoje e ajude a equipe a perceber mudanças cedo.</p><button class="role-button" type="button" id="classCheckIn">Registrar check-in</button></div>
				</div>
			</section>
		</div>
	</main>
	<div class="modal-backdrop" id="referralModal" hidden>
		<form class="role-modal" id="referralForm">
			<header><h2>Novo encaminhamento</h2><button class="role-modal-close" type="button" data-close-modal>×</button></header>
			<label>Estudante<input required placeholder="Nome do estudante"></label>
			<label>Motivo<select required><option value="">Selecione</option><option>Faltas ou queda de rendimento</option><option>Apoio emocional</option><option>Necessidade socioeconômica</option></select></label>
			<label>Observação<textarea rows="4" required placeholder="Registre o contexto essencial para a rede"></textarea></label>
			<button class="role-button" type="submit">Salvar encaminhamento</button>
			<p id="referralMessage"></p>
		</form>
	</div>
	<script src="js/api-client.js"></script>
	<script src="js/login.js"></script>
	<script src="js/reunioes.js"></script>
	<script src="js/dashboard-professor.js"></script>
<script src="js/buttons.js"></script><script src="js/insights.js"></script>
</body>
</html>
