USE salve_aluno_apoio;

INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
    ('roupas', 'Roupas', 'Roupas limpas e em bom estado.'),
    ('uniformes', 'Uniformes', 'Uniformes escolares em bom estado.'),
    ('livros', 'Livros', 'Livros didáticos e materiais de leitura.'),
    ('calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.'),
    ('outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao), ativa = 1;

INSERT INTO categorias_beneficios (nome, slug, descricao) VALUES
    ('Roupas', 'roupas', 'Roupas limpas e em bom estado.'),
    ('Uniformes', 'uniformes', 'Uniformes escolares em bom estado.'),
    ('Livros', 'livros', 'Livros didáticos e materiais de leitura.'),
    ('Calçados', 'calcados', 'Calçados em bom estado para o dia a dia.'),
    ('Outros', 'outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao);
