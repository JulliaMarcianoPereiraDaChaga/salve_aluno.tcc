-- Salve Aluno — banco relacional completo
-- Banco novo: salve_aluno_apoio
-- Importe este arquivo em uma instalação nova. O schema.sql continua disponível para compatibilidade legada.

CREATE DATABASE IF NOT EXISTS salve_aluno_apoio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE salve_aluno_apoio;

CREATE TABLE IF NOT EXISTS perfis (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    codigo VARCHAR(30) NOT NULL,
    nome VARCHAR(80) NOT NULL,
    descricao VARCHAR(255) NOT NULL DEFAULT '',
    permite_diagnostico TINYINT(1) NOT NULL DEFAULT 1,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY perfis_codigo_unico (codigo)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS escolas (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(160) NOT NULL,
    codigo VARCHAR(64) NOT NULL,
    cnpj VARCHAR(18) NULL,
    email VARCHAR(254) NOT NULL DEFAULT '',
    telefone VARCHAR(40) NOT NULL DEFAULT '',
    endereco VARCHAR(255) NOT NULL DEFAULT '',
    cidade VARCHAR(100) NOT NULL DEFAULT '',
    estado CHAR(2) NOT NULL DEFAULT '',
    turno_principal VARCHAR(30) NOT NULL DEFAULT '',
    ativa TINYINT(1) NOT NULL DEFAULT 1,
    criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizada_em TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY escolas_codigo_unico (codigo)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NULL,
    perfil_id SMALLINT UNSIGNED NULL,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    profile VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    details_json LONGTEXT NOT NULL,
    quiz_json LONGTEXT NOT NULL,
    preferences_json LONGTEXT NOT NULL,
    school_key VARCHAR(64) NOT NULL DEFAULT 'escola-municipal',
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    ultimo_login_em DATETIME NULL,
    created_at VARCHAR(35) NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY usuarios_email_unico (email),
    KEY usuarios_escola_perfil (escola_id, perfil_id),
    CONSTRAINT usuarios_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT usuarios_perfil_fk FOREIGN KEY (perfil_id) REFERENCES perfis (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alunos (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id BIGINT UNSIGNED NOT NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    matricula VARCHAR(40) NOT NULL DEFAULT '',
    turma VARCHAR(60) NOT NULL DEFAULT '',
    serie VARCHAR(40) NOT NULL DEFAULT '',
    turno VARCHAR(30) NOT NULL DEFAULT '',
    data_nascimento DATE NULL,
    possui_deficiencia TINYINT(1) NOT NULL DEFAULT 0,
    necessidades_acessibilidade VARCHAR(500) NOT NULL DEFAULT '',
    responsavel_nome VARCHAR(120) NOT NULL DEFAULT '',
    responsavel_contato VARCHAR(120) NOT NULL DEFAULT '',
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY alunos_usuario_unico (usuario_id), KEY alunos_escola_turma (escola_id, turma),
    CONSTRAINT alunos_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT alunos_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS professores (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id BIGINT UNSIGNED NOT NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    registro_profissional VARCHAR(60) NOT NULL DEFAULT '',
    area_atuacao VARCHAR(120) NOT NULL DEFAULT '',
    turmas_json LONGTEXT NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY professores_usuario_unico (usuario_id),
    CONSTRAINT professores_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT professores_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS assistentes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id BIGINT UNSIGNED NOT NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    registro_profissional VARCHAR(60) NOT NULL DEFAULT '',
    especialidade VARCHAR(120) NOT NULL DEFAULT '',
    territorio_atendimento VARCHAR(255) NOT NULL DEFAULT '',
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY assistentes_usuario_unico (usuario_id),
    CONSTRAINT assistentes_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT assistentes_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias_beneficios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    slug VARCHAR(60) NOT NULL,
    descricao VARCHAR(255) NOT NULL DEFAULT '',
    ativa TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id), UNIQUE KEY categorias_beneficios_slug_unico (slug)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS beneficios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    categoria_id BIGINT UNSIGNED NOT NULL,
    titulo VARCHAR(160) NOT NULL,
    descricao TEXT NOT NULL,
    tipo VARCHAR(40) NOT NULL DEFAULT 'doacao',
    quantidade_total INT UNSIGNED NOT NULL DEFAULT 0,
    quantidade_disponivel INT UNSIGNED NOT NULL DEFAULT 0,
    valor_referencia DECIMAL(10,2) NULL,
    imagem VARCHAR(255) NOT NULL DEFAULT '',
    tamanho VARCHAR(80) NOT NULL DEFAULT '',
    status ENUM('disponivel','esgotado','arquivado') NOT NULL DEFAULT 'disponivel',
    criado_por BIGINT UNSIGNED NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY beneficios_escola_status (escola_id, status),
    CONSTRAINT beneficios_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT beneficios_categoria_fk FOREIGN KEY (categoria_id) REFERENCES categorias_beneficios (id),
    CONSTRAINT beneficios_criador_fk FOREIGN KEY (criado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS solicitacoes (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    aluno_id BIGINT UNSIGNED NOT NULL,
    beneficio_id BIGINT UNSIGNED NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    categoria VARCHAR(80) NOT NULL,
    descricao TEXT NOT NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 1,
    data_preferencial DATE NULL,
    prioridade ENUM('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
    status ENUM('recebida','em_analise','aprovada','recusada','entregue','cancelada') NOT NULL DEFAULT 'recebida',
    analisada_por BIGINT UNSIGNED NULL,
    criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    analisada_em DATETIME NULL,
    concluida_em DATETIME NULL,
    PRIMARY KEY (id), KEY solicitacoes_aluno_status (aluno_id, status), KEY solicitacoes_escola_status (escola_id, status),
    CONSTRAINT solicitacoes_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT solicitacoes_beneficio_fk FOREIGN KEY (beneficio_id) REFERENCES beneficios (id),
    CONSTRAINT solicitacoes_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT solicitacoes_analisada_por_fk FOREIGN KEY (analisada_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anexos_solicitacoes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    solicitacao_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    nome_original VARCHAR(255) NOT NULL,
    mime_type VARCHAR(120) NOT NULL,
    caminho_armazenamento VARCHAR(500) NOT NULL,
    tamanho_bytes INT UNSIGNED NOT NULL,
    enviado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), CONSTRAINT anexos_solicitacoes_fk FOREIGN KEY (solicitacao_id) REFERENCES solicitacoes (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS diagnosticos (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    aluno_id BIGINT UNSIGNED NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    perfil_codigo VARCHAR(30) NOT NULL,
    score SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    nivel_atencao ENUM('estavel','acompanhar','prioritario') NOT NULL,
    resumo VARCHAR(500) NOT NULL,
    respondido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY diagnosticos_usuario_data (usuario_id, respondido_em), KEY diagnosticos_escola_nivel (escola_id, nivel_atencao),
    CONSTRAINT diagnosticos_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT diagnosticos_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT diagnosticos_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS respostas_diagnostico (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    diagnostico_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    chave_pergunta VARCHAR(60) NOT NULL,
    pergunta VARCHAR(255) NOT NULL,
    valor TINYINT UNSIGNED NOT NULL,
    resposta VARCHAR(255) NOT NULL,
    respondida_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY respostas_diagnostico_unico (diagnostico_id, chave_pergunta),
    CONSTRAINT respostas_diagnostico_fk FOREIGN KEY (diagnostico_id) REFERENCES diagnosticos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alertas (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    aluno_id BIGINT UNSIGNED NULL,
    diagnostico_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NULL,
    tipo VARCHAR(50) NOT NULL,
    titulo VARCHAR(160) NOT NULL,
    mensagem TEXT NOT NULL,
    severidade ENUM('informativo','atencao','alto','urgente') NOT NULL DEFAULT 'informativo',
    lido_em DATETIME NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY alertas_escola_severidade (escola_id, severidade, criado_em),
    CONSTRAINT alertas_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT alertas_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT alertas_diagnostico_fk FOREIGN KEY (diagnostico_id) REFERENCES diagnosticos (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mensagens_canal_seguro (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    escola_id BIGINT UNSIGNED NOT NULL,
    remetente_usuario_id BIGINT UNSIGNED NOT NULL,
    aluno_id BIGINT UNSIGNED NULL,
    destinatario_usuario_id BIGINT UNSIGNED NULL,
    anonima TINYINT(1) NOT NULL DEFAULT 0,
    assunto VARCHAR(160) NOT NULL DEFAULT '',
    mensagem TEXT NOT NULL,
    criptografada TINYINT(1) NOT NULL DEFAULT 0,
    lida_em DATETIME NULL,
    enviada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY mensagens_escola_data (escola_id, enviada_em),
    CONSTRAINT mensagens_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT mensagens_remetente_fk FOREIGN KEY (remetente_usuario_id) REFERENCES usuarios (id),
    CONSTRAINT mensagens_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT mensagens_destinatario_fk FOREIGN KEY (destinatario_usuario_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS atendimentos (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    aluno_id BIGINT UNSIGNED NOT NULL,
    assistente_id BIGINT UNSIGNED NULL,
    criado_por BIGINT UNSIGNED NOT NULL,
    tipo VARCHAR(60) NOT NULL,
    motivo VARCHAR(255) NOT NULL DEFAULT '',
    observacoes TEXT NOT NULL,
    inicio DATETIME NOT NULL,
    fim DATETIME NULL,
    status ENUM('agendado','em_atendimento','concluido','cancelado','faltou') NOT NULL DEFAULT 'agendado',
    encaminhamento_necessario TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY atendimentos_escola_data (escola_id, inicio), KEY atendimentos_aluno_status (aluno_id, status),
    CONSTRAINT atendimentos_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT atendimentos_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT atendimentos_assistente_fk FOREIGN KEY (assistente_id) REFERENCES assistentes (id),
    CONSTRAINT atendimentos_criador_fk FOREIGN KEY (criado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS checkins (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    professor_id BIGINT UNSIGNED NOT NULL,
    turma VARCHAR(60) NOT NULL,
    clima ENUM('bem','estavel','atencao','critico') NOT NULL,
    participacao TINYINT UNSIGNED NOT NULL DEFAULT 0,
    presenca TINYINT UNSIGNED NOT NULL DEFAULT 0,
    observacao VARCHAR(1000) NOT NULL DEFAULT '',
    realizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY checkins_escola_turma_data (escola_id, turma, realizado_em),
    CONSTRAINT checkins_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT checkins_professor_fk FOREIGN KEY (professor_id) REFERENCES professores (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS encaminhamentos (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    aluno_id BIGINT UNSIGNED NOT NULL,
    criado_por BIGINT UNSIGNED NOT NULL,
    destino VARCHAR(100) NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    observacao TEXT NOT NULL,
    prioridade ENUM('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
    status ENUM('aberto','em_acompanhamento','resolvido','cancelado') NOT NULL DEFAULT 'aberto',
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    concluido_em DATETIME NULL,
    PRIMARY KEY (id), KEY encaminhamentos_aluno_status (aluno_id, status),
    CONSTRAINT encaminhamentos_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT encaminhamentos_aluno_fk FOREIGN KEY (aluno_id) REFERENCES alunos (id),
    CONSTRAINT encaminhamentos_criador_fk FOREIGN KEY (criado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS oportunidades (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NULL,
    titulo VARCHAR(180) NOT NULL,
    tipo ENUM('curso','jovem_aprendiz','bico','biblioteca','telecentro','maker','outro') NOT NULL,
    descricao TEXT NOT NULL,
    organizacao VARCHAR(160) NOT NULL DEFAULT '',
    endereco VARCHAR(255) NOT NULL DEFAULT '',
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    distancia_escola_km DECIMAL(6,2) NULL,
    turno VARCHAR(40) NOT NULL DEFAULT '',
    bolsa DECIMAL(10,2) NULL,
    gratuita TINYINT(1) NOT NULL DEFAULT 0,
    acessivel TINYINT(1) NOT NULL DEFAULT 0,
    turno_inverso TINYINT(1) NOT NULL DEFAULT 0,
    ativa TINYINT(1) NOT NULL DEFAULT 1,
    criada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY oportunidades_tipo_turno (tipo, turno, ativa),
    CONSTRAINT oportunidades_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS seguranca_oportunidades (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    oportunidade_id BIGINT UNSIGNED NOT NULL,
    iluminacao_nivel ENUM('nao_informado','baixo','medio','alto') NOT NULL DEFAULT 'nao_informado',
    rota_segura TINYINT(1) NOT NULL DEFAULT 0,
    transporte_proximo TINYINT(1) NOT NULL DEFAULT 0,
    paradas_proximas VARCHAR(255) NOT NULL DEFAULT '',
    relatos_comunidade INT UNSIGNED NOT NULL DEFAULT 0,
    atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id), UNIQUE KEY seguranca_oportunidade_unica (oportunidade_id),
    CONSTRAINT seguranca_oportunidades_fk FOREIGN KEY (oportunidade_id) REFERENCES oportunidades (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS acessibilidade_oportunidades (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    oportunidade_id BIGINT UNSIGNED NOT NULL,
    possui_rampa TINYINT(1) NOT NULL DEFAULT 0,
    banheiro_adaptado TINYINT(1) NOT NULL DEFAULT 0,
    atendimento_prioritario TINYINT(1) NOT NULL DEFAULT 0,
    libras TINYINT(1) NOT NULL DEFAULT 0,
    descricao VARCHAR(500) NOT NULL DEFAULT '',
    PRIMARY KEY (id), UNIQUE KEY acessibilidade_oportunidade_unica (oportunidade_id),
    CONSTRAINT acessibilidade_oportunidades_fk FOREIGN KEY (oportunidade_id) REFERENCES oportunidades (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS comunicados (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    escola_id BIGINT UNSIGNED NOT NULL,
    publicado_por BIGINT UNSIGNED NOT NULL,
    titulo VARCHAR(180) NOT NULL,
    mensagem TEXT NOT NULL,
    publico VARCHAR(30) NOT NULL DEFAULT 'todos',
    publicado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expira_em DATETIME NULL,
    PRIMARY KEY (id), KEY comunicados_escola_data (escola_id, publicado_em),
    CONSTRAINT comunicados_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id),
    CONSTRAINT comunicados_autor_fk FOREIGN KEY (publicado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS consentimentos_lgpd (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id BIGINT UNSIGNED NOT NULL,
    finalidade VARCHAR(100) NOT NULL,
    versao_politica VARCHAR(30) NOT NULL,
    consentiu TINYINT(1) NOT NULL,
    origem VARCHAR(80) NOT NULL DEFAULT 'aplicacao',
    ip_hash CHAR(64) NULL,
    consentido_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revogado_em DATETIME NULL,
    PRIMARY KEY (id), KEY consentimentos_usuario_finalidade (usuario_id, finalidade),
    CONSTRAINT consentimentos_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS auditoria_lgpd (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id BIGINT UNSIGNED NULL,
    escola_id BIGINT UNSIGNED NULL,
    acao VARCHAR(80) NOT NULL,
    entidade VARCHAR(80) NOT NULL,
    entidade_id VARCHAR(64) NOT NULL DEFAULT '',
    finalidade VARCHAR(120) NOT NULL DEFAULT '',
    dados_minimizados_json JSON NULL,
    ip_hash CHAR(64) NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id), KEY auditoria_entidade_data (entidade, entidade_id, criado_em), KEY auditoria_usuario_data (usuario_id, criado_em),
    CONSTRAINT auditoria_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL,
    CONSTRAINT auditoria_escola_fk FOREIGN KEY (escola_id) REFERENCES escolas (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessoes_usuario (
    id CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    usuario_id BIGINT UNSIGNED NOT NULL,
    csrf_hash CHAR(64) NOT NULL,
    ultimo_acesso_em DATETIME NOT NULL,
    expira_em DATETIME NOT NULL,
    revogada_em DATETIME NULL,
    PRIMARY KEY (id), KEY sessoes_usuario_fk (usuario_id),
    CONSTRAINT sessoes_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS limites_tentativa (
    rate_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    attempts INT UNSIGNED NOT NULL,
    window_started BIGINT NOT NULL,
    PRIMARY KEY (rate_key)
) ENGINE=InnoDB;

-- Compatibilidade com a API atual do projeto.
CREATE TABLE IF NOT EXISTS registros (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type VARCHAR(40) NOT NULL,
    data_json LONGTEXT NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id), KEY registros_usuario_tipo_data (user_id, type, created_at),
    CONSTRAINT registros_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS arquivos_registro (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    record_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    content MEDIUMBLOB NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id), CONSTRAINT arquivos_registro_fk FOREIGN KEY (record_id) REFERENCES registros (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reunioes (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    meeting_date VARCHAR(64) NOT NULL,
    cancelled TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    cancelled_at VARCHAR(35) NULL,
    PRIMARY KEY (id), KEY reunioes_escola_data (school_key, meeting_date), CONSTRAINT reunioes_criador_fk FOREIGN KEY (created_by) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS participantes_reuniao (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    participant_name VARCHAR(120) NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id), CONSTRAINT participantes_reuniao_reuniao_fk FOREIGN KEY (meeting_id) REFERENCES reunioes (id) ON DELETE CASCADE, CONSTRAINT participantes_reuniao_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS encerramentos_reuniao (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    closed_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id), CONSTRAINT encerramentos_reuniao_reuniao_fk FOREIGN KEY (meeting_id) REFERENCES reunioes (id) ON DELETE CASCADE, CONSTRAINT encerramentos_reuniao_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias_auxilio (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug VARCHAR(48) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(240) NOT NULL DEFAULT '',
    ativa TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id), UNIQUE KEY categorias_auxilio_slug_unico (slug)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS itens_solidarios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    categoria_id BIGINT UNSIGNED NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    titulo VARCHAR(160) NOT NULL,
    descricao TEXT NOT NULL,
    tamanho VARCHAR(80) NOT NULL DEFAULT '',
    condicao VARCHAR(80) NOT NULL DEFAULT 'Novo ou em ótimo estado',
    quantidade_total INT UNSIGNED NOT NULL,
    quantidade_disponivel INT UNSIGNED NOT NULL,
    caminho_imagem VARCHAR(255) NOT NULL DEFAULT '',
    tipo VARCHAR(20) NOT NULL DEFAULT 'doacao',
    doador VARCHAR(120) NOT NULL DEFAULT 'Anônimo',
    data_doacao VARCHAR(10) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'disponivel',
    chave_seed VARCHAR(60) NULL,
    criado_por BIGINT UNSIGNED NOT NULL,
    criado_em VARCHAR(35) NOT NULL,
    atualizado_em VARCHAR(35) NULL,
    PRIMARY KEY (id), UNIQUE KEY itens_solidarios_seed_escola (school_key, chave_seed),
    CONSTRAINT itens_solidarios_categoria_fk FOREIGN KEY (categoria_id) REFERENCES categorias_auxilio (id), CONSTRAINT itens_solidarios_criador_fk FOREIGN KEY (criado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS solicitacoes_auxilio (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    item_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 1,
    observacao VARCHAR(1000) NOT NULL DEFAULT '',
    tipo VARCHAR(20) NOT NULL DEFAULT 'doacao',
    prazo_devolucao VARCHAR(10) NULL,
    data_retirada VARCHAR(10) NULL,
    precisa_busca TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'pendente',
    requested_at VARCHAR(35) NOT NULL,
    reviewed_at VARCHAR(35) NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    delivered_at VARCHAR(35) NULL,
    received_at VARCHAR(35) NULL,
    returned_at VARCHAR(35) NULL,
    PRIMARY KEY (id), KEY solicitacoes_auxilio_aluno_data (user_id, requested_at),
    CONSTRAINT solicitacoes_auxilio_item_fk FOREIGN KEY (item_id) REFERENCES itens_solidarios (id), CONSTRAINT solicitacoes_auxilio_aluno_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE, CONSTRAINT solicitacoes_auxilio_revisor_fk FOREIGN KEY (reviewed_by) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notificacoes_solidarias (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    mensagem VARCHAR(500) NOT NULL,
    tipo VARCHAR(32) NOT NULL,
    criada_em VARCHAR(35) NOT NULL,
    lida_em VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY notificacoes_solidarias_usuario_data (user_id, criada_em),
    CONSTRAINT notificacoes_solidarias_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS movimentacoes_auxilio (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    item_id BIGINT UNSIGNED NOT NULL,
    solicitacao_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    tipo_movimentacao VARCHAR(32) NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    observacao VARCHAR(500) NOT NULL DEFAULT '',
    criado_em VARCHAR(35) NOT NULL,
    PRIMARY KEY (id), CONSTRAINT movimentacoes_auxilio_item_fk FOREIGN KEY (item_id) REFERENCES itens_solidarios (id), CONSTRAINT movimentacoes_auxilio_solicitacao_fk FOREIGN KEY (solicitacao_id) REFERENCES solicitacoes_auxilio (id) ON DELETE SET NULL, CONSTRAINT movimentacoes_auxilio_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

INSERT INTO perfis (codigo, nome, descricao, permite_diagnostico) VALUES
('admin','Administrador','Administração técnica e de acessos',0),
('aluno','Aluno','Estudante da escola',1),
('professor','Professor','Professor ou educador',1),
('escola','Gestão escolar','Gestão e coordenação da escola',1),
('assistente','Assistente social','Acompanhamento e rede de proteção',1)
ON DUPLICATE KEY UPDATE nome=VALUES(nome), descricao=VALUES(descricao), permite_diagnostico=VALUES(permite_diagnostico);

INSERT INTO escolas (nome, codigo, email, cidade, estado, turno_principal) VALUES
('Escola Municipal','escola-municipal','','','','manhã e tarde')
ON DUPLICATE KEY UPDATE nome=VALUES(nome), turno_principal=VALUES(turno_principal);

INSERT INTO categorias_beneficios (nome, slug, descricao) VALUES
('Materiais escolares','materiais','Cadernos, mochilas e itens para estudar.'),
('Roupas','roupas','Roupas em bom estado.'),
('Uniformes','uniformes','Uniformes escolares em bom estado.'),
('Livros','livros','Livros didáticos e materiais de leitura.'),
('Calçados','calcados','Calçados em bom estado para o dia a dia.'),
('Outros','outros','Outros recursos para apoiar a permanência estudantil.'),
('Tecnologia','tecnologia','Equipamentos e conectividade.'),
('Alimentação e higiene','alimentacao','Itens essenciais para a rotina escolar.'),
('Transporte','transporte','Apoio para deslocamento e permanência.')
ON DUPLICATE KEY UPDATE nome=VALUES(nome), descricao=VALUES(descricao);

INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
('materiais','Materiais escolares','Cadernos, mochilas e itens para estudar.'),
('roupas','Roupas','Roupas em bom estado.'),
('uniformes','Uniformes','Uniformes escolares em bom estado.'),
('livros','Livros','Livros didáticos e materiais de leitura.'),
('calcados','Calçados','Calçados em bom estado para o dia a dia.'),
('outros','Outros','Outros recursos para apoiar a permanência estudantil.'),
('tecnologia','Tecnologia','Equipamentos e conectividade.'),
('alimentacao','Alimentação e higiene','Itens essenciais para a rotina escolar.'),
('transporte','Transporte','Apoio para deslocamento e permanência.')
ON DUPLICATE KEY UPDATE nome=VALUES(nome), descricao=VALUES(descricao);

CREATE OR REPLACE VIEW vw_resumo_risco_escolar AS
SELECT d.escola_id, d.nivel_atencao, COUNT(*) AS total_diagnosticos, MAX(d.respondido_em) AS ultimo_diagnostico
FROM diagnosticos d GROUP BY d.escola_id, d.nivel_atencao;

CREATE OR REPLACE VIEW vw_oportunidades_seguras AS
SELECT o.*, s.iluminacao_nivel, s.rota_segura, s.transporte_proximo,
       a.possui_rampa, a.banheiro_adaptado, a.atendimento_prioritario
FROM oportunidades o
LEFT JOIN seguranca_oportunidades s ON s.oportunidade_id = o.id
LEFT JOIN acessibilidade_oportunidades a ON a.oportunidade_id = o.id
WHERE o.ativa = 1;
