-- Migração de uma instalação existente do esquema anterior.
-- Execute uma única vez APENAS quando as tabelas originais em inglês existirem.
-- Faça backup do banco antes de executar. Em uma instalação nova, importe apenas schema.sql.
RENAME TABLE
    users TO usuarios,
    registration_requests TO solicitacoes_cadastro,
    records TO registros,
    record_files TO arquivos_registro,
    meetings TO reunioes,
    meeting_participants TO participantes_reuniao,
    meeting_closures TO encerramentos_reuniao,
    secure_messages TO mensagens_seguras,
    rate_limits TO limites_tentativa;
