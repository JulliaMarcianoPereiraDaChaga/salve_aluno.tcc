USE salve_aluno;

INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
    ('roupas', 'Roupas', 'Roupas limpas e em bom estado.'),
    ('uniformes', 'Uniformes', 'Uniformes escolares em bom estado.'),
    ('livros', 'Livros', 'Livros didáticos e materiais de leitura.'),
    ('calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.'),
    ('outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao), ativa = 1;
