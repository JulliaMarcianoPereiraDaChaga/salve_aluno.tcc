# Implementação manual do banco no phpMyAdmin

Este projeto usa o banco `salve_aluno_apoio`. O arquivo `config/database.php` do ZIP já está configurado com esse nome como padrão.

## 1. Faça backup do banco antigo

No phpMyAdmin, selecione qualquer banco existente do Salve Aluno, abra **Exportar**, escolha **Rápido**, formato **SQL** e clique em **Exportar**. Guarde o arquivo antes de criar o banco novo.

## 2. Crie o banco novo

1. Acesse `http://localhost/phpmyadmin`.
2. Clique em **Novo** no menu esquerdo.
3. Em **Criar banco de dados**, digite `salve_aluno_apoio`.
4. Escolha `utf8mb4_unicode_ci` como agrupamento, se aparecer.
5. Clique em **Criar**.

Não use `salve_aluno` nesta instalação nova. O PHP deste ZIP está configurado para `salve_aluno_apoio`.

## 3. Importe as tabelas

1. Clique no banco `salve_aluno_apoio` no menu esquerdo.
2. Abra a aba **Importar**.
3. Clique em **Escolher arquivo**.
4. Selecione `database/schema-relacional.sql` dentro do projeto.
5. Mantenha o formato SQL.
6. Clique em **Importar**.

O arquivo cria as tabelas relacionais, as tabelas de compatibilidade, os perfis, a escola padrão, as categorias de benefícios e as categorias do Banco Solidário. A versão deste ZIP possui 34 tabelas principais/auxiliares e views de resumo.

Se o phpMyAdmin informar que o banco já existe, isso não é problema. Se informar que uma tabela já existe, não apague a tabela automaticamente: confira antes se está usando o banco correto.

## 4. Cadastre os usuários

1. Continue dentro de `salve_aluno_apoio`.
2. Abra **Importar** novamente.
3. Selecione `database/cadastro-usuarios-manual.sql`.
4. Clique em **Importar**.

Esse arquivo cadastra ou atualiza estas contas:

| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | `admin@salvealuno.local` | `Admin@2026!` |
| Aluno | `aluno@escola.edu.br` | `Aluno@2026!` |
| Professor | `professor@escola.edu.br` | `Professor@2026!` |
| Gestão | `gestao@escola.edu.br` | `Gestao@2026!` |
| Assistente | `assistente@escola.edu.br` | `Assistente@2026!` |

As senhas estão armazenadas com hash bcrypt. Não substitua o conteúdo de `password_hash` por senha em texto simples.

## 5. Confira as tabelas

Na aba **SQL**, execute:

```sql
SHOW TABLES;
```

Depois:

```sql
SELECT COUNT(*) AS total_tabelas
FROM information_schema.tables
WHERE table_schema = 'salve_aluno_apoio'
  AND table_type = 'BASE TABLE';
```

Confira perfis e escola:

```sql
SELECT id, codigo, nome FROM perfis ORDER BY id;
SELECT id, codigo, nome FROM escolas;
```

Confira usuários:

```sql
SELECT u.id, u.email, u.profile, p.nome AS perfil, e.nome AS escola, u.ativo
FROM usuarios u
LEFT JOIN perfis p ON p.id = u.perfil_id
LEFT JOIN escolas e ON e.id = u.escola_id
ORDER BY u.id;
```

## 6. Confira os perfis especializados

```sql
SELECT a.id, u.email, a.matricula, a.turma, a.serie
FROM alunos a JOIN usuarios u ON u.id = a.usuario_id;
```

```sql
SELECT p.id, u.email, p.registro_profissional, p.area_atuacao
FROM professores p JOIN usuarios u ON u.id = p.usuario_id;
```

```sql
SELECT a.id, u.email, a.registro_profissional, a.especialidade
FROM assistentes a JOIN usuarios u ON u.id = a.usuario_id;
```

## 7. Categorias do Banco Solidário

O schema já cria categorias básicas. Para acrescentar categorias específicas, execute:

```sql
INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
('uniformes', 'Uniformes', 'Uniformes escolares em bom estado.'),
('livros', 'Livros', 'Livros didáticos e materiais de leitura.'),
('calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.'),
('outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao), ativa = 1;
```

Para conferir:

```sql
SELECT id, slug, nome, ativa FROM categorias_auxilio ORDER BY id;
```

## 8. Configure o arquivo PHP

No ZIP enviado, abra:

```text
config/database.php
```

Ele já deve conter:

```php
'name' => getenv('SALVE_DB_NAME') ?: 'salve_aluno_apoio',
```

Se estiver diferente, ajuste para `salve_aluno_apoio`.

Para XAMPP padrão, confirme também:

```php
'host' => '127.0.0.1',
'user' => 'root',
'password' => '',
```

Se o MySQL tiver senha, preencha a senha real no campo `password`.

## 9. Teste no navegador

1. Copie a pasta `SalveAluno/salve-aluno` para `C:\xampp\htdocs\salve-aluno`.
2. Inicie **Apache** e **MySQL** no XAMPP.
3. Abra `http://localhost/salve-aluno/login.php`.
4. Teste o login do aluno e depois o da gestão.
5. Se o PHP mostrar erro de conexão, confira o nome do banco, usuário, senha e se o MySQL está iniciado.

## O que não importar nesta instalação

Não importe juntos:

- `database/schema.sql` e `database/schema-relacional.sql`;
- `database/migrar-banco-solidario.sql` e `database/migrar-banco-solidario-relacional.sql`;
- `database/migrar-tabelas-portugues.sql` em uma instalação nova.

Os arquivos `migrar-banco-solidario.sql` e `migrar-tabelas-portugues.sql` são para instalações antigas específicas. Para o ZIP atual, use `schema-relacional.sql` e `cadastro-usuarios-manual.sql`.
