CREATE DATABASE IF NOT EXISTS salve_aluno CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE salve_aluno;

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    profile VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    details_json LONGTEXT NOT NULL,
    quiz_json LONGTEXT NOT NULL,
    preferences_json LONGTEXT NOT NULL,
    school_key VARCHAR(64) NOT NULL DEFAULT 'escola-municipal',
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY usuarios_email_unico (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS solicitacoes_cadastro (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NULL,
    profile VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    details_json LONGTEXT NOT NULL,
    quiz_json LONGTEXT NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    requested_at VARCHAR(35) NOT NULL,
    reviewed_at VARCHAR(35) NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY solicitacoes_cadastro_email_unico (email),
    KEY solicitacoes_cadastro_escola_status (school_key, status, requested_at),
    CONSTRAINT solicitacoes_cadastro_revisor_fk FOREIGN KEY (reviewed_by) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS registros (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type VARCHAR(40) NOT NULL,
    data_json LONGTEXT NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY registros_usuario_tipo_data (user_id, type, created_at),
    CONSTRAINT registros_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS arquivos_registro (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    record_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    content MEDIUMBLOB NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY arquivos_registro_id (record_id),
    CONSTRAINT arquivos_registro_registro_fk FOREIGN KEY (record_id) REFERENCES registros (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reunioes (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    meeting_date VARCHAR(64) NOT NULL,
    cancelled TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    cancelled_at VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY reunioes_escola_data (school_key, meeting_date),
    CONSTRAINT reunioes_criador_fk FOREIGN KEY (created_by) REFERENCES usuarios (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS participantes_reuniao (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    participant_name VARCHAR(120) NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id),
    CONSTRAINT participantes_reuniao_reuniao_fk FOREIGN KEY (meeting_id) REFERENCES reunioes (id) ON DELETE CASCADE,
    CONSTRAINT participantes_reuniao_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS encerramentos_reuniao (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    closed_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id),
    CONSTRAINT encerramentos_reuniao_reuniao_fk FOREIGN KEY (meeting_id) REFERENCES reunioes (id) ON DELETE CASCADE,
    CONSTRAINT encerramentos_reuniao_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagens_seguras (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    sender_user_id BIGINT UNSIGNED NOT NULL,
    source VARCHAR(20) NOT NULL,
    sender_name VARCHAR(120) NOT NULL,
    student_name VARCHAR(120) NOT NULL DEFAULT '',
    anonymous TINYINT(1) NOT NULL DEFAULT 0,
    message TEXT NOT NULL,
    sent_at VARCHAR(35) NOT NULL,
    read_at VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY mensagens_seguras_escola_envio (school_key, sent_at),
    CONSTRAINT mensagens_seguras_remetente_fk FOREIGN KEY (sender_user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS limites_tentativa (
    rate_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    attempts INT UNSIGNED NOT NULL,
    window_started BIGINT NOT NULL,
    PRIMARY KEY (rate_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categorias_auxilio (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug VARCHAR(48) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(240) NOT NULL DEFAULT '',
    ativa TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY categorias_auxilio_slug_unico (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS itens_solidarios (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    categoria_id BIGINT UNSIGNED NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    titulo VARCHAR(160) NOT NULL,
    descricao TEXT NOT NULL,
    tamanho VARCHAR(80) NOT NULL DEFAULT '',
    condicao VARCHAR(80) NOT NULL DEFAULT 'Novo ou em ótimo estado',
    quantidade_total INT UNSIGNED NOT NULL,
    quantidade_disponivel INT UNSIGNED NOT NULL,
    caminho_imagem VARCHAR(255) NOT NULL DEFAULT '',
    tipo VARCHAR(20) NOT NULL DEFAULT 'doacao',
    doador VARCHAR(120) NOT NULL DEFAULT 'Anônimo',
    data_doacao VARCHAR(10) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'disponivel',
    chave_seed VARCHAR(60) NULL,
    criado_por BIGINT UNSIGNED NOT NULL,
    criado_em VARCHAR(35) NOT NULL,
    atualizado_em VARCHAR(35) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY itens_solidarios_seed_escola (school_key, chave_seed),
    KEY itens_solidarios_escola_status (school_key, status, categoria_id),
    CONSTRAINT itens_solidarios_categoria_fk FOREIGN KEY (categoria_id) REFERENCES categorias_auxilio (id),
    CONSTRAINT itens_solidarios_criador_fk FOREIGN KEY (criado_por) REFERENCES usuarios (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS solicitacoes_auxilio (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    item_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    quantidade INT UNSIGNED NOT NULL DEFAULT 1,
    observacao VARCHAR(1000) NOT NULL DEFAULT '',
    tipo VARCHAR(20) NOT NULL DEFAULT 'doacao',
    prazo_devolucao VARCHAR(10) NULL,
    data_retirada VARCHAR(10) NULL,
    precisa_busca TINYINT(1) NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'pendente',
    requested_at VARCHAR(35) NOT NULL,
    reviewed_at VARCHAR(35) NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    delivered_at VARCHAR(35) NULL,
    received_at VARCHAR(35) NULL,
    returned_at VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY solicitacoes_auxilio_aluno_data (user_id, requested_at),
    KEY solicitacoes_auxilio_escola_status (school_key, status, requested_at),
    KEY solicitacoes_auxilio_item_status (item_id, status),
    CONSTRAINT solicitacoes_auxilio_item_fk FOREIGN KEY (item_id) REFERENCES itens_solidarios (id),
    CONSTRAINT solicitacoes_auxilio_aluno_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE,
    CONSTRAINT solicitacoes_auxilio_revisor_fk FOREIGN KEY (reviewed_by) REFERENCES usuarios (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS movimentacoes_auxilio (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    item_id BIGINT UNSIGNED NOT NULL,
    solicitacao_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    tipo_movimentacao VARCHAR(32) NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    observacao VARCHAR(500) NOT NULL DEFAULT '',
    criado_em VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY movimentacoes_auxilio_item_data (item_id, criado_em),
    KEY movimentacoes_auxilio_solicitacao (solicitacao_id),
    CONSTRAINT movimentacoes_auxilio_item_fk FOREIGN KEY (item_id) REFERENCES itens_solidarios (id),
    CONSTRAINT movimentacoes_auxilio_solicitacao_fk FOREIGN KEY (solicitacao_id) REFERENCES solicitacoes_auxilio (id) ON DELETE SET NULL,
    CONSTRAINT movimentacoes_auxilio_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notificacoes_solidarias (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    mensagem VARCHAR(500) NOT NULL,
    tipo VARCHAR(32) NOT NULL,
    criada_em VARCHAR(35) NOT NULL,
    lida_em VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY notificacoes_solidarias_usuario_data (user_id, criada_em),
    CONSTRAINT notificacoes_solidarias_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS diagnosticos (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    profile VARCHAR(20) NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    score TINYINT UNSIGNED NOT NULL,
    nivel_atencao VARCHAR(24) NOT NULL,
    resumo VARCHAR(500) NOT NULL,
    submitted_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY diagnosticos_usuario_data (user_id, submitted_at),
    KEY diagnosticos_escola_perfil (school_key, profile, submitted_at),
    CONSTRAINT diagnosticos_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS respostas_diagnostico (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    diagnostic_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    question_key VARCHAR(48) NOT NULL,
    pergunta VARCHAR(240) NOT NULL,
    valor TINYINT UNSIGNED NOT NULL,
    resposta VARCHAR(180) NOT NULL,
    criado_em VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY respostas_diagnostico_pergunta_unica (diagnostic_id, question_key),
    CONSTRAINT respostas_diagnostico_diagnostico_fk FOREIGN KEY (diagnostic_id) REFERENCES diagnosticos (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
    ('materiais', 'Materiais escolares', 'Cadernos, mochilas e itens para as atividades.'),
    ('roupas', 'Roupas', 'Roupas limpas e em bom estado.'),
    ('uniformes', 'Uniformes', 'Uniformes escolares em bom estado.'),
    ('livros', 'Livros', 'Livros didáticos e materiais de leitura.'),
    ('calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.'),
    ('alimentacao', 'Alimentação e higiene', 'Itens essenciais para o dia a dia escolar.'),
    ('transporte', 'Transporte', 'Apoio para chegar e permanecer na escola.'),
    ('tecnologia', 'Tecnologia', 'Equipamentos e conectividade para estudar.'),
    ('outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao), ativa = 1;
