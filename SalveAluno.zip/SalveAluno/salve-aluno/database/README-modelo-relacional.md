# Modelo relacional do Salve Aluno

O arquivo `schema-relacional.sql` cria um segundo banco chamado `salve_aluno_apoio`. Ele separa os domínios do projeto atual e mantém as colunas de compatibilidade que a API PHP já utiliza na tabela `usuarios`.

O núcleo relacional segue o fluxo solicitado:

`usuarios → perfis → escolas`

`usuarios → alunos → diagnosticos → alertas`

`alunos → solicitacoes → beneficios`

`usuarios → professores → checkins → encaminhamentos`

`usuarios → assistentes → atendimentos → mensagens_canal_seguro`

`escolas → comunicados → oportunidades → seguranca_oportunidades / acessibilidade_oportunidades`

Também foram incluídas `consentimentos_lgpd`, `auditoria_lgpd`, `sessoes_usuario`, `anexos_solicitacoes`, `categorias_beneficios` e tabelas de compatibilidade para registros, reuniões, Banco Solidário e limites de tentativa.

## Instalação nova

1. Importe `database/schema-relacional.sql` no MySQL/MariaDB.
2. Configure `SALVE_DB_NAME=salve_aluno_apoio` no Apache/PHP.
3. Execute `php tools/install-default-users.php` para criar as contas padrão.
4. Execute `php tools/sincronizar-modelo-relacional.php` para preencher `perfil_id`, `escola_id` e as tabelas `alunos`, `professores` e `assistentes`.

O instalador de contas continua idempotente. O script de sincronização também pode ser executado novamente sem duplicar os perfis especializados.

## Segurança e LGPD

A modelagem separa consentimentos por finalidade e versão de política. `auditoria_lgpd` registra ação, entidade, finalidade, minimização e hash de IP sem armazenar o IP bruto. `mensagens_canal_seguro` possui destinatários, anonimato e marcador de criptografia para permitir uma implementação de proteção em repouso sem misturar conversas com registros genéricos. `sessoes_usuario` permite revogação e expiração explícita de sessão.

As tabelas de oportunidade não afirmam que uma rota é segura apenas por existir. `seguranca_oportunidades` guarda o nível de iluminação, transporte, relatos da comunidade e a marca de rota sugerida; `acessibilidade_oportunidades` registra rampa, banheiro adaptado, atendimento prioritário e Libras, sempre sujeitos à atualização local.
