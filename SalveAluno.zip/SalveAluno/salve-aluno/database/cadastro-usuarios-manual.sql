-- Salve Aluno — cadastro manual dos usuários padrão
-- Use este arquivo SOMENTE depois de importar schema-relacional.sql.
-- No phpMyAdmin, selecione o banco salve_aluno_apoio antes de executar.

USE salve_aluno_apoio;

-- Garante a escola padrão caso ela ainda não exista.
INSERT INTO escolas (nome, codigo, email, cidade, estado, turno_principal)
VALUES ('Escola Municipal', 'escola-municipal', '', '', '', 'manhã e tarde')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), turno_principal = VALUES(turno_principal);

-- O INSERT usa SELECT nos perfis e na escola, portanto não depende de IDs fixos.
INSERT INTO usuarios
(escola_id, perfil_id, email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, ativo, created_at)
SELECT NULL, p.id, 'admin@salvealuno.local', '$2b$10$m7yqjFTe2RCdnLn2jsY7NOJ04VM2.VehTbZwepl1tmTSwtWRwHVDG', 'admin', 'Administrador Salve Aluno', '', '{}', '{}', '{}', 'escola-municipal', 1, '2026-10-27T14:00:00Z'
FROM perfis p WHERE p.codigo = 'admin'
ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), perfil_id = VALUES(perfil_id), profile = VALUES(profile), name = VALUES(name), ativo = 1;

INSERT INTO usuarios
(escola_id, perfil_id, email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, ativo, created_at)
SELECT e.id, p.id, 'aluno@escola.edu.br', '$2b$10$zkuxGx29sS95RLyWhc/RMe6bVQ6Y7358fxr6YH8rykyp6JN8ovcIy', 'aluno', 'Aluno Padrão', '', '{}', '{}', '{}', 'escola-municipal', 1, '2026-10-27T14:00:00Z'
FROM escolas e CROSS JOIN perfis p WHERE e.codigo = 'escola-municipal' AND p.codigo = 'aluno'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), password_hash = VALUES(password_hash), perfil_id = VALUES(perfil_id), profile = VALUES(profile), name = VALUES(name), ativo = 1;

INSERT INTO usuarios
(escola_id, perfil_id, email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, ativo, created_at)
SELECT e.id, p.id, 'professor@escola.edu.br', '$2b$10$GJIeCJhVlFIEQy6GE8IY3uBDEFJkeMcw0S6UH2tx2eA.USV0SUcXm', 'professor', 'Professor Padrão', '', '{}', '{}', '{}', 'escola-municipal', 1, '2026-10-27T14:00:00Z'
FROM escolas e CROSS JOIN perfis p WHERE e.codigo = 'escola-municipal' AND p.codigo = 'professor'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), password_hash = VALUES(password_hash), perfil_id = VALUES(perfil_id), profile = VALUES(profile), name = VALUES(name), ativo = 1;

INSERT INTO usuarios
(escola_id, perfil_id, email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, ativo, created_at)
SELECT e.id, p.id, 'gestao@escola.edu.br', '$2b$10$DBH/b48.XWTuUx9kUcKcNuLrMpo/VGWgRyqVSzdKLKbcu9bgTr5Bq', 'escola', 'Gestão Escolar', '', '{}', '{}', '{}', 'escola-municipal', 1, '2026-10-27T14:00:00Z'
FROM escolas e CROSS JOIN perfis p WHERE e.codigo = 'escola-municipal' AND p.codigo = 'escola'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), password_hash = VALUES(password_hash), perfil_id = VALUES(perfil_id), profile = VALUES(profile), name = VALUES(name), ativo = 1;

INSERT INTO usuarios
(escola_id, perfil_id, email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, ativo, created_at)
SELECT e.id, p.id, 'assistente@escola.edu.br', '$2b$10$gP4/kIZzjZV/cfSWwBQEp.APnVXZKdBZlptawadGhPvJOIX.yFh0y', 'assistente', 'Assistente Social', '', '{}', '{}', '{}', 'escola-municipal', 1, '2026-10-27T14:00:00Z'
FROM escolas e CROSS JOIN perfis p WHERE e.codigo = 'escola-municipal' AND p.codigo = 'assistente'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), password_hash = VALUES(password_hash), perfil_id = VALUES(perfil_id), profile = VALUES(profile), name = VALUES(name), ativo = 1;

-- Perfis específicos. ON DUPLICATE KEY UPDATE torna o cadastro repetível.
INSERT INTO alunos (usuario_id, escola_id, matricula, turma, serie, turno)
SELECT u.id, e.id, 'ALUNO-001', '8º ano A', '8º ano', 'manhã'
FROM usuarios u JOIN escolas e ON e.codigo = 'escola-municipal'
WHERE u.email = 'aluno@escola.edu.br'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), turma = VALUES(turma), serie = VALUES(serie), turno = VALUES(turno);

INSERT INTO professores (usuario_id, escola_id, registro_profissional, area_atuacao, turmas_json)
SELECT u.id, e.id, 'PROF-001', 'Educação básica', '["8º ano A", "9º ano B"]'
FROM usuarios u JOIN escolas e ON e.codigo = 'escola-municipal'
WHERE u.email = 'professor@escola.edu.br'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), area_atuacao = VALUES(area_atuacao), turmas_json = VALUES(turmas_json);

INSERT INTO assistentes (usuario_id, escola_id, registro_profissional, especialidade, territorio_atendimento)
SELECT u.id, e.id, 'AS-001', 'Assistência social escolar', 'Comunidade escolar e território próximo'
FROM usuarios u JOIN escolas e ON e.codigo = 'escola-municipal'
WHERE u.email = 'assistente@escola.edu.br'
ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id), especialidade = VALUES(especialidade), territorio_atendimento = VALUES(territorio_atendimento);

-- Conferência final.
SELECT u.id, u.email, u.profile, p.nome AS perfil, e.nome AS escola
FROM usuarios u
LEFT JOIN perfis p ON p.id = u.perfil_id
LEFT JOIN escolas e ON e.id = u.escola_id
ORDER BY u.id;
