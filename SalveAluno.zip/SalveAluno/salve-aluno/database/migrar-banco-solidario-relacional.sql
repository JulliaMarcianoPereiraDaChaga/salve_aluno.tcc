USE salve_aluno_apoio;

ALTER TABLE itens_solidarios
    ADD COLUMN tipo VARCHAR(20) NOT NULL DEFAULT 'doacao' AFTER caminho_imagem,
    ADD COLUMN doador VARCHAR(120) NOT NULL DEFAULT 'Anônimo' AFTER tipo,
    ADD COLUMN data_doacao VARCHAR(10) NULL AFTER doador;

ALTER TABLE solicitacoes_auxilio
    ADD COLUMN tipo VARCHAR(20) NOT NULL DEFAULT 'doacao' AFTER observacao,
    ADD COLUMN prazo_devolucao VARCHAR(10) NULL AFTER tipo,
    ADD COLUMN data_retirada VARCHAR(10) NULL AFTER prazo_devolucao,
    ADD COLUMN precisa_busca TINYINT(1) NOT NULL DEFAULT 0 AFTER data_retirada,
    ADD COLUMN received_at VARCHAR(35) NULL AFTER delivered_at,
    ADD COLUMN returned_at VARCHAR(35) NULL AFTER received_at;

CREATE TABLE IF NOT EXISTS notificacoes_solidarias (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    mensagem VARCHAR(500) NOT NULL,
    tipo VARCHAR(32) NOT NULL,
    criada_em VARCHAR(35) NOT NULL,
    lida_em VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY notificacoes_solidarias_usuario_data (user_id, criada_em),
    CONSTRAINT notificacoes_solidarias_usuario_fk FOREIGN KEY (user_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO categorias_auxilio (slug, nome, descricao) VALUES
    ('roupas', 'Roupas', 'Roupas limpas e em bom estado.'),
    ('uniformes', 'Uniformes', 'Uniformes escolares em bom estado.'),
    ('livros', 'Livros', 'Livros didáticos e materiais de leitura.'),
    ('calcados', 'Calçados', 'Calçados em bom estado para o dia a dia.'),
    ('outros', 'Outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao), ativa = 1;

INSERT INTO categorias_beneficios (nome, slug, descricao) VALUES
    ('Roupas', 'roupas', 'Roupas limpas e em bom estado.'),
    ('Uniformes', 'uniformes', 'Uniformes escolares em bom estado.'),
    ('Livros', 'livros', 'Livros didáticos e materiais de leitura.'),
    ('Calçados', 'calcados', 'Calçados em bom estado para o dia a dia.'),
    ('Outros', 'outros', 'Outros recursos para apoiar a permanência estudantil.')
ON DUPLICATE KEY UPDATE nome = VALUES(nome), descricao = VALUES(descricao);
