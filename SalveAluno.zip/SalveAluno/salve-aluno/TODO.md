# TODO — Salve Aluno

- [ ] **Banco Solidário:** adicionar um espaço onde alunos possam ter acesso a doações de materiais, roupas e outros auxílios para continuar na escola. Incluir catálogo e pedidos com acompanhamento; oferecer à gestão escolar e à assistência social uma forma de administrar itens e pedidos.
- [ ] **Interface:** tornar a interface mais bonita e menos simples, preservando os painéis e os fluxos existentes, com visual responsivo, hierarquia clara e estados acessíveis.
- [ ] **Quiz de diagnóstico:** adicionar questionário apropriado para cada tipo de usuário — aluno, professor, escola/gestão e assistente social — e não oferecer o quiz ao administrador; salvar respostas e resultados associados ao perfil autenticado.
- [ ] **Imagens e fontes:** incluir imagens adequadas ao acolhimento e às doações, e aplicar fontes tipográficas legíveis e visualmente cuidadas.
- [ ] **Banco de dados:** entregar esquema com pelo menos 10 e até 15 tabelas em português; manter relacionamentos e dados necessários às funcionalidades existentes e novas.
- [ ] **Credenciais:** disponibilizar as contas `admin@salvealuno.local` / `Admin@2026!` (`admin`), `aluno@escola.edu.br` / `Aluno@2026!` (`aluno`), `professor@escola.edu.br` / `Professor@2026!` (`professor`), `gestao@escola.edu.br` / `Gestao@2026!` (`escola`) e `assistente@escola.edu.br` / `Assistente@2026!` (`assistente`).
