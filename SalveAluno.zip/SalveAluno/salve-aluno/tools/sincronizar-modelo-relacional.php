<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'database.php';
$config = databaseConfig();
$db = new PDO(
    'mysql:host=' . $config['host'] . ';dbname=' . $config['name'] . ';charset=utf8mb4',
    $config['user'],
    $config['password'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
);
$db->beginTransaction();
try {
    $school = $db->query("SELECT id FROM escolas WHERE codigo = 'escola-municipal' LIMIT 1")->fetchColumn();
    if (!$school) {
        $db->prepare('INSERT INTO escolas (nome, codigo, turno_principal) VALUES (:name, :code, :shift)')->execute([':name' => 'Escola Municipal', ':code' => 'escola-municipal', ':shift' => 'manhã e tarde']);
        $school = $db->lastInsertId();
    }
    $profiles = $db->query('SELECT id, codigo FROM perfis')->fetchAll();
    $profileIds = [];
    foreach ($profiles as $profile) { $profileIds[$profile['codigo']] = (int)$profile['id']; }
    $users = $db->query('SELECT id, profile, school_key FROM usuarios')->fetchAll();
    foreach ($users as $user) {
        $profileId = $profileIds[$user['profile']] ?? null;
        if (!$profileId) continue;
        $db->prepare('UPDATE usuarios SET perfil_id = :profile_id, escola_id = :school_id WHERE id = :id')->execute([':profile_id' => $profileId, ':school_id' => $school, ':id' => $user['id']]);
        if ($user['profile'] === 'aluno') {
            $db->prepare('INSERT INTO alunos (usuario_id, escola_id) VALUES (:user_id, :school_id) ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id)')->execute([':user_id' => $user['id'], ':school_id' => $school]);
        } elseif ($user['profile'] === 'professor') {
            $db->prepare('INSERT INTO professores (usuario_id, escola_id) VALUES (:user_id, :school_id) ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id)')->execute([':user_id' => $user['id'], ':school_id' => $school]);
        } elseif ($user['profile'] === 'assistente') {
            $db->prepare('INSERT INTO assistentes (usuario_id, escola_id) VALUES (:user_id, :school_id) ON DUPLICATE KEY UPDATE escola_id = VALUES(escola_id)')->execute([':user_id' => $user['id'], ':school_id' => $school]);
        }
    }
    $db->commit();
    fwrite(STDOUT, "Modelo relacional sincronizado: usuários, escola e perfis especializados.\n");
} catch (Throwable $error) {
    $db->rollBack();
    fwrite(STDERR, "Falha na sincronização: {$error->getMessage()}\n");
    exit(1);
}
