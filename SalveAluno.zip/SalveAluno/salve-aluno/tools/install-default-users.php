<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'api.php';

$defaults = [
    ['admin@salvealuno.local', 'admin', 'Administrador Salve Aluno', 'Escola Municipal', 'Admin@2026!'],
    ['aluno@escola.edu.br', 'aluno', 'Aluno Padrão', 'Escola Municipal', 'Aluno@2026!'],
    ['professor@escola.edu.br', 'professor', 'Professor Padrão', 'Escola Municipal', 'Professor@2026!'],
    ['gestao@escola.edu.br', 'escola', 'Gestão Escolar', 'Escola Municipal', 'Gestao@2026!'],
    ['assistente@escola.edu.br', 'assistente', 'Assistente Social', 'Escola Municipal', 'Assistente@2026!'],
];

$database = apiDatabase();
$find = $database->prepare('SELECT id FROM usuarios WHERE email = :email');
$insert = $database->prepare(
    'INSERT INTO usuarios
        (email, password_hash, profile, name, details_json, quiz_json, preferences_json, school_key, created_at)
     VALUES (:email, :password_hash, :profile, :name, :details, :quiz, :preferences, :school_key, :created_at)'
);

foreach ($defaults as [$email, $profile, $name, $schoolName, $password]) {
    $find->execute([':email' => $email]);
    if ($find->fetchColumn()) {
        fwrite(STDOUT, "Já existe: {$email}\n");
        continue;
    }
    $insert->execute([
        ':email' => $email,
        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ':profile' => $profile,
        ':name' => $name,
        ':details' => '{}',
        ':quiz' => '{}',
        ':preferences' => '{}',
        ':school_key' => schoolKeyForName($schoolName),
        ':created_at' => gmdate('c'),
    ]);
    fwrite(STDOUT, "Criado: {$email} ({$profile})\n");
}

$schoolKey = schoolKeyForName('Escola Municipal');
$manager = $database->query("SELECT id FROM usuarios WHERE profile = 'escola' AND school_key = '{$schoolKey}' ORDER BY id LIMIT 1")->fetchColumn();
if ($manager) {
    $categories = $database->query('SELECT id, slug FROM categorias_auxilio')->fetchAll();
    $categoryIds = [];
    foreach ($categories as $category) { $categoryIds[$category['slug']] = (int)$category['id']; }
    $items = [
        ['kit-materiais', 'materiais', 'Kit de materiais escolares', 'Cadernos, lápis, estojo e mochila para apoiar a rotina de estudos.', 'Escolar', 12, 'assets/images/doacao-materiais.jpg'],
        ['uniforme-roupas', 'roupas', 'Uniforme e roupas para escola', 'Peças limpas e em ótimo estado para usar na escola.', 'PP ao GG', 8, 'assets/images/doacao-roupas.jpg'],
        ['notebook-estudo', 'tecnologia', 'Empréstimo de notebook', 'Equipamento para atividades, pesquisas e aulas online.', 'Uso temporário', 4, 'assets/images/doacao-materiais.jpg']
    ];
    $seed = $database->prepare('SELECT id FROM itens_solidarios WHERE school_key = :school_key AND chave_seed = :seed');
    $add = $database->prepare('INSERT INTO itens_solidarios (categoria_id, school_key, titulo, descricao, tamanho, condicao, quantidade_total, quantidade_disponivel, caminho_imagem, status, chave_seed, criado_por, criado_em) VALUES (:category_id, :school_key, :title, :description, :size, :condition, :total, :available, :image, :status, :seed, :created_by, :created_at)');
    foreach ($items as [$key, $slug, $title, $description, $size, $quantity, $image]) {
        if (!isset($categoryIds[$slug])) continue;
        $seed->execute([':school_key' => $schoolKey, ':seed' => $key]);
        if ($seed->fetchColumn()) continue;
        $add->execute([':category_id' => $categoryIds[$slug], ':school_key' => $schoolKey, ':title' => $title, ':description' => $description, ':size' => $size, ':condition' => 'Novo ou em ótimo estado', ':total' => $quantity, ':available' => $quantity, ':image' => $image, ':status' => 'disponivel', ':seed' => $key, ':created_by' => $manager, ':created_at' => gmdate('c')]);
    }
}
fwrite(STDOUT, "Instalação das contas padrão concluída.\n");
