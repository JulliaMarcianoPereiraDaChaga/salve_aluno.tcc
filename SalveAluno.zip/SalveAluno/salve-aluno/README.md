# Salve Aluno — PHP + MySQL

O projeto agora usa páginas `.php` e uma API PHP com PDO para persistência no MySQL/MariaDB. Não abra os arquivos com `file://`: use Apache/XAMPP ou o servidor embutido do PHP.

## Instalação no XAMPP/Apache

1. Ative Apache, MySQL/MariaDB, `pdo_mysql` e `fileinfo`.
2. Copie esta pasta para `htdocs/salve-aluno`.
3. Importe `database/schema.sql` pelo phpMyAdmin.
4. Configure as variáveis `SALVE_DB_HOST`, `SALVE_DB_NAME`, `SALVE_DB_USER` e `SALVE_DB_PASSWORD` no ambiente do Apache. Os padrões são `127.0.0.1`, `salve_aluno`, `root` e senha vazia.
5. Abra `http://localhost/salve-aluno/` (a entrada é `index.php`).
6. Crie as contas padrão executando `php tools/install-default-users.php`.
7. Abra `http://localhost/salve-aluno/login.php` para entrar.

## Estrutura

- `index.php`, `login.php` e `dashboard-*.php`: páginas PHP da aplicação.
- `api.php`: API principal com sessão, CSRF, autenticação e persistência.
- `config/database.php`: conexão/configuração PDO do banco.
- `database/schema.sql`: criação do banco e tabelas.
- `api/`: endpoints complementares JSON.
- `css/`, `js/` e `assets/`: interface e recursos estáticos.

O navegador continua usando JavaScript para chamadas assíncronas, mas todas as páginas e a camada de dados são executadas pelo PHP no servidor.


## Área do administrador

O perfil `admin` acessa `admin.php` e pode listar usuários, criar contas para todos os perfis, redefinir senhas e excluir contas que não sejam a própria conta administradora. Todas as operações são protegidas por sessão, CSRF e verificação de perfil no servidor.

Para instalar os usuários padrão:

```bash
php tools/install-default-users.php
```

Credenciais iniciais de desenvolvimento:

| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | `admin@salvealuno.local` | `Admin@2026!` |
| Aluno | `aluno@escola.edu.br` | `Aluno@2026!` |
| Professor | `professor@escola.edu.br` | `Professor@2026!` |
| Gestão escolar | `gestao@escola.edu.br` | `Gestao@2026!` |
| Assistente social | `assistente@escola.edu.br` | `Assistente@2026!` |

Altere as senhas iniciais depois do primeiro acesso. O instalador é idempotente: se o e-mail já existir, ele não substitui a senha nem duplica o usuário.

## Novas áreas

O painel do aluno agora inclui o **Banco Solidário**, com catálogo pesquisável e filtros de categoria, condição e modalidade, pedidos confidenciais de doação ou empréstimo, acompanhamento, confirmação de recebimento e notificações de status e devolução. A gestão escolar e a assistência social podem cadastrar e editar itens, enviar imagens JPG/PNG/WEBP de até 5 MB, indisponibilizá-los, analisar pedidos, registrar entregas e devoluções e exportar o relatório em CSV. As imagens são guardadas em `storage/solidarity/` (diretório protegido pelo Apache) e entregues pela API somente a usuários autenticados da mesma escola. As categorias incluem materiais, roupas, uniformes, tecnologia, livros, calçados, alimentação, transporte e outros. Para uma instalação existente que ainda não recebeu as colunas do Banco Solidário, faça backup e execute `database/migrar-banco-solidario.sql` no banco `salve_aluno` ou `database/migrar-banco-solidario-relacional.sql` no banco `salve_aluno_apoio`. Se essas colunas já foram migradas anteriormente, execute apenas a migração de categorias correspondente (`database/migrar-categorias-solidario.sql` ou `database/migrar-categorias-solidario-relacional.sql`). Novas instalações recebem as tabelas e categorias ao importar o schema correspondente.

O **Mapa de oportunidades** apresenta cursos, empregos, bibliotecas, serviços e eventos em um mapa Leaflet/OpenStreetMap, com busca, filtros de raio e disponibilidade, cálculo opcional de deslocamento, favoritos, detalhes, rotas e avisos de prazo/proximidade. O dataset atual é demonstrativo, com endereços, vagas e prazos não verificados; não use os exemplos para decisões ou deslocamentos reais. A localização precisa só é solicitada por ação explícita e permanece em memória durante a página; o serviço de mapas recebe solicitações para carregar os tiles. Favoritos, avaliações e denúncias são armazenados apenas neste navegador; as avaliações e denúncias ainda não são enviadas a um serviço central. Antes de uso em produção, conecte uma fonte de oportunidades verificada e um endpoint de gestão/denúncias. Os critérios são apoio à decisão e não substituem a validação local da escola ou da comunidade.

As áreas de escola, professor e assistência social receberam indicadores coloridos, check-in contextual e cards de prioridade. A gestão também tem a calculadora de **Custo da Inação**, que simula o impacto financeiro e social estimado de um investimento preventivo; o número é uma projeção orientativa, não um laudo financeiro.

O esquema novo tem 16 tabelas com nomes em português: `usuarios`, `solicitacoes_cadastro`, `registros`, `arquivos_registro`, `reunioes`, `participantes_reuniao`, `encerramentos_reuniao`, `mensagens_seguras`, `limites_tentativa`, `categorias_auxilio`, `itens_solidarios`, `solicitacoes_auxilio`, `movimentacoes_auxilio`, `notificacoes_solidarias`, `diagnosticos` e `respostas_diagnostico`. Em instalações antigas, use `database/migrar-tabelas-portugues.sql` depois de fazer backup; em instalações novas, importe apenas `database/schema.sql`.

O quiz de diagnóstico é disponibilizado para aluno, professor, gestão escolar e assistência social. O perfil administrador continua sem diagnóstico e a API também rejeita esse acesso. O modo escuro é persistido no navegador para os painéis e pode ser alternado pelo botão de tema.

## Novo modelo relacional

Foi adicionado um segundo esquema completo em `database/schema-relacional.sql`, no banco `salve_aluno_apoio`. Ele organiza o projeto por entidades relacionais: `perfis`, `escolas`, `usuarios`, `alunos`, `professores`, `assistentes`, `diagnosticos`, `beneficios`, `solicitacoes`, `mensagens_canal_seguro`, `atendimentos`, `checkins`, `encaminhamentos`, `alertas`, `oportunidades`, `seguranca_oportunidades`, `acessibilidade_oportunidades`, `comunicados`, `consentimentos_lgpd` e `auditoria_lgpd`, além de tabelas auxiliares e de compatibilidade.

Para usar o novo banco, importe o schema relacional, defina `SALVE_DB_NAME=salve_aluno_apoio`, execute `php tools/install-default-users.php` e depois `php tools/sincronizar-modelo-relacional.php`. A documentação detalhada está em `database/README-modelo-relacional.md`. O banco anterior continua em `database/schema.sql` para evitar uma troca destrutiva automática.
No **Banco Solidário**, novos itens recebem automaticamente uma foto ilustrativa do Unsplash conforme a categoria e o nome (por exemplo, mochila, agasalho, kit escolar, calculadora ou livro didático). As fotos são carregadas do Unsplash; o formulário da gestão escolar e da assistência social já permite enviar JPG, PNG ou WEBP próprios de até 5 MB, que substituem a imagem ilustrativa e ficam armazenados de forma privada por escola. As fotos ilustrativas não representam a condição real de um item.

## Implementação manual pelo phpMyAdmin

Para instalar o banco sem terminal, use `database/GUIA-PHPMYADMIN.md`. O fluxo do ZIP atual é: criar o banco `salve_aluno_apoio`, importar `database/schema-relacional.sql` e depois importar `database/cadastro-usuarios-manual.sql`. Não misture o schema relacional com o schema legado ou com as migrações destinadas a `salve_aluno`.
