<?php
declare(strict_types=1);

function diagnosticQuestionSet(string $profile): array
{
    $sets = [
        'aluno' => [
            ['materiais', 'Você tem os materiais básicos de que precisa para estudar?'],
            ['roupas', 'Você tem uniforme ou roupas adequadas para frequentar a escola?'],
            ['transporte', 'Você consegue chegar à escola com regularidade?'],
            ['alimentacao', 'Você conta com alimentação suficiente nos dias de aula?'],
            ['apoio', 'Se algo atrapalha seus estudos, você tem alguém de confiança para conversar?']
        ],
        'professor' => [
            ['presenca', 'Você tem percebido dificuldades recorrentes de presença ou participação na turma?'],
            ['escuta', 'Quando um estudante sinaliza uma dificuldade, existe um canal seguro para acolher?'],
            ['materiais', 'Os estudantes conseguem acessar os materiais necessários para acompanhar as aulas?'],
            ['encaminhamento', 'Você sabe a quem recorrer quando um estudante precisa de apoio especializado?'],
            ['retorno', 'Os encaminhamentos feitos pela equipe costumam ter um próximo passo acompanhado?']
        ],
        'escola' => [
            ['frequencia', 'A escola identifica com regularidade padrões de faltas que podem interromper a trajetória?'],
            ['recursos', 'Há recursos básicos disponíveis para responder a necessidades materiais dos estudantes?'],
            ['articulacao', 'As equipes conseguem combinar ações de apoio sem sobrecarregar o estudante?'],
            ['privacidade', 'Os estudantes têm um canal claro e reservado para pedir ajuda?'],
            ['acompanhamento', 'A escola acompanha o retorno depois de encaminhar um estudante para apoio?']
        ],
        'assistente' => [
            ['volume', 'O volume atual de atendimentos permite acompanhar cada caso com cuidado?'],
            ['urgencia', 'Há um fluxo claro para responder a situações que precisam de atenção rápida?'],
            ['rede', 'A rede local oferece opções suficientes de apoio e encaminhamento?'],
            ['recursos', 'Você consegue identificar e acessar auxílios materiais quando são necessários?'],
            ['retorno', 'Os encaminhamentos costumam ter retorno e continuidade registrados?']
        ]
    ];
    if (!isset($sets[$profile])) return [];
    $scale = [
        ['value' => 0, 'label' => 'Não é uma dificuldade no momento'],
        ['value' => 1, 'label' => 'Acontece de vez em quando'],
        ['value' => 2, 'label' => 'Acontece com frequência'],
        ['value' => 3, 'label' => 'Preciso de apoio ou de uma ação agora']
    ];
    return array_map(static fn(array $question): array => [
        'key' => $question[0], 'question' => $question[1], 'options' => $scale
    ], $sets[$profile]);
}

function diagnosticResult(string $profile, int $score): array
{
    if ($score <= 4) {
        $level = 'estavel';
        $title = 'Sua rede tem bons pontos de apoio';
        $summary = 'Continue observando o que funciona e mantenha os canais de conversa abertos.';
    } elseif ($score <= 9) {
        $level = 'acompanhar';
        $title = 'Alguns pontos merecem acompanhamento';
        $summary = 'Converse com a equipe responsável e combine um próximo passo simples.';
    } else {
        $level = 'prioritario';
        $title = 'Vale buscar apoio próximo';
        $summary = 'Procure a equipe de confiança da escola para organizar apoio e próximos passos.';
    }
    $disclaimer = 'Este questionário não é diagnóstico clínico; é um ponto de partida para uma conversa de apoio.';
    if ($profile !== 'aluno') {
        $disclaimer = 'Este questionário não avalia pessoas nem substitui critérios profissionais; ele ajuda a identificar necessidades de organização e apoio.';
    }
    return ['level' => $level, 'title' => $title, 'summary' => $summary, 'disclaimer' => $disclaimer];
}

function handleDiagnosticActions(PDO $database, array $user, string $action, array $body): void
{
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $profile = (string)($user['profile'] ?? '');
    if (!in_array($profile, ['aluno', 'professor', 'escola', 'assistente'], true)) {
        apiFail(403, 'O diagnóstico está disponível para aluno, professor, gestão escolar e assistência social.');
    }

    if ($action === 'diagnostico-perguntas' && $method === 'GET') {
        $labels = ['aluno' => 'Aluno', 'professor' => 'Professor', 'escola' => 'Gestão escolar', 'assistente' => 'Assistência social'];
        apiResponse(200, [
            'profile' => $profile,
            'profileLabel' => $labels[$profile],
            'questions' => diagnosticQuestionSet($profile),
            'notice' => 'Suas respostas são confidenciais e servem para orientar próximos passos de apoio.'
        ]);
    }

    if ($action === 'diagnostico-historico' && $method === 'GET') {
        $statement = $database->prepare(
            'SELECT id, score, nivel_atencao AS level, resumo AS summary, submitted_at AS submittedAt
             FROM diagnosticos WHERE user_id = :user_id ORDER BY submitted_at DESC LIMIT 5'
        );
        $statement->execute([':user_id' => $user['id']]);
        apiResponse(200, ['diagnostics' => $statement->fetchAll()]);
    }

    if ($action === 'diagnostico-enviar' && $method === 'POST') {
        $questions = diagnosticQuestionSet($profile);
        $answers = $body['answers'] ?? null;
        if (!is_array($answers) || count($answers) !== count($questions)) {
            apiFail(422, 'Responda a todas as perguntas antes de salvar.');
        }
        $answerMap = [];
        $score = 0;
        $labels = [
            0 => 'Não é uma dificuldade no momento',
            1 => 'Acontece de vez em quando',
            2 => 'Acontece com frequência',
            3 => 'Preciso de apoio ou de uma ação agora'
        ];
        foreach ($questions as $question) {
            $key = $question['key'];
            $value = $answers[$key] ?? null;
            if (!is_int($value) && !(is_string($value) && ctype_digit($value))) {
                apiFail(422, 'Uma das respostas não é válida.');
            }
            $value = (int)$value;
            if ($value < 0 || $value > 3) apiFail(422, 'Uma das respostas não é válida.');
            $answerMap[$key] = ['value' => $value, 'label' => $labels[$value], 'question' => $question['question']];
            $score += $value;
        }
        if (count(array_diff(array_keys($answers), array_column($questions, 'key'))) > 0) {
            apiFail(422, 'O formulário contém respostas que não pertencem ao seu perfil.');
        }
        $result = diagnosticResult($profile, $score);
        $id = newId();
        $now = gmdate('c');
        $database->beginTransaction();
        $insert = $database->prepare(
            'INSERT INTO diagnosticos (id, user_id, profile, school_key, score, nivel_atencao, resumo, submitted_at)
             VALUES (:id, :user_id, :profile, :school_key, :score, :level, :summary, :submitted_at)'
        );
        $insert->execute([
            ':id' => $id, ':user_id' => $user['id'], ':profile' => $profile,
            ':school_key' => $user['school_key'], ':score' => $score, ':level' => $result['level'],
            ':summary' => $result['title'] . ' — ' . $result['summary'], ':submitted_at' => $now
        ]);
        $answerInsert = $database->prepare(
            'INSERT INTO respostas_diagnostico (diagnostic_id, question_key, pergunta, valor, resposta, criado_em)
             VALUES (:diagnostic_id, :question_key, :question, :value, :answer, :created_at)'
        );
        foreach ($answerMap as $key => $answer) {
            $answerInsert->execute([
                ':diagnostic_id' => $id, ':question_key' => $key, ':question' => $answer['question'],
                ':value' => $answer['value'], ':answer' => $answer['label'], ':created_at' => $now
            ]);
        }
        $database->commit();
        apiResponse(201, ['diagnostic' => [
            'id' => $id, 'score' => $score, 'maximum' => count($questions) * 3,
            'level' => $result['level'], 'title' => $result['title'],
            'summary' => $result['summary'], 'disclaimer' => $result['disclaimer'], 'submittedAt' => $now
        ]]);
    }

    apiFail(404, 'Ação de diagnóstico desconhecida.');
}
