<?php
declare(strict_types=1);

function solidarityNotify(PDO $database, int $userId, string $message, string $type): void
{
    $statement = $database->prepare(
        'INSERT INTO notificacoes_solidarias (user_id, mensagem, tipo, criada_em)
         VALUES (:user_id, :message, :type, :created_at)'
    );
    $statement->execute([
        ':user_id' => $userId,
        ':message' => $message,
        ':type' => $type,
        ':created_at' => gmdate('c')
    ]);
}

function solidarityNotifyTeam(PDO $database, string $schoolKey, string $message, string $type): void
{
    $statement = $database->prepare(
        'SELECT id FROM usuarios WHERE school_key = :school_key AND profile IN ("assistente", "escola")'
    );
    $statement->execute([':school_key' => $schoolKey]);
    foreach ($statement->fetchAll(PDO::FETCH_COLUMN) as $userId) {
        solidarityNotify($database, (int)$userId, $message, $type);
    }
}

function solidarityStoreImage(): ?string
{
    $file = $_FILES['solidarityImage'] ?? null;
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || (int)($file['size'] ?? 0) > 5 * 1024 * 1024 ||
        !is_uploaded_file((string)($file['tmp_name'] ?? ''))) {
        apiFail(422, 'A imagem deve ter até 5 MB e ser enviada corretamente.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $imageInfo = getimagesize($file['tmp_name']);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$imageInfo || !isset($extensions[$mime]) ||
        !in_array($imageInfo[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true) ||
        $imageInfo[0] > 6000 || $imageInfo[1] > 6000) {
        apiFail(422, 'Use uma imagem JPG, PNG ou WEBP com até 6000 × 6000 pixels.');
    }

    $directory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'solidarity';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        apiFail(500, 'Não foi possível preparar o armazenamento de imagens.');
    }
    if (!is_writable($directory)) apiFail(500, 'O armazenamento de imagens não permite gravação.');

    $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . DIRECTORY_SEPARATOR . $filename)) {
        apiFail(500, 'Não foi possível salvar a imagem enviada.');
    }
    return 'storage/solidarity/' . $filename;
}

function solidarityRemoveImage(?string $path): void
{
    if (!is_string($path) || !preg_match('~^storage/solidarity/[a-f0-9]{32}\.(?:jpg|png|webp)$~', $path)) return;
    $filename = basename($path);
    $fullPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR .
        'solidarity' . DIRECTORY_SEPARATOR . $filename;
    if (is_file($fullPath)) unlink($fullPath);
}

function solidarityDefaultImage(string $category, string $title): string
{
    $title = strtolower($title);
    $images = [
        'roupas' => [
            ['mochil', 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80'],
            ['agasalh', 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80'],
            ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80']
        ],
        'uniformes' => [
            'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=900&q=80'
        ],
        'materiais' => [
            ['kit', 'https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=900&q=80'],
            ['https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=900&q=80']
        ],
        'tecnologia' => [
            ['calculador', 'https://images.unsplash.com/photo-1587145820266-a5951ee96835?auto=format&fit=crop&w=900&q=80'],
            'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80'
        ],
        'livros' => [
            ['did', 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=900&q=80'],
            'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=900&q=80'
        ],
        'calcados' => ['assets/images/doacao-roupas.jpg'],
        'outros' => ['https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=900&q=80'],
        'alimentacao' => ['assets/images/salve-hero.jpg'],
        'transporte' => ['assets/images/salve-hero.jpg']
    ];
    $categoryImages = $images[$category] ?? ['assets/images/doacao-materiais.jpg'];
    foreach ($categoryImages as $image) {
        if (is_array($image)) {
            if (str_contains($title, $image[0])) return $image[1];
        } else {
            return $image;
        }
    }
    $last = end($categoryImages);
    return is_array($last) ? $last[1] : $last;
}

function handleSolidarityActions(PDO $database, array $user, string $action, array $body): void
{
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $profile = (string)($user['profile'] ?? '');
    $schoolKey = (string)$user['school_key'];

    if ($action === 'banco-imagem' && $method === 'GET') {
        requireProfile($user, ['aluno', 'escola', 'assistente']);
        $itemId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$itemId) apiFail(422, 'Identificador de imagem inválido.');
        $statement = $database->prepare(
            'SELECT caminho_imagem FROM itens_solidarios
             WHERE id = :id AND school_key = :school_key AND status <> :archived'
        );
        $statement->execute([':id' => $itemId, ':school_key' => $schoolKey, ':archived' => 'arquivado']);
        $path = $statement->fetchColumn();
        if (!is_string($path) || !preg_match('~^storage/solidarity/[a-f0-9]{32}\.(?:jpg|png|webp)$~', $path)) {
            apiFail(404, 'Imagem não encontrada.');
        }
        $fullPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR .
            'solidarity' . DIRECTORY_SEPARATOR . basename($path);
        if (!is_file($fullPath)) apiFail(404, 'Imagem não encontrada.');
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($fullPath);
        if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
            apiFail(415, 'O arquivo armazenado não é uma imagem compatível.');
        }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($fullPath));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=3600');
        readfile($fullPath);
        exit;
    }

    if ($action === 'banco-itens' && $method === 'GET') {
        requireProfile($user, ['aluno', 'escola', 'assistente']);
        $staff = in_array($profile, ['escola', 'assistente'], true);
        $sql = 'SELECT i.id, i.categoria_id AS categoryId, c.nome AS category, c.slug AS categorySlug,
                       i.titulo AS title, i.descricao AS description, i.tamanho AS size,
                       i.condicao AS conditionLabel, i.quantidade_total AS totalQuantity,
                       i.quantidade_disponivel AS availableQuantity, i.caminho_imagem AS imagePath,
                       i.tipo AS itemType, i.doador AS donor, i.data_doacao AS donatedAt,
                       i.status, i.criado_em AS createdAt,
                       COALESCE(i.atualizado_em, i.criado_em) AS imageVersion
                FROM itens_solidarios i
                JOIN categorias_auxilio c ON c.id = i.categoria_id
                WHERE i.school_key = :school_key AND i.status <> :archived AND c.ativa = 1';
        if (!$staff) {
            $sql .= ' AND i.status = :available AND i.quantidade_disponivel > 0';
        }
        $sql .= ' ORDER BY c.nome, i.criado_em DESC, i.titulo';
        $statement = $database->prepare($sql);
        $params = [':school_key' => $schoolKey, ':archived' => 'arquivado'];
        if (!$staff) $params[':available'] = 'disponivel';
        $statement->execute($params);
        $items = array_map(static function (array $row): array {
            return [
                'id' => (int)$row['id'], 'categoryId' => (int)$row['categoryId'],
                'category' => $row['category'], 'categorySlug' => $row['categorySlug'],
                'title' => $row['title'], 'description' => $row['description'],
                'size' => $row['size'], 'condition' => $row['conditionLabel'],
                'totalQuantity' => (int)$row['totalQuantity'],
                'availableQuantity' => (int)$row['availableQuantity'],
                'imagePath' => preg_match('~^storage/solidarity/[a-f0-9]{32}\.(?:jpg|png|webp)$~', (string)$row['imagePath'])
                    ? 'api.php?action=banco-imagem&id=' . (int)$row['id'] . '&v=' . rawurlencode((string)$row['imageVersion'])
                    : $row['imagePath'],
                'itemType' => $row['itemType'],
                'donor' => $row['donor'], 'donatedAt' => $row['donatedAt'], 'status' => $row['status'],
                'createdAt' => $row['createdAt']
            ];
        }, $statement->fetchAll());
        $categories = $database->query('SELECT id, slug, nome AS name FROM categorias_auxilio WHERE ativa = 1 ORDER BY nome')->fetchAll();
        $categories = array_map(static fn(array $row): array => [
            'id' => (int)$row['id'], 'slug' => $row['slug'], 'name' => $row['name']
        ], $categories);
        apiResponse(200, ['items' => $items, 'categories' => $categories, 'canManage' => $staff]);
    }

    if ($action === 'banco-meus-pedidos' && $method === 'GET') {
        requireProfile($user, ['aluno']);
        $statement = $database->prepare(
            'SELECT s.id, s.item_id AS itemId, i.titulo AS itemTitle, c.nome AS category,
                    s.quantidade AS quantity, s.observacao AS note, s.tipo AS requestType,
                    s.prazo_devolucao AS dueDate, s.data_retirada AS pickupDate,
                    s.precisa_busca AS needPickup, s.status, s.requested_at AS requestedAt,
                    s.reviewed_at AS reviewedAt, s.delivered_at AS deliveredAt,
                    s.received_at AS receivedAt, s.returned_at AS returnedAt
             FROM solicitacoes_auxilio s
             JOIN itens_solidarios i ON i.id = s.item_id
             JOIN categorias_auxilio c ON c.id = i.categoria_id
             WHERE s.user_id = :user_id
             ORDER BY s.requested_at DESC LIMIT 100'
        );
        $statement->execute([':user_id' => $user['id']]);
        apiResponse(200, ['requests' => $statement->fetchAll()]);
    }

    if ($action === 'banco-pedidos' && $method === 'GET') {
        requireProfile($user, ['escola', 'assistente']);
        $statement = $database->prepare(
            'SELECT s.id, s.item_id AS itemId, i.titulo AS itemTitle, c.nome AS category,
                    s.quantidade AS quantity, s.observacao AS note, s.tipo AS requestType,
                    s.prazo_devolucao AS dueDate, s.data_retirada AS pickupDate,
                    s.precisa_busca AS needPickup, s.status, s.requested_at AS requestedAt,
                    s.reviewed_at AS reviewedAt, s.received_at AS receivedAt,
                    u.name AS studentName, u.email AS studentEmail
             FROM solicitacoes_auxilio s
             JOIN itens_solidarios i ON i.id = s.item_id
             JOIN categorias_auxilio c ON c.id = i.categoria_id
             JOIN usuarios u ON u.id = s.user_id
             WHERE s.school_key = :school_key
             ORDER BY FIELD(s.status, "pendente", "aprovado", "entregue", "devolvido", "recusado"), s.requested_at DESC
             LIMIT 150'
        );
        $statement->execute([':school_key' => $schoolKey]);
        apiResponse(200, ['requests' => $statement->fetchAll()]);
    }

    if ($action === 'banco-solicitar' && $method === 'POST') {
        requireProfile($user, ['aluno']);
        $itemId = filter_var($body['itemId'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($body['quantity'] ?? 1, FILTER_VALIDATE_INT);
        if (!$itemId || !$quantity || $quantity > 5) {
            apiFail(422, 'Escolha uma quantidade entre 1 e 5.');
        }
        $note = jsonField($body, 'note', 1000, false);
        $requestType = $body['requestType'] ?? 'doacao';
        if (!in_array($requestType, ['doacao', 'emprestimo'], true)) {
            apiFail(422, 'Escolha doação permanente ou empréstimo temporário.');
        }
        if (trim($note) === '') apiFail(422, 'Conte o motivo da solicitação.');
        $dueDate = $body['dueDate'] ?? '';
        $pickupDate = $body['pickupDate'] ?? '';
        if (!is_string($dueDate) || !is_string($pickupDate)) {
            apiFail(422, 'Informe datas válidas para a solicitação.');
        }
        foreach ([$dueDate, $pickupDate] as $date) {
            if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                apiFail(422, 'Informe uma data válida para retirada e devolução.');
            }
            if ($date !== '' && !checkdate((int)substr($date, 5, 2), (int)substr($date, 8, 2), (int)substr($date, 0, 4))) {
                apiFail(422, 'Informe uma data válida para retirada e devolução.');
            }
            if ($date !== '' && $date < gmdate('Y-m-d')) {
                apiFail(422, 'As datas da solicitação não podem estar no passado.');
            }
        }
        if ($requestType === 'emprestimo' && $dueDate === '') apiFail(422, 'Informe a data prevista para devolução.');
        if ($requestType === 'doacao') $dueDate = null;
        if ($pickupDate === '') $pickupDate = null;
        $needPickup = !empty($body['needPickup']) ? 1 : 0;
        $database->beginTransaction();
        $itemQuery = $database->prepare(
            'SELECT id, quantidade_disponivel AS available, titulo, tipo
             FROM itens_solidarios
             WHERE id = :id AND school_key = :school_key AND status = :status
             FOR UPDATE'
        );
        $itemQuery->execute([':id' => $itemId, ':school_key' => $schoolKey, ':status' => 'disponivel']);
        $item = $itemQuery->fetch();
        if (!$item) {
            $database->rollBack();
            apiFail(404, 'Este item não está mais disponível para sua escola.');
        }
        if ($item['tipo'] !== $requestType) {
            $database->rollBack();
            apiFail(422, 'O tipo de solicitação não corresponde à modalidade deste item.');
        }
        $pendingQuery = $database->prepare(
            'SELECT COALESCE(SUM(quantidade), 0) FROM solicitacoes_auxilio
             WHERE item_id = :item_id AND status = :status'
        );
        $pendingQuery->execute([':item_id' => $itemId, ':status' => 'pendente']);
        $reserved = (int)$pendingQuery->fetchColumn();
        if ((int)$item['available'] - $reserved < $quantity) {
            $database->rollBack();
            apiFail(409, 'A quantidade disponível já está reservada em outros pedidos.');
        }
        $id = newId();
        $now = gmdate('c');
        $insert = $database->prepare(
            'INSERT INTO solicitacoes_auxilio
                (id, item_id, user_id, school_key, quantidade, observacao, tipo, prazo_devolucao,
                 data_retirada, precisa_busca, status, requested_at)
             VALUES (:id, :item_id, :user_id, :school_key, :quantity, :note, :type, :due_date,
                     :pickup_date, :need_pickup, :status, :requested_at)'
        );
        $insert->execute([
            ':id' => $id, ':item_id' => $itemId, ':user_id' => $user['id'],
            ':school_key' => $schoolKey, ':quantity' => $quantity, ':note' => $note,
            ':type' => $requestType, ':due_date' => $dueDate, ':pickup_date' => $pickupDate,
            ':need_pickup' => $needPickup,
            ':status' => 'pendente', ':requested_at' => $now
        ]);
        $movement = $database->prepare(
            'INSERT INTO movimentacoes_auxilio
                (item_id, solicitacao_id, user_id, tipo_movimentacao, quantidade, observacao, criado_em)
             VALUES (:item_id, :request_id, :user_id, :type, :quantity, :note, :created_at)'
        );
        $movement->execute([
            ':item_id' => $itemId, ':request_id' => $id, ':user_id' => $user['id'],
            ':type' => 'pedido', ':quantity' => $quantity,             ':note' => 'Solicitação de ' . $requestType . ' enviada.', ':created_at' => $now
        ]);
        $database->commit();
        solidarityNotifyTeam(
            $database,
            $schoolKey,
            'Nova solicitação de ' . (string)$user['name'] . ' para ' . $item['titulo'] . '.',
            'nova_solicitacao'
        );
        apiResponse(201, ['request' => ['id' => $id, 'itemTitle' => $item['titulo'], 'status' => 'pendente']]);
    }

    if ($action === 'banco-revisar-solicitacao' && $method === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $requestId = jsonField($body, 'id', 32);
        $decision = $body['decision'] ?? '';
        if (!in_array($decision, ['aprovado', 'recusado', 'entregue'], true)) {
            apiFail(422, 'A decisão informada não é válida.');
        }
        $database->beginTransaction();
        $query = $database->prepare(
            'SELECT s.id, s.item_id, s.user_id, s.quantidade, s.status, s.data_retirada AS pickup_date,
                    i.quantidade_disponivel,
                    i.titulo AS item_title, i.tipo AS item_type, i.status AS item_status
             FROM solicitacoes_auxilio s
             JOIN itens_solidarios i ON i.id = s.item_id
             WHERE s.id = :id AND s.school_key = :school_key
             FOR UPDATE'
        );
        $query->execute([':id' => $requestId, ':school_key' => $schoolKey]);
        $request = $query->fetch();
        if (!$request) {
            $database->rollBack();
            apiFail(404, 'Pedido não encontrado para esta escola.');
        }
        $now = gmdate('c');
        if ($decision === 'aprovado' || $decision === 'recusado') {
            if ($request['status'] !== 'pendente') {
                $database->rollBack();
                apiFail(409, 'Este pedido já foi analisado.');
            }
            if ($decision === 'aprovado') {
                if ($request['item_status'] !== 'disponivel') {
                    $database->rollBack();
                    apiFail(409, 'Este item foi marcado como indisponível e não pode ser aprovado.');
                }
                if ((int)$request['quantidade_disponivel'] < (int)$request['quantidade']) {
                    $database->rollBack();
                    apiFail(409, 'O estoque foi alterado e não atende mais a quantidade deste pedido.');
                }
                $remaining = (int)$request['quantidade_disponivel'] - (int)$request['quantidade'];
                $database->prepare(
                    'UPDATE itens_solidarios SET quantidade_disponivel = :quantity, status = :status, atualizado_em = :updated_at WHERE id = :id'
                )->execute([
                    ':quantity' => $remaining, ':status' => $remaining > 0 ? 'disponivel' : 'esgotado',
                    ':updated_at' => $now, ':id' => $request['item_id']
                ]);
            }
            $database->prepare(
                'UPDATE solicitacoes_auxilio SET status = :status, reviewed_at = :reviewed_at, reviewed_by = :reviewed_by WHERE id = :id'
            )->execute([
                ':status' => $decision, ':reviewed_at' => $now, ':reviewed_by' => $user['id'], ':id' => $requestId
            ]);
            $movement = $database->prepare(
                'INSERT INTO movimentacoes_auxilio
                    (item_id, solicitacao_id, user_id, tipo_movimentacao, quantidade, observacao, criado_em)
                 VALUES (:item_id, :request_id, :user_id, :type, :quantity, :note, :created_at)'
            );
            $movement->execute([
                ':item_id' => $request['item_id'], ':request_id' => $requestId, ':user_id' => $user['id'],
                ':type' => $decision, ':quantity' => $request['quantidade'],
                ':note' => $decision === 'aprovado' ? 'Pedido aprovado; estoque reservado.' : 'Pedido recusado.',
                ':created_at' => $now
            ]);
        } else {
            if ($request['status'] !== 'aprovado') {
                $database->rollBack();
                apiFail(409, 'Somente pedidos aprovados podem ser marcados como entregues.');
            }
            $database->prepare('UPDATE solicitacoes_auxilio SET status = :status, delivered_at = :delivered_at WHERE id = :id')
                ->execute([':status' => 'entregue', ':delivered_at' => $now, ':id' => $requestId]);
            $database->prepare(
                'INSERT INTO movimentacoes_auxilio
                    (item_id, solicitacao_id, user_id, tipo_movimentacao, quantidade, observacao, criado_em)
                 VALUES (:item_id, :request_id, :user_id, :type, :quantity, :note, :created_at)'
            )->execute([
                ':item_id' => $request['item_id'], ':request_id' => $requestId, ':user_id' => $user['id'],
                ':type' => 'entrega', ':quantity' => $request['quantidade'],
                ':note' => 'Item entregue ao estudante.', ':created_at' => $now
            ]);
        }
        $database->commit();
        if ($decision === 'aprovado' || $decision === 'recusado') {
            $message = $decision === 'aprovado'
                ? 'Seu pedido de ' . $request['item_title'] . ' foi aprovado!' .
                    ($request['pickup_date'] ? ' Sua data preferencial para retirada é ' . $request['pickup_date'] . '.' : ' A equipe combinará a retirada com você.')
                : 'Sua solicitação de ' . $request['item_title'] . ' precisa de outra solução. Procure a equipe da escola.';
            solidarityNotify($database, (int)$request['user_id'], $message, 'pedido_' . $decision);
        } elseif ($decision === 'entregue') {
            solidarityNotify(
                $database,
                (int)$request['user_id'],
                'Confirme o recebimento do item ' . $request['item_title'] . ' com a equipe da escola.',
                'item_entregue'
            );
            solidarityNotifyTeam(
                $database,
                $schoolKey,
                (string)$user['name'] . ' registrou a entrega do item ' . $request['item_title'] . '.',
                'item_entregue'
            );
        }
        apiResponse(200, ['message' => 'O acompanhamento do pedido foi atualizado.', 'status' => $decision]);
    }

    if ($action === 'banco-cadastrar-item' && $method === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $title = jsonField($body, 'title', 160);
        $description = jsonField($body, 'description', 1600);
        $size = jsonField($body, 'size', 80, false);
        $condition = jsonField($body, 'condition', 80, false) ?: 'Novo ou em ótimo estado';
        $donor = jsonField($body, 'donor', 120, false) ?: 'Anônimo';
        $donatedAt = $body['donatedAt'] ?? '';
        $categoryId = filter_var($body['categoryId'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($body['quantity'] ?? null, FILTER_VALIDATE_INT);
        $itemType = $body['itemType'] ?? 'doacao';
        if (!in_array($itemType, ['doacao', 'emprestimo'], true)) {
            apiFail(422, 'Escolha doação permanente ou empréstimo temporário.');
        }
        if (!$categoryId || !$quantity || $quantity > 1000) {
            apiFail(422, 'Informe uma categoria e uma quantidade entre 1 e 1000.');
        }
        if (!is_string($donatedAt) || ($donatedAt !== '' &&
            (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $donatedAt) ||
             !checkdate((int)substr($donatedAt, 5, 2), (int)substr($donatedAt, 8, 2), (int)substr($donatedAt, 0, 4))))) {
            apiFail(422, 'Informe uma data de doação válida.');
        }
        if ($donatedAt !== '' && $donatedAt > gmdate('Y-m-d')) apiFail(422, 'A data da doação não pode estar no futuro.');
        $categoryQuery = $database->prepare('SELECT slug FROM categorias_auxilio WHERE id = :id AND ativa = 1');
        $categoryQuery->execute([':id' => $categoryId]);
        $categorySlug = $categoryQuery->fetchColumn();
        if (!$categorySlug) apiFail(422, 'A categoria selecionada não está disponível.');
        $uploadedImage = solidarityStoreImage();
        $imagePath = $uploadedImage ?? solidarityDefaultImage((string)$categorySlug, $title);
        $insert = $database->prepare(
            'INSERT INTO itens_solidarios
                (categoria_id, school_key, titulo, descricao, tamanho, condicao, quantidade_total,
                 quantidade_disponivel, caminho_imagem, tipo, doador, data_doacao, status, criado_por, criado_em)
             VALUES (:category_id, :school_key, :title, :description, :size, :condition, :total,
                     :available, :image, :type, :donor, :donated_at, :status, :created_by, :created_at)'
        );
        try {
            $insert->execute([
                ':category_id' => $categoryId, ':school_key' => $schoolKey, ':title' => $title,
                ':description' => $description, ':size' => $size, ':condition' => $condition,
                ':total' => $quantity, ':available' => $quantity, ':image' => $imagePath,
                ':type' => $itemType,
                ':donor' => $donor, ':donated_at' => $donatedAt === '' ? null : $donatedAt,
                ':status' => 'disponivel', ':created_by' => $user['id'], ':created_at' => gmdate('c')
            ]);
        } catch (Throwable $error) {
            solidarityRemoveImage($uploadedImage);
            throw $error;
        }
        apiResponse(201, ['message' => 'Item adicionado ao Banco Solidário.', 'itemId' => (int)$database->lastInsertId()]);
    }

    if ($action === 'banco-editar-item' && $method === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $itemId = filter_var($body['itemId'] ?? null, FILTER_VALIDATE_INT);
        $categoryId = filter_var($body['categoryId'] ?? null, FILTER_VALIDATE_INT);
        $quantity = filter_var($body['quantity'] ?? null, FILTER_VALIDATE_INT);
        $title = jsonField($body, 'title', 160);
        $description = jsonField($body, 'description', 1600);
        $size = jsonField($body, 'size', 80, false);
        $condition = jsonField($body, 'condition', 80, false);
        $donor = jsonField($body, 'donor', 120, false) ?: 'Anônimo';
        $donatedAt = $body['donatedAt'] ?? '';
        $itemType = $body['itemType'] ?? '';
        if (!$itemId || !$categoryId || !$quantity || $quantity > 1000 ||
            !in_array($itemType, ['doacao', 'emprestimo'], true)) {
            apiFail(422, 'Confira categoria, modalidade e quantidade do item.');
        }
        if (!is_string($donatedAt) || ($donatedAt !== '' &&
            (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $donatedAt) ||
             !checkdate((int)substr($donatedAt, 5, 2), (int)substr($donatedAt, 8, 2), (int)substr($donatedAt, 0, 4))))) {
            apiFail(422, 'Informe uma data de doação válida.');
        }
        if ($donatedAt !== '' && $donatedAt > gmdate('Y-m-d')) apiFail(422, 'A data da doação não pode estar no futuro.');
        $database->beginTransaction();
        $currentQuery = $database->prepare(
            'SELECT quantidade_disponivel, status, tipo, caminho_imagem FROM itens_solidarios
             WHERE id = :id AND school_key = :school_key AND status <> :archived FOR UPDATE'
        );
        $currentQuery->execute([':id' => $itemId, ':school_key' => $schoolKey, ':archived' => 'arquivado']);
        $current = $currentQuery->fetch();
        if (!$current) {
            $database->rollBack();
            apiFail(404, 'Item não encontrado para esta escola.');
        }
        if ($current['tipo'] !== $itemType) {
            $activeRequests = $database->prepare(
                'SELECT COUNT(*) FROM solicitacoes_auxilio
                 WHERE item_id = :item_id AND status IN (:pending, :approved, :delivered)'
            );
            $activeRequests->execute([
                ':item_id' => $itemId, ':pending' => 'pendente',
                ':approved' => 'aprovado', ':delivered' => 'entregue'
            ]);
            if ((int)$activeRequests->fetchColumn() > 0) {
                $database->rollBack();
                apiFail(409, 'Não é possível alterar a modalidade enquanto houver solicitações em andamento.');
            }
        }
        $categoryQuery = $database->prepare('SELECT id FROM categorias_auxilio WHERE id = :id AND ativa = 1');
        $categoryQuery->execute([':id' => $categoryId]);
        if (!$categoryQuery->fetchColumn()) {
            $database->rollBack();
            apiFail(422, 'A categoria selecionada não está disponível.');
        }
        $allocatedQuery = $database->prepare(
            'SELECT COALESCE(SUM(quantidade), 0) FROM solicitacoes_auxilio
             WHERE item_id = :item_id AND status IN (:approved, :delivered)'
        );
        $allocatedQuery->execute([
            ':item_id' => $itemId, ':approved' => 'aprovado', ':delivered' => 'entregue'
        ]);
        $allocated = (int)$allocatedQuery->fetchColumn();
        $pendingQuery = $database->prepare(
            'SELECT COALESCE(SUM(quantidade), 0) FROM solicitacoes_auxilio
             WHERE item_id = :item_id AND status = :status'
        );
        $pendingQuery->execute([':item_id' => $itemId, ':status' => 'pendente']);
        $pending = (int)$pendingQuery->fetchColumn();
        if ($quantity < $allocated + $pending) {
            $database->rollBack();
            apiFail(422, 'A quantidade total não pode ficar abaixo dos pedidos pendentes, itens reservados ou entregues.');
        }
        $available = $quantity - $allocated;
        $itemStatus = $current['status'] === 'indisponivel'
            ? 'indisponivel'
            : ($available > 0 ? 'disponivel' : 'esgotado');
        $uploadedImage = solidarityStoreImage();
        $imagePath = $uploadedImage ?? $current['caminho_imagem'];
        try {
            $database->prepare(
            'UPDATE itens_solidarios SET categoria_id = :category_id, titulo = :title, descricao = :description,
             tamanho = :size, condicao = :condition, quantidade_total = :total,
             quantidade_disponivel = :available, tipo = :type, doador = :donor, caminho_imagem = :image,
             data_doacao = :donated_at, status = :status, atualizado_em = :updated_at
             WHERE id = :id AND school_key = :school_key'
            )->execute([
                ':category_id' => $categoryId, ':title' => $title, ':description' => $description,
                ':size' => $size, ':condition' => $condition, ':total' => $quantity,
                ':available' => $available, ':type' => $itemType, ':status' => $itemStatus,
                ':donor' => $donor, ':image' => $imagePath,
                ':donated_at' => $donatedAt === '' ? null : $donatedAt,
                ':updated_at' => gmdate('c'), ':id' => $itemId, ':school_key' => $schoolKey
            ]);
            $database->commit();
        } catch (Throwable $error) {
            if ($database->inTransaction()) $database->rollBack();
            solidarityRemoveImage($uploadedImage);
            throw $error;
        }
        if ($uploadedImage) solidarityRemoveImage($current['caminho_imagem']);
        apiResponse(200, ['message' => 'Item atualizado no Banco Solidário.']);
    }

    if ($action === 'banco-indisponibilizar-item' && $method === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $itemId = filter_var($body['itemId'] ?? null, FILTER_VALIDATE_INT);
        if (!$itemId) apiFail(422, 'Item inválido.');
        $statement = $database->prepare(
            'UPDATE itens_solidarios SET status = :status, atualizado_em = :updated_at
             WHERE id = :id AND school_key = :school_key AND status <> :archived'
        );
        $statement->execute([
            ':status' => 'indisponivel', ':updated_at' => gmdate('c'), ':id' => $itemId,
            ':school_key' => $schoolKey, ':archived' => 'arquivado'
        ]);
        if (!$statement->rowCount()) apiFail(404, 'Item não encontrado ou já indisponível.');
        apiResponse(200, ['message' => 'Item marcado como indisponível.']);
    }

    if ($action === 'banco-devolver-item' && $method === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $requestId = jsonField($body, 'id', 32);
        $database->beginTransaction();
        $query = $database->prepare(
            'SELECT s.id, s.item_id, s.user_id, s.quantidade, s.status, s.tipo, i.titulo,
                    i.status AS item_status
             FROM solicitacoes_auxilio s JOIN itens_solidarios i ON i.id = s.item_id
             WHERE s.id = :id AND s.school_key = :school_key FOR UPDATE'
        );
        $query->execute([':id' => $requestId, ':school_key' => $schoolKey]);
        $request = $query->fetch();
        if (!$request || $request['status'] !== 'entregue' || $request['tipo'] !== 'emprestimo') {
            $database->rollBack();
            apiFail(409, 'Somente empréstimos entregues podem ser registrados como devolvidos.');
        }
        $now = gmdate('c');
        $database->prepare('UPDATE solicitacoes_auxilio SET status = :status, returned_at = :returned_at WHERE id = :id')
            ->execute([':status' => 'devolvido', ':returned_at' => $now, ':id' => $requestId]);
        $database->prepare(
            'UPDATE itens_solidarios SET quantidade_disponivel = quantidade_disponivel + :quantity,
             status = :status, atualizado_em = :updated_at WHERE id = :id AND school_key = :school_key'
        )->execute([
            ':quantity' => $request['quantidade'],
            ':status' => $request['item_status'] === 'indisponivel' ? 'indisponivel' : 'disponivel',
            ':updated_at' => $now,
            ':id' => $request['item_id'], ':school_key' => $schoolKey
        ]);
        $database->prepare(
            'INSERT INTO movimentacoes_auxilio
             (item_id, solicitacao_id, user_id, tipo_movimentacao, quantidade, observacao, criado_em)
             VALUES (:item_id, :request_id, :user_id, :type, :quantity, :note, :created_at)'
        )->execute([
            ':item_id' => $request['item_id'], ':request_id' => $requestId, ':user_id' => $user['id'],
            ':type' => 'devolucao', ':quantity' => $request['quantidade'],
            ':note' => 'Empréstimo devolvido e disponível novamente.', ':created_at' => $now
        ]);
        $database->commit();
        $waiting = $database->prepare(
            'SELECT DISTINCT user_id FROM solicitacoes_auxilio
             WHERE item_id = :item_id AND school_key = :school_key AND status = :status'
        );
        $waiting->execute([
            ':item_id' => $request['item_id'], ':school_key' => $schoolKey, ':status' => 'recusado'
        ]);
        foreach ($waiting->fetchAll(PDO::FETCH_COLUMN) as $studentId) {
            solidarityNotify(
                $database,
                (int)$studentId,
                'O item ' . $request['titulo'] . ' que você solicitou está disponível novamente.',
                'item_disponivel'
            );
        }
        solidarityNotify(
            $database,
            (int)$request['user_id'],
            'Obrigado por devolver o item ' . $request['titulo'] . '.',
            'item_devolvido'
        );
        solidarityNotifyTeam(
            $database,
            $schoolKey,
            'O item ' . $request['titulo'] . ' foi devolvido e está disponível novamente.',
            'item_disponivel'
        );
        apiResponse(200, ['message' => 'Devolução registrada e estoque atualizado.']);
    }

    if ($action === 'banco-notificacoes' && $method === 'GET') {
        requireProfile($user, ['aluno', 'escola', 'assistente']);
        $statement = $database->prepare(
            'SELECT id, mensagem AS message, tipo AS type, criada_em AS createdAt
             FROM notificacoes_solidarias WHERE user_id = :user_id ORDER BY criada_em DESC LIMIT 30'
        );
        $statement->execute([':user_id' => $user['id']]);
        $notifications = $statement->fetchAll();
        $dueDate = gmdate('Y-m-d', strtotime('+3 days'));
        if ($profile === 'aluno') {
            $due = $database->prepare(
                'SELECT i.titulo, s.prazo_devolucao FROM solicitacoes_auxilio s
                 JOIN itens_solidarios i ON i.id = s.item_id
                 WHERE s.user_id = :user_id AND s.tipo = :type AND s.status = :status
                 AND s.prazo_devolucao IS NOT NULL AND s.prazo_devolucao <= :due_date
                 ORDER BY s.prazo_devolucao LIMIT 10'
            );
            $due->execute([':user_id' => $user['id'], ':type' => 'emprestimo', ':status' => 'entregue', ':due_date' => $dueDate]);
            foreach ($due->fetchAll() as $loan) {
                $daysRemaining = (int)floor((strtotime($loan['prazo_devolucao']) - strtotime(gmdate('Y-m-d'))) / 86400);
                $reminder = $daysRemaining < 0
                    ? 'está com a devolução atrasada'
                    : ($daysRemaining === 0 ? 'deve ser devolvido hoje' : 'deve ser devolvido em ' . $daysRemaining . ' dia(s)');
                array_unshift($notifications, [
                    'message' => 'Lembrete: o item ' . $loan['titulo'] . ' ' . $reminder . ' (prazo: ' . $loan['prazo_devolucao'] . ').',
                    'type' => 'lembrete_devolucao',
                    'createdAt' => gmdate('c')
                ]);
            }
        } else {
            $due = $database->prepare(
                'SELECT i.titulo, s.prazo_devolucao, u.name AS student_name
                 FROM solicitacoes_auxilio s JOIN itens_solidarios i ON i.id = s.item_id
                 JOIN usuarios u ON u.id = s.user_id
                 WHERE s.school_key = :school_key AND s.tipo = :type AND s.status = :status
                 AND s.prazo_devolucao IS NOT NULL AND s.prazo_devolucao <= :due_date
                 ORDER BY s.prazo_devolucao LIMIT 10'
            );
            $due->execute([
                ':school_key' => $schoolKey, ':type' => 'emprestimo',
                ':status' => 'entregue', ':due_date' => $dueDate
            ]);
            foreach ($due->fetchAll() as $loan) {
                $daysRemaining = (int)floor((strtotime($loan['prazo_devolucao']) - strtotime(gmdate('Y-m-d'))) / 86400);
                $reminder = $daysRemaining < 0
                    ? 'está com a devolução atrasada'
                    : ($daysRemaining === 0 ? 'vence hoje' : 'vence em ' . $daysRemaining . ' dia(s)');
                array_unshift($notifications, [
                    'message' => 'Item ' . $loan['titulo'] . ' de ' . $loan['student_name'] .
                        ' ' . $reminder . ' (' . $loan['prazo_devolucao'] . ').',
                    'type' => 'lembrete_devolucao',
                    'createdAt' => gmdate('c')
                ]);
            }
        }
        apiResponse(200, ['notifications' => $notifications]);
    }

    if ($action === 'banco-confirmar-recebimento' && $method === 'POST') {
        requireProfile($user, ['aluno']);
        $requestId = jsonField($body, 'id', 32);
        $statement = $database->prepare(
            'UPDATE solicitacoes_auxilio SET received_at = :received_at
             WHERE id = :id AND user_id = :user_id AND status = :status AND received_at IS NULL'
        );
        $statement->execute([
            ':received_at' => gmdate('c'), ':id' => $requestId,
            ':user_id' => $user['id'], ':status' => 'entregue'
        ]);
        if (!$statement->rowCount()) apiFail(409, 'Este pedido não está aguardando confirmação de recebimento.');
        $requestQuery = $database->prepare(
            'SELECT s.school_key, i.titulo FROM solicitacoes_auxilio s
             JOIN itens_solidarios i ON i.id = s.item_id WHERE s.id = :id'
        );
        $requestQuery->execute([':id' => $requestId]);
        $request = $requestQuery->fetch();
        if ($request) {
            solidarityNotifyTeam(
                $database,
                $request['school_key'],
                (string)$user['name'] . ' confirmou o recebimento do item ' . $request['titulo'] . '.',
                'recebimento_confirmado'
            );
        }
        apiResponse(200, ['message' => 'Recebimento confirmado.']);
    }

    if ($action === 'banco-relatorio' && $method === 'GET') {
        requireProfile($user, ['escola', 'assistente']);
        $statement = $database->prepare(
            'SELECT i.id, i.titulo AS title, c.nome AS category, i.tipo AS itemType,
                    i.doador AS donor, i.data_doacao AS donatedAt,
                    i.condicao AS conditionLabel, i.quantidade_total AS totalQuantity,
                    i.quantidade_disponivel AS availableQuantity, i.status,
                    COUNT(DISTINCT s.id) AS requestCount,
                    COALESCE(SUM(CASE WHEN s.status = "entregue" THEN s.quantidade ELSE 0 END), 0) AS deliveredQuantity
             FROM itens_solidarios i JOIN categorias_auxilio c ON c.id = i.categoria_id
             LEFT JOIN solicitacoes_auxilio s ON s.item_id = i.id
             WHERE i.school_key = :school_key
             GROUP BY i.id, i.titulo, c.nome, i.tipo, i.doador, i.data_doacao,
                      i.condicao, i.quantidade_total,
                      i.quantidade_disponivel, i.status
             ORDER BY c.nome, i.titulo'
        );
        $statement->execute([':school_key' => $schoolKey]);
        apiResponse(200, ['items' => $statement->fetchAll()]);
    }

    apiFail(404, 'Ação do Banco Solidário desconhecida.');
}
