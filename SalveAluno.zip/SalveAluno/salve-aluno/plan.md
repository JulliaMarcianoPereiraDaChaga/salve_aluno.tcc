# Plano — Salve Aluno

## Escopo e abordagem

Atualizar a aplicação existente em PHP, JavaScript e MySQL sem trocar seu fluxo de autenticação nem remover painéis e recursos atuais. O Banco Solidário terá catálogo de doações por escola, pedidos vinculados ao aluno, estados de acompanhamento e controle de estoque. O diagnóstico será um questionário curto por perfil (`aluno`, `professor`, `escola` e `assistente`), persistido no banco; o perfil `admin` será excluído da interface e também recusado pela API. O esquema de dados usará 15 nomes de tabelas em português e manterá os dados e relacionamentos já existentes em uma nomenclatura compatível com as consultas atuais.

## Direção visual

Opções consideradas: editorial de acolhimento comunitário (0,07); neo-brutalismo escolar (0,04); minimalismo clínico (0,02). Escolha: **editorial de acolhimento comunitário**.

- **Movimento:** design editorial contemporâneo, com referências a publicações de impacto social e produtos digitais de serviços comunitários.
- **Princípios:** acolhedor sem infantilizar; legível antes de decorativo; informação sensível apresentada com discrição; ações principais evidentes.
- **Cores:** verde-floresta para confiança e continuidade, creme para calor e leitura, limão suave para ações positivas e terracota para sinais que precisam de atenção.
- **Layout:** áreas de conteúdo assimétricas com blocos editoriais e fotografia contextual, em vez de uma sequência de caixas iguais; navegação responsiva e simples em telas pequenas.
- **Elementos assinatura:** pílulas de status suaves; pequenos marcadores orgânicos inspirados em sementes; fotografia documental luminosa.
- **Interação:** ações diretas, linguagem clara, estados de carregamento e confirmação, e validação compreensível sem expor dados pessoais.
- **Animação:** transições breves de opacidade e deslocamento nos cartões; respeitar `prefers-reduced-motion`.
- **Tipografia:** Manrope para títulos e DM Sans para texto e controles; hierarquia com títulos expressivos, corpo confortável e microtexto legível.
- **Essência:** apoio escolar discreto e prático para estudantes e equipes encontrarem próximos passos; personalidade acolhedora, confiável e respeitosa.
- **Tom:** humano, direto e sem julgamento. Exemplos: “O que você precisa para seguir estudando?” e “Cada pedido tem um próximo passo — acompanhe por aqui.”
- **Marca:** manter o nome `salve.aluno` e a marca em “S”, refinando o símbolo para sugerir conexão e continuidade.
- **Cor proprietária:** verde-floresta profundo.

## Implementação e estrutura

- `index.php`, `login.php` e os painéis existentes: preservar fluxos atuais, atualizar tipografia e conectar atalhos relevantes.
- `banco-solidario.php`: catálogo para alunos e área de inventário/pedidos para gestão escolar e assistência social.
- `diagnostico.php`: formulário e resultado específicos do perfil autenticado, exceto administrador.
- `api.php`: novas ações autenticadas para catálogo, solicitações de doação, revisão de pedidos e diagnósticos; manter proteção CSRF, escopo por escola e transações de estoque.
- `database/schema.sql`: 15 tabelas em português. Tabelas atuais passam a ter nomes portugueses, preservando colunas esperadas pelo backend; acrescentar categorias, itens, solicitações, movimentações e diagnóstico/respostas.
- `tools/install-default-users.php`: instalação idempotente de cinco contas de demonstração com os perfis e as senhas informados; executar apenas em CLI.
- `assets/images/`: imagens originais para acolhimento e categorias de doação; carregar fontes Manrope e DM Sans.
- `css/` e `js/`: estilos responsivos e módulos de interface novos, sem dependência de framework adicional.

## Modelo de dados (15 tabelas)

`usuarios`, `solicitacoes_cadastro`, `registros`, `arquivos_registro`, `reunioes`, `participantes_reuniao`, `encerramentos_reuniao`, `mensagens_seguras`, `limites_tentativa`, `categorias_auxilio`, `itens_solidarios`, `solicitacoes_auxilio`, `movimentacoes_auxilio`, `diagnosticos` e `respostas_diagnostico`.
