<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'api.php';

function promptSecret(string $prompt): string
{
    fwrite(STDOUT, $prompt);
    $value = fgets(STDIN);
    return is_string($value) ? trim($value) : '';
}

$arguments = $argv;
array_shift($arguments);
$command = array_shift($arguments) ?? '';
$database = apiDatabase();

if ($command === 'create') {
    [$email, $profile, $name, $schoolName] = array_pad($arguments, 4, '');
    $email = strtolower(trim($email));
    $profile = trim($profile);
    $name = trim($name);
    $schoolName = trim($schoolName);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !in_array($profile, ['aluno', 'professor', 'escola', 'assistente'], true) ||
        $name === '' || $schoolName === '') {
        fwrite(STDERR, "Uso: php tools/manage-user.php create email perfil nome \"nome da escola\"\n");
        exit(2);
    }
    $password = promptSecret("Senha (mínimo de 8 caracteres): ");
    if (strlen($password) < 8) {
        fwrite(STDERR, "A senha deve ter pelo menos 8 caracteres.\n");
        exit(2);
    }
    $statement = $database->prepare(
        'INSERT INTO users
            (email, password_hash, profile, name, details_json, quiz_json, preferences_json, school_key, created_at)
         VALUES (:email, :password_hash, :profile, :name, :details, :quiz, :preferences, :school_key, :created_at)'
    );
    try {
        $statement->execute([
            ':email' => $email,
            ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ':profile' => $profile,
            ':name' => $name,
            ':details' => '{}',
            ':quiz' => '{}',
            ':preferences' => '{}',
            ':school_key' => schoolKeyForName($schoolName),
            ':created_at' => gmdate('c')
        ]);
    } catch (PDOException $error) {
        if (isDuplicateKey($error)) {
            fwrite(STDERR, "Este e-mail já está cadastrado.\n");
            exit(1);
        }
        throw $error;
    }
    fwrite(STDOUT, "Conta criada para o perfil {$profile}.\n");
    exit(0);
}

if ($command === 'password') {
    [$email] = array_pad($arguments, 1, '');
    $email = strtolower(trim($email));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fwrite(STDERR, "Uso: php tools/manage-user.php password email\n");
        exit(2);
    }
    $password = promptSecret("Nova senha (mínimo de 8 caracteres): ");
    if (strlen($password) < 8) {
        fwrite(STDERR, "A senha deve ter pelo menos 8 caracteres.\n");
        exit(2);
    }
    $statement = $database->prepare('UPDATE users SET password_hash = :password_hash WHERE email = :email');
    $statement->execute([
        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ':email' => $email
    ]);
    if ($statement->rowCount() !== 1) {
        fwrite(STDERR, "Nenhuma conta foi encontrada com esse e-mail.\n");
        exit(1);
    }
    fwrite(STDOUT, "Senha atualizada.\n");
    exit(0);
}

fwrite(STDERR, "Comandos disponíveis: create, password.\n");
exit(2);
