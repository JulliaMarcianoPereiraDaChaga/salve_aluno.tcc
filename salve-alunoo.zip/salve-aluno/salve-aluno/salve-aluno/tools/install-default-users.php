<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'api.php';

$defaults = [
    ['admin@salvealuno.local', 'admin', 'Administrador Salve Aluno', 'Escola Municipal', 'Admin@2026!'],
    ['aluno@escola.edu.br', 'aluno', 'Aluno Padrão', 'Escola Municipal', 'Aluno@2026!'],
    ['professor@escola.edu.br', 'professor', 'Professor Padrão', 'Escola Municipal', 'Professor@2026!'],
    ['gestao@escola.edu.br', 'escola', 'Gestão Escolar', 'Escola Municipal', 'Gestao@2026!'],
    ['assistente@escola.edu.br', 'assistente', 'Assistente Social', 'Escola Municipal', 'Assistente@2026!'],
];

$database = apiDatabase();
$find = $database->prepare('SELECT id FROM users WHERE email = :email');
$insert = $database->prepare(
    'INSERT INTO users
        (email, password_hash, profile, name, details_json, quiz_json, preferences_json, school_key, created_at)
     VALUES (:email, :password_hash, :profile, :name, :details, :quiz, :preferences, :school_key, :created_at)'
);

foreach ($defaults as [$email, $profile, $name, $schoolName, $password]) {
    $find->execute([':email' => $email]);
    if ($find->fetchColumn()) {
        fwrite(STDOUT, "Já existe: {$email}\n");
        continue;
    }
    $insert->execute([
        ':email' => $email,
        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ':profile' => $profile,
        ':name' => $name,
        ':details' => '{}',
        ':quiz' => '{}',
        ':preferences' => '{}',
        ':school_key' => schoolKeyForName($schoolName),
        ':created_at' => gmdate('c'),
    ]);
    fwrite(STDOUT, "Criado: {$email} ({$profile})\n");
}

fwrite(STDOUT, "Instalação das contas padrão concluída.\n");
