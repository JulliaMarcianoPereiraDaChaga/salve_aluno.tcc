<?php declare(strict_types=1); ?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador | Salve Aluno</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/role-dashboards.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body class="role-app" data-required-role="admin">
<header class="role-topbar">
    <a class="role-brand" href="index.php"><span class="role-mark">S</span>salve.aluno</a>
    <div class="role-user"><div><strong id="adminName">Administrador</strong><small>Controle da plataforma</small></div><button type="button" onclick="logout()">Sair</button></div>
</header>
<main class="role-main">
    <div class="role-heading"><div><p class="eyebrow">Administração</p><h1>Usuários e acessos</h1><p>Crie contas, redefina senhas e mantenha os perfis da rede sob controle.</p></div><div class="role-actions"><button class="role-button" type="button" id="openCreateUser">Novo usuário</button></div></div>
    <section class="role-grid admin-stats"><article class="role-stat"><span>Total de usuários</span><strong id="totalUsers">—</strong><span class="trend">Contas cadastradas</span></article><article class="role-stat"><span>Alunos</span><strong id="totalAlunos">—</strong><span>Perfil estudantil</span></article><article class="role-stat"><span>Equipe escolar</span><strong id="totalEquipe">—</strong><span>Professores e gestão</span></article><article class="role-stat"><span>Administradores</span><strong id="totalAdmins">—</strong><span>Controle restrito</span></article></section>
    <section class="role-card"><div class="admin-card-heading"><div><h2>Contas cadastradas</h2><p>As senhas nunca são exibidas nesta tela.</p></div><input id="userSearch" type="search" placeholder="Buscar por nome ou e-mail"></div><div id="adminMessage" class="admin-message" role="status"></div><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Usuário</th><th>Perfil</th><th>Escola</th><th>Criado em</th><th>Ações</th></tr></thead><tbody id="usersTable"><tr><td colspan="5" class="role-empty">Carregando usuários...</td></tr></tbody></table></div></section>
</main>
<div class="modal-backdrop" id="userModal" hidden><form class="role-modal" id="userForm"><header><h2 id="modalTitle">Novo usuário</h2><button class="role-modal-close" type="button" data-close-modal>×</button></header><label>Nome<input name="name" required maxlength="120"></label><label>E-mail<input name="email" type="email" required maxlength="254"></label><label>Perfil<select name="profile" required><option value="aluno">Aluno</option><option value="professor">Professor</option><option value="escola">Gestão escolar</option><option value="assistente">Assistente social</option><option value="admin">Administrador</option></select></label><label>Escola<input name="schoolName" value="Escola Municipal" required maxlength="120"></label><label>Senha<input name="password" type="password" minlength="8" required><small class="field-help">Mínimo de 8 caracteres.</small></label><button class="role-button" type="submit">Criar usuário</button><p id="userFormMessage" class="admin-message"></p></form></div>
<script src="js/api-client.js"></script><script src="js/login.js"></script><script src="js/admin.js"></script>
</body>
</html>
