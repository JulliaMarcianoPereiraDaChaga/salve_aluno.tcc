# Salve Aluno — PHP + MySQL

O projeto agora usa páginas `.php` e uma API PHP com PDO para persistência no MySQL/MariaDB. Não abra os arquivos com `file://`: use Apache/XAMPP ou o servidor embutido do PHP.

## Instalação no XAMPP/Apache

1. Ative Apache, MySQL/MariaDB, `pdo_mysql` e `fileinfo`.
2. Copie esta pasta para `htdocs/salve-aluno`.
3. Importe `database/schema.sql` pelo phpMyAdmin.
4. Configure as variáveis `SALVE_DB_HOST`, `SALVE_DB_NAME`, `SALVE_DB_USER` e `SALVE_DB_PASSWORD` no ambiente do Apache. Os padrões são `127.0.0.1`, `salve_aluno`, `root` e senha vazia.
5. Abra `http://localhost/salve-aluno/` (a entrada é `index.php`).
6. Crie as contas padrão executando `php tools/install-default-users.php`.
7. Abra `http://localhost/salve-aluno/login.php` para entrar.

## Estrutura

- `index.php`, `login.php` e `dashboard-*.php`: páginas PHP da aplicação.
- `api.php`: API principal com sessão, CSRF, autenticação e persistência.
- `config/database.php`: conexão/configuração PDO do banco.
- `database/schema.sql`: criação do banco e tabelas.
- `api/`: endpoints complementares JSON.
- `css/`, `js/` e `assets/`: interface e recursos estáticos.

O navegador continua usando JavaScript para chamadas assíncronas, mas todas as páginas e a camada de dados são executadas pelo PHP no servidor.


## Área do administrador

O perfil `admin` acessa `admin.php` e pode listar usuários, criar contas para todos os perfis, redefinir senhas e excluir contas que não sejam a própria conta administradora. Todas as operações são protegidas por sessão, CSRF e verificação de perfil no servidor.

Para instalar os usuários padrão:

```bash
php tools/install-default-users.php
```

Credenciais iniciais de desenvolvimento:

| Perfil | E-mail | Senha |
|---|---|---|
| Administrador | `admin@salvealuno.local` | `Admin@2026!` |
| Aluno | `aluno@escola.edu.br` | `Aluno@2026!` |
| Professor | `professor@escola.edu.br` | `Professor@2026!` |
| Gestão escolar | `gestao@escola.edu.br` | `Gestao@2026!` |
| Assistente social | `assistente@escola.edu.br` | `Assistente@2026!` |

Altere as senhas iniciais depois do primeiro acesso. O instalador é idempotente: se o e-mail já existir, ele não substitui a senha nem duplica o usuário.
