<?php
declare(strict_types=1);
namespace SalveAluno\Notifications;
final class NotificationService
{
    public function unreadCount(): int { return 0; }
}
