<?php
declare(strict_types=1);
namespace SalveAluno\Requests;
final class ApiRequest
{
    public static function method(string $method): void { if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method) { http_response_code(405); exit; } }
}
