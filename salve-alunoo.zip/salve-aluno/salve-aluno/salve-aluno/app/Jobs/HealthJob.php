<?php
declare(strict_types=1);
namespace SalveAluno\Jobs;
final class HealthJob
{
    public function handle(): array { return ['job'=>'health','executedAt'=>gmdate('c')]; }
}
