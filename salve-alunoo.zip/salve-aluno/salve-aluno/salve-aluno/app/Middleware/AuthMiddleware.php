<?php
declare(strict_types=1);
namespace SalveAluno\Middleware;
final class AuthMiddleware
{
    public static function userId(): int { $id=$_SESSION['user_id'] ?? 0; if (!$id) { http_response_code(401); exit; } return (int)$id; }
}
