<?php
declare(strict_types=1);
namespace SalveAluno\Resources;
final class UserResource
{
    public static function make(array $user): array { return ['id'=>(int)$user['id'],'name'=>$user['name'],'email'=>$user['email'] ?? null,'profile'=>$user['profile']]; }
}
