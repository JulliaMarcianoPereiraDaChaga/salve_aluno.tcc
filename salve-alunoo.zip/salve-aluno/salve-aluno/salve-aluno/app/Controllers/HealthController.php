<?php
declare(strict_types=1);
namespace SalveAluno\Controllers;
use SalveAluno\Services\HealthService;
final class HealthController
{
    public function __invoke(): array { return (new HealthService())->status(); }
}
