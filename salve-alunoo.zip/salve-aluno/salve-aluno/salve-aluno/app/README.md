# Arquitetura PHP

A aplicação está dividida por responsabilidades: Controllers recebem requisições, Services concentram regras de negócio, Repositories acessam o banco, Validators validam entradas e Resources formatam respostas.

As APIs públicas ficam em `api/` e compartilham `api/_bootstrap.php`.
