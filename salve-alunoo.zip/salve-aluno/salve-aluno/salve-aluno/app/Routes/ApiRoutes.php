<?php
declare(strict_types=1);
namespace SalveAluno\Routes;
final class ApiRoutes
{
    public static function list(): array { return ['health','dashboard','profile','requests','messages','notifications','benefits','meetings','upload']; }
}
