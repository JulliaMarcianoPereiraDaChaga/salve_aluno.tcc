<?php
declare(strict_types=1);
namespace SalveAluno\Exceptions;
class ApiException extends \RuntimeException
{
    public function __construct(string $message, public readonly int $status = 400) { parent::__construct($message); }
}
