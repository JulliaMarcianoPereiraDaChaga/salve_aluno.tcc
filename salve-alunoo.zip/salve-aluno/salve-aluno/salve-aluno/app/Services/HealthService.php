<?php
declare(strict_types=1);
namespace SalveAluno\Services;
final class HealthService
{
    public function status(): array { return ['app' => 'salve-aluno', 'status' => 'ok', 'time' => gmdate('c')]; }
}
