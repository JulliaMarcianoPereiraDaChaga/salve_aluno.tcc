<?php
declare(strict_types=1);
namespace SalveAluno\Support;
final class Id
{
    public static function make(): string { return bin2hex(random_bytes(16)); }
}
