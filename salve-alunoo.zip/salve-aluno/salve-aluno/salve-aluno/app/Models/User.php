<?php
declare(strict_types=1);
namespace SalveAluno\Models;
final class User
{
    public function __construct(public readonly int $id, public readonly string $name, public readonly string $profile) {}
}
