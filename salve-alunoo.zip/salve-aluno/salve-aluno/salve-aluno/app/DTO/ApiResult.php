<?php
declare(strict_types=1);
namespace SalveAluno\DTO;
final class ApiResult
{
    public function __construct(public readonly array $data, public readonly int $status = 200) {}
}
