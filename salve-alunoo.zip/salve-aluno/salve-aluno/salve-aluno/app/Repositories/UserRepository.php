<?php
declare(strict_types=1);
namespace SalveAluno\Repositories;
final class UserRepository
{
    public function __construct(private readonly \PDO $db) {}
    public function find(int $id): ?array { $q=$this->db->prepare('SELECT id,email,profile,name,phone,school_key FROM users WHERE id=:id'); $q->execute([':id'=>$id]); return $q->fetch() ?: null; }
}
