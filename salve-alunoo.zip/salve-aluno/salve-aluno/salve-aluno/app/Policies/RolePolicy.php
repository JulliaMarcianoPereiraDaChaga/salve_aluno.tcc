<?php
declare(strict_types=1);
namespace SalveAluno\Policies;
final class RolePolicy
{
    public static function allows(string $profile, array $allowed): bool { return in_array($profile, $allowed, true); }
}
