Views HTML permanecem na raiz pública para compatibilidade com XAMPP.
