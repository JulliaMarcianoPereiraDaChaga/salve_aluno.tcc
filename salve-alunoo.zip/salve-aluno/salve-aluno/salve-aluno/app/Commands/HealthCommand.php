<?php
declare(strict_types=1);
namespace SalveAluno\Commands;
final class HealthCommand
{
    public function run(): int { fwrite(STDOUT, "Salve Aluno API OK\n"); return 0; }
}
