<?php
declare(strict_types=1);
namespace SalveAluno\Database;
final class Connection
{
    public static function make(): \PDO { $c=\databaseConfig(); return new \PDO('mysql:host='.$c['host'].';dbname='.$c['name'].';charset=utf8mb4',$c['user'],$c['password'],[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC]); }
}
