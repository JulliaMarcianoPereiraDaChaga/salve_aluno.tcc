<?php
declare(strict_types=1);
namespace SalveAluno\Validators;
final class InputValidator
{
    public static function text(mixed $value, int $max, bool $required = true): string
    {
        $value = is_string($value) ? trim($value) : '';
        if ($required && $value === '') throw new \InvalidArgumentException('Campo obrigatório.');
        if (strlen($value) > $max) throw new \InvalidArgumentException('Campo excede o limite.');
        return $value;
    }
}
