<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
function api_json(array $body, int $status=200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($body, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function api_session(): void { if (session_status() !== PHP_SESSION_ACTIVE) { session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax']); } $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32)); }
function api_input(): array { $raw=file_get_contents('php://input'); $data=json_decode($raw ?: '{}', true); return is_array($data) ? $data : $_POST; }
function api_db(): PDO { $c=databaseConfig(); return new PDO('mysql:host='.$c['host'].';dbname='.$c['name'].';charset=utf8mb4',$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]); }
function api_user(PDO $db): array { api_session(); $id=(int)($_SESSION['user_id'] ?? 0); if (!$id) api_json(['error'=>'Faça login para continuar.'],401); $q=$db->prepare('SELECT * FROM users WHERE id=:id'); $q->execute([':id'=>$id]); $user=$q->fetch(); if (!$user) api_json(['error'=>'Usuário não encontrado.'],401); return $user; }
function api_csrf(): void { $expected=$_SESSION['csrf_token'] ?? ''; $given=$_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''; if (!$expected || !hash_equals($expected,(string)$given)) api_json(['error'=>'Token CSRF inválido.'],403); }
