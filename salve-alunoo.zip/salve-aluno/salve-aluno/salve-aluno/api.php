<?php
declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
const API_MAX_RECORD_BYTES = 65536;
const API_MAX_FILE_BYTES = 5242880;

function apiResponse(int $status, array $body): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    echo json_encode(
        $body,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_THROW_ON_ERROR
    );
    exit;
}

function apiFail(int $status, string $message): never
{
    apiResponse($status, ['error' => $message]);
}

function isDuplicateKey(PDOException $error): bool
{
    return (string)$error->getCode() === '23000' && (int)($error->errorInfo[1] ?? 0) === 1062;
}

set_exception_handler(static function (Throwable $error): never {
    error_log('Salve Aluno API: ' . $error->getMessage());
    apiFail(500, 'O servidor não conseguiu concluir a operação.');
});

function apiDatabase(): PDO
{
    try {
        $database = new PDO(
            (function (): string {
                $config = databaseConfig();
                return 'mysql:host=' . $config['host'] . ';dbname=' . $config['name'] . ';charset=utf8mb4';
            })(),
            databaseConfig()['user'],
            databaseConfig()['password'],
            [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return $database;
    } catch (PDOException $error) {
        error_log('Salve Aluno MySQL: ' . $error->getMessage());
        apiFail(500, 'Não foi possível conectar ao MySQL. Importe database/schema.sql no phpMyAdmin e confira as variáveis SALVE_DB_*.');
    }
}

function schoolKeyForName(string $schoolName): string
{
    $normalizedSchoolName = function_exists('mb_strtolower')
        ? mb_strtolower(trim($schoolName), 'UTF-8')
        : strtolower(trim($schoolName));
    return $normalizedSchoolName === 'escola municipal'
        ? 'escola-municipal'
        : hash('sha256', $normalizedSchoolName);
}

function apiUser(PDO $database): ?array
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $statement = $database->prepare(
        'SELECT id, email, profile, name, phone, details_json, preferences_json, school_key
         FROM users WHERE id = :id'
    );
    $statement->execute([':id' => $_SESSION['user_id']]);
    $user = $statement->fetch();
    return $user ?: null;
}

function publicUser(array $user): array
{
    return [
        'id' => (int)$user['id'],
        'email' => $user['email'],
        'profile' => $user['profile'],
        'name' => $user['name'],
        'phone' => $user['phone'],
        'details' => json_decode($user['details_json'], true) ?: [],
        'preferences' => json_decode($user['preferences_json'], true) ?: []
    ];
}

function requestBody(): array
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'multipart/form-data')) {
        $data = $_POST['data'] ?? '';
        if (!is_string($data) || strlen($data) > API_MAX_RECORD_BYTES) {
            apiFail(413, 'Os dados enviados excedem o limite permitido.');
        }
        try {
            $body = json_decode($data, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            apiFail(400, 'Os dados do formulário não são válidos.');
        }
        if (!is_array($body)) {
            apiFail(400, 'Os dados do formulário precisam ser um objeto.');
        }
        $body['type'] = $_POST['type'] ?? '';
        return $body;
    }
    if (str_contains($contentType, 'application/json')) {
        $raw = file_get_contents('php://input');
        if (!is_string($raw) || strlen($raw) > API_MAX_RECORD_BYTES) {
            apiFail(413, 'Os dados enviados excedem o limite permitido.');
        }
        try {
            $body = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            apiFail(400, 'O corpo enviado não contém JSON válido.');
        }
        if (!is_array($body)) {
            apiFail(400, 'O corpo enviado precisa ser um objeto JSON.');
        }
        return $body;
    }

    return $_POST;
}

function requireUser(?array $user): array
{
    if (!$user) {
        apiFail(401, 'Entre na sua conta para continuar.');
    }
    return $user;
}

function requireProfile(array $user, array $profiles): void
{
    if (!in_array($user['profile'], $profiles, true)) {
        apiFail(403, 'Seu perfil não tem permissão para esta ação.');
    }
}

function requireCsrf(): void
{
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';
    if (!is_string($provided) || !is_string($expected) || $expected === '' || !hash_equals($expected, $provided)) {
        apiFail(403, 'A sessão expirou. Atualize a página e tente novamente.');
    }
}

function jsonField(array $body, string $name, int $maxLength, bool $required = true): string
{
    $value = $body[$name] ?? '';
    if (!is_string($value)) {
        apiFail(422, "O campo {$name} precisa ser texto.");
    }
    $value = trim($value);
    if ($required && $value === '') {
        apiFail(422, "Preencha o campo {$name}.");
    }
    if (strlen($value) > $maxLength) {
        apiFail(422, "O campo {$name} excede o limite permitido.");
    }
    return $value;
}

function newId(): string
{
    return bin2hex(random_bytes(16));
}

function saveRecord(PDO $database, array $user, string $type, array $data): array
{
    $allowedTypes = [
        'student_diagnostic', 'student_request', 'school_notice', 'teacher_referral',
        'social_appointment', 'class_checkin', 'student_message', 'profile_update'
    ];
    if (!in_array($type, $allowedTypes, true)) {
        apiFail(422, 'Tipo de registro não permitido.');
    }
    if (strlen(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)) > API_MAX_RECORD_BYTES) {
        apiFail(413, 'Os dados enviados excedem o limite permitido.');
    }
    $id = newId();
    $createdAt = gmdate('c');
    $statement = $database->prepare(
        'INSERT INTO records (id, user_id, type, data_json, created_at)
         VALUES (:id, :user_id, :type, :data_json, :created_at)'
    );
    $statement->execute([
        ':id' => $id,
        ':user_id' => $user['id'],
        ':type' => $type,
        ':data_json' => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
        ':created_at' => $createdAt
    ]);

    $uploadedFiles = [];
    if (isset($_FILES['attachments']['name']) && is_array($_FILES['attachments']['name'])) {
        foreach ($_FILES['attachments']['name'] as $index => $name) {
            $uploadedFiles[] = [
                'name' => $name,
                'type' => $_FILES['attachments']['type'][$index] ?? '',
                'tmp_name' => $_FILES['attachments']['tmp_name'][$index] ?? '',
                'error' => $_FILES['attachments']['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size' => $_FILES['attachments']['size'][$index] ?? 0
            ];
        }
    } elseif (isset($_FILES['attachment'])) {
        $uploadedFiles[] = $_FILES['attachment'];
    }
    if (count($uploadedFiles) > 5) {
        $database->prepare('DELETE FROM records WHERE id = :id')->execute([':id' => $id]);
        apiFail(422, 'É possível anexar até 5 arquivos por solicitação.');
    }
    foreach ($uploadedFiles as $file) {
        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > API_MAX_FILE_BYTES ||
            !is_uploaded_file($file['tmp_name'])) {
            $database->prepare('DELETE FROM records WHERE id = :id')->execute([':id' => $id]);
            apiFail(422, 'Cada arquivo deve ter até 5 MB e ser enviado corretamente.');
        }
        $contentType = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']) ?: 'application/octet-stream';
        if (!in_array($contentType, ['application/pdf', 'image/jpeg', 'image/png'], true)) {
            $database->prepare('DELETE FROM records WHERE id = :id')->execute([':id' => $id]);
            apiFail(422, 'Os anexos devem ser arquivos PDF, JPG ou PNG.');
        }
        $fileInsert = $database->prepare(
            'INSERT INTO record_files (record_id, original_name, content_type, content, created_at)
             VALUES (:record_id, :original_name, :content_type, :content, :created_at)'
        );
        $fileInsert->bindValue(':record_id', $id);
        $fileInsert->bindValue(':original_name', basename((string)$file['name']));
        $fileInsert->bindValue(':content_type', $contentType);
        $fileInsert->bindValue(':content', file_get_contents($file['tmp_name']), PDO::PARAM_LOB);
        $fileInsert->bindValue(':created_at', $createdAt);
        $fileInsert->execute();
    }

    return ['id' => $id, 'type' => $type, 'data' => $data, 'createdAt' => $createdAt];
}

function recordList(PDO $database, array $user, string $type): array
{
    if (!in_array($type, [
        'student_diagnostic', 'student_request', 'school_notice', 'teacher_referral',
        'social_appointment', 'class_checkin', 'student_message', 'profile_update'
    ], true)) {
        apiFail(422, 'Tipo de registro não permitido.');
    }

    $schoolVisibleTypes = [
        'escola' => ['student_diagnostic', 'student_request', 'class_checkin', 'teacher_referral', 'social_appointment', 'school_notice'],
        'assistente' => ['student_diagnostic', 'student_request', 'class_checkin', 'teacher_referral', 'school_notice'],
        'professor' => ['school_notice'],
        'aluno' => ['school_notice']
    ];
    if (in_array($type, $schoolVisibleTypes[$user['profile']] ?? [], true)) {
        $statement = $database->prepare(
            'SELECT records.id, records.type, records.data_json, records.created_at, users.name AS user_name
             FROM records JOIN users ON users.id = records.user_id
             WHERE users.school_key = :school_key AND records.type = :type
             ORDER BY records.created_at DESC LIMIT 500'
        );
        $statement->execute([':school_key' => $user['school_key'], ':type' => $type]);
    } else {
        $statement = $database->prepare(
            'SELECT id, type, data_json, created_at, NULL AS user_name
             FROM records WHERE user_id = :user_id AND type = :type
             ORDER BY created_at DESC LIMIT 500'
        );
        $statement->execute([':user_id' => $user['id'], ':type' => $type]);
    }

    return array_map(static function (array $record): array {
        return [
            'id' => $record['id'],
            'type' => $record['type'],
            'data' => json_decode($record['data_json'], true) ?: [],
            'createdAt' => $record['created_at'],
            'userName' => $record['user_name']
        ];
    }, $statement->fetchAll());
}

function handleRegistrationRequests(PDO $database, array $user, string $action, array $body): void
{
    requireProfile($user, ['escola']);

    if ($action === 'registration-requests-list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $statement = $database->prepare(
            'SELECT id, email, profile, name, phone, details_json, quiz_json, requested_at
             FROM registration_requests
             WHERE school_key = :school_key AND status = :status
             ORDER BY requested_at ASC LIMIT 200'
        );
        $statement->execute([':school_key' => $user['school_key'], ':status' => 'pending']);
        $requests = array_map(static function (array $request): array {
            return [
                'id' => $request['id'],
                'email' => $request['email'],
                'profile' => $request['profile'],
                'name' => $request['name'],
                'phone' => $request['phone'],
                'details' => json_decode($request['details_json'], true) ?: [],
                'quiz' => json_decode($request['quiz_json'], true) ?: [],
                'requestedAt' => $request['requested_at']
            ];
        }, $statement->fetchAll());
        apiResponse(200, ['requests' => $requests]);
    }

    if ($action === 'registration-request-review' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = jsonField($body, 'id', 32);
        $status = jsonField($body, 'status', 20);
        if (!preg_match('/\A[a-f0-9]{32}\z/D', $id) || !in_array($status, ['approved', 'rejected'], true)) {
            apiFail(422, 'A solicitação ou decisão informada é inválida.');
        }

        $database->beginTransaction();
        $statement = $database->prepare(
            'SELECT * FROM registration_requests WHERE id = :id AND school_key = :school_key FOR UPDATE'
        );
        $statement->execute([':id' => $id, ':school_key' => $user['school_key']]);
        $request = $statement->fetch();
        if (!$request) {
            $database->rollBack();
            apiFail(404, 'Solicitação de cadastro não encontrada.');
        }
        if ($request['status'] !== 'pending') {
            $database->rollBack();
            apiFail(409, 'Esta solicitação já foi analisada.');
        }

        if ($status === 'approved') {
            try {
                $database->prepare(
                    'INSERT INTO users
                        (email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, created_at)
                     VALUES (:email, :password_hash, :profile, :name, :phone, :details, :quiz, :preferences, :school_key, :created_at)'
                )->execute([
                    ':email' => $request['email'],
                    ':password_hash' => $request['password_hash'],
                    ':profile' => $request['profile'],
                    ':name' => $request['name'],
                    ':phone' => $request['phone'],
                    ':details' => $request['details_json'],
                    ':quiz' => $request['quiz_json'],
                    ':preferences' => '{}',
                    ':school_key' => $request['school_key'],
                    ':created_at' => gmdate('c')
                ]);
            } catch (PDOException $error) {
                $database->rollBack();
                if (isDuplicateKey($error)) {
                    apiFail(409, 'Já existe uma conta com este e-mail. A solicitação não foi aprovada.');
                }
                throw $error;
            }
        }

        $database->prepare(
            'UPDATE registration_requests
             SET status = :status, password_hash = NULL, reviewed_at = :reviewed_at, reviewed_by = :reviewed_by
             WHERE id = :id'
        )->execute([
            ':status' => $status,
            ':reviewed_at' => gmdate('c'),
            ':reviewed_by' => $user['id'],
            ':id' => $id
        ]);
        $database->commit();
        apiResponse(200, ['ok' => true, 'status' => $status]);
    }

    apiFail(404, 'Ação de solicitação de cadastro desconhecida.');
}

function handleSchoolAccounts(PDO $database, array $user, string $action, array $body): void
{
    requireProfile($user, ['escola']);

    if ($action === 'school-accounts-list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $statement = $database->prepare(
            'SELECT id, email, profile, name, created_at
             FROM users
             WHERE school_key = :school_key AND profile IN (:student, :teacher)
             ORDER BY profile, name LIMIT 500'
        );
        $statement->execute([
            ':school_key' => $user['school_key'],
            ':student' => 'aluno',
            ':teacher' => 'professor'
        ]);
        apiResponse(200, ['accounts' => array_map(static function (array $account): array {
            return [
                'id' => (int)$account['id'],
                'email' => $account['email'],
                'profile' => $account['profile'],
                'name' => $account['name'],
                'createdAt' => $account['created_at']
            ];
        }, $statement->fetchAll())]);
    }

    if ($action === 'school-account-create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = jsonField($body, 'name', 120);
        $email = strtolower(jsonField($body, 'email', 254));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            apiFail(422, 'Informe um endereço de e-mail válido.');
        }
        $password = $body['password'] ?? null;
        if (!is_string($password) || strlen($password) < 8 || strlen($password) > 1024) {
            apiFail(422, 'A senha inicial deve ter pelo menos 8 caracteres.');
        }
        $profile = $body['profile'] ?? '';
        if (!in_array($profile, ['aluno', 'professor'], true)) {
            apiFail(422, 'Selecione o perfil de aluno ou professor.');
        }

        $schoolDetails = json_decode($user['details_json'], true) ?: [];
        $institution = $schoolDetails['institution'] ?? 'Escola Municipal';
        if (!is_string($institution) || trim($institution) === '') {
            $institution = 'Escola Municipal';
        }
        $details = json_encode(['institution' => trim($institution)], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        try {
            $database->prepare(
                'INSERT INTO users
                    (email, password_hash, profile, name, phone, details_json, quiz_json, preferences_json, school_key, created_at)
                 VALUES (:email, :password_hash, :profile, :name, :phone, :details, :quiz, :preferences, :school_key, :created_at)'
            )->execute([
                ':email' => $email,
                ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ':profile' => $profile,
                ':name' => $name,
                ':phone' => '',
                ':details' => $details,
                ':quiz' => '{}',
                ':preferences' => '{}',
                ':school_key' => $user['school_key'],
                ':created_at' => gmdate('c')
            ]);
        } catch (PDOException $error) {
            if (isDuplicateKey($error)) {
                apiFail(409, 'Este e-mail já está cadastrado. Use outro e-mail.');
            }
            throw $error;
        }

        apiResponse(201, ['account' => [
            'id' => (int)$database->lastInsertId(),
            'email' => $email,
            'profile' => $profile,
            'name' => $name
        ]]);
    }

    apiFail(404, 'Ação de contas escolares desconhecida.');
}

function meetingList(PDO $database, array $user): array
{
    $statement = $database->prepare(
        'SELECT meetings.id, meetings.title, meetings.description, meetings.meeting_date AS date,
                meetings.cancelled, meeting_participants.participant_name AS participant_name,
                CASE WHEN meeting_closures.user_id IS NULL THEN 0 ELSE 1 END AS closed_by_me
         FROM meetings
         LEFT JOIN meeting_participants
            ON meeting_participants.meeting_id = meetings.id
         LEFT JOIN meeting_closures
            ON meeting_closures.meeting_id = meetings.id AND meeting_closures.user_id = :user_id
         WHERE meetings.school_key = :school_key
         ORDER BY meetings.meeting_date, meetings.created_at, meeting_participants.created_at'
    );
    $statement->execute([':user_id' => $user['id'], ':school_key' => $user['school_key']]);
    $meetings = [];
    foreach ($statement->fetchAll() as $row) {
        $id = $row['id'];
        if (!isset($meetings[$id])) {
            $meetings[$id] = [
                'id' => $id,
                'title' => $row['title'],
                'description' => $row['description'],
                'date' => $row['date'],
                'cancelled' => (bool)$row['cancelled'],
                'closedByMe' => (bool)$row['closed_by_me'],
                'participants' => []
            ];
        }
        if ($row['participant_name'] !== null) {
            $meetings[$id]['participants'][] = $row['participant_name'];
        }
    }
    return array_values($meetings);
}

function handleMeetings(PDO $database, array $user, string $action, array $body): never
{
    if ($action === 'meetings-list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        requireProfile($user, ['escola', 'professor']);
        $meetings = meetingList($database, $user);
        $meetings = array_values(array_filter($meetings, static fn(array $meeting): bool =>
            !$meeting['cancelled'] || !$meeting['closedByMe']
        ));
        apiResponse(200, ['meetings' => $meetings]);
    }

    if ($action === 'meeting-create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['escola']);
        $title = jsonField($body, 'title', 120);
        $description = jsonField($body, 'description', 1000);
        $date = jsonField($body, 'date', 10);
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (!$parsed || $parsed->format('Y-m-d') !== $date) {
            apiFail(422, 'Informe uma data válida para a reunião.');
        }
        $id = newId();
        $statement = $database->prepare(
            'INSERT INTO meetings (id, school_key, title, description, meeting_date, created_by, created_at)
             VALUES (:id, :school_key, :title, :description, :meeting_date, :created_by, :created_at)'
        );
        $statement->execute([
            ':id' => $id,
            ':school_key' => $user['school_key'],
            ':title' => $title,
            ':description' => $description,
            ':meeting_date' => $date,
            ':created_by' => $user['id'],
            ':created_at' => gmdate('c')
        ]);
        apiResponse(201, ['meeting' => [
            'id' => $id, 'title' => $title, 'description' => $description, 'date' => $date,
            'cancelled' => false, 'closedByMe' => false, 'participants' => []
        ]]);
    }

    $meetingId = jsonField($body, 'id', 64);
    $statement = $database->prepare('SELECT id, cancelled FROM meetings WHERE id = :id AND school_key = :school_key');
    $statement->execute([':id' => $meetingId, ':school_key' => $user['school_key']]);
    $meeting = $statement->fetch();
    if (!$meeting) {
        apiFail(404, 'A reunião não foi encontrada.');
    }

    if ($action === 'meeting-join' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['professor']);
        if ((bool)$meeting['cancelled']) {
            apiFail(409, 'Esta reunião foi cancelada e não aceita mais participantes.');
        }
        $name = jsonField($body, 'name', 80);
        $statement = $database->prepare(
            'INSERT INTO meeting_participants (meeting_id, user_id, participant_name, created_at)
             VALUES (:meeting_id, :user_id, :participant_name, :created_at)
             ON DUPLICATE KEY UPDATE participant_name = VALUES(participant_name)'
        );
        $statement->execute([
            ':meeting_id' => $meetingId, ':user_id' => $user['id'],
            ':participant_name' => $name, ':created_at' => gmdate('c')
        ]);
        apiResponse(200, ['message' => 'Participação confirmada.']);
    }

    if ($action === 'meeting-cancel' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['escola']);
        if (!(bool)$meeting['cancelled']) {
            $database->prepare(
                'UPDATE meetings SET cancelled = 1, cancelled_at = :cancelled_at WHERE id = :id'
            )->execute([':cancelled_at' => gmdate('c'), ':id' => $meetingId]);
        }
        apiResponse(200, ['message' => 'Reunião cancelada.']);
    }

    if ($action === 'meeting-close' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['escola', 'professor']);
        if (!(bool)$meeting['cancelled']) {
            apiFail(409, 'Somente reuniões canceladas podem ser fechadas.');
        }
        $statement = $database->prepare(
            'INSERT INTO meeting_closures (meeting_id, user_id, closed_at)
             VALUES (:meeting_id, :user_id, :closed_at)
             ON DUPLICATE KEY UPDATE meeting_id = VALUES(meeting_id)'
        );
        $statement->execute([
            ':meeting_id' => $meetingId, ':user_id' => $user['id'], ':closed_at' => gmdate('c')
        ]);
        apiResponse(200, ['message' => 'Reunião fechada.']);
    }

    apiFail(405, 'Método não permitido para esta operação.');
}

function handleMessages(PDO $database, array $user, string $action, array $body): never
{
    if ($action === 'messages-list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        requireProfile($user, ['escola', 'assistente']);
        $statement = $database->prepare(
            'SELECT id, source, sender_name, student_name, anonymous, message, sent_at, read_at
             FROM secure_messages WHERE school_key = :school_key ORDER BY sent_at DESC LIMIT 500'
        );
        $statement->execute([':school_key' => $user['school_key']]);
        apiResponse(200, ['messages' => array_map(static fn(array $row): array => [
            'id' => $row['id'],
            'source' => $row['source'],
            'sender' => (bool)$row['anonymous'] ? 'Estudante anônimo' : $row['sender_name'],
            'student' => (bool)$row['anonymous'] ? '' : $row['student_name'],
            'anonymous' => (bool)$row['anonymous'],
            'message' => $row['message'],
            'sentAt' => $row['sent_at'],
            'read' => $row['read_at'] !== null
        ], $statement->fetchAll())]);
    }

    if ($action === 'message-send' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['aluno', 'assistente']);
        $message = jsonField($body, 'message', 2000);
        $source = $user['profile'] === 'aluno' ? 'student' : 'assistant';
        $anonymous = $source === 'student' && filter_var($body['anonymous'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $studentName = $source === 'assistant' ? jsonField($body, 'student', 120, false) : $user['name'];
        $id = newId();
        $statement = $database->prepare(
            'INSERT INTO secure_messages
                (id, school_key, sender_user_id, source, sender_name, student_name, anonymous, message, sent_at)
             VALUES (:id, :school_key, :sender_user_id, :source, :sender_name, :student_name, :anonymous, :message, :sent_at)'
        );
        $statement->execute([
            ':id' => $id, ':school_key' => $user['school_key'], ':sender_user_id' => $user['id'],
            ':source' => $source, ':sender_name' => $user['name'], ':student_name' => $studentName,
            ':anonymous' => $anonymous ? 1 : 0, ':message' => $message, ':sent_at' => gmdate('c')
        ]);
        apiResponse(201, ['id' => $id]);
    }

    if ($action === 'message-read' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireProfile($user, ['escola', 'assistente']);
        $id = jsonField($body, 'id', 64);
        $statement = $database->prepare(
            'UPDATE secure_messages SET read_at = :read_at
             WHERE id = :id AND school_key = :school_key AND read_at IS NULL'
        );
        $statement->execute([':read_at' => gmdate('c'), ':id' => $id, ':school_key' => $user['school_key']]);
        if ($statement->rowCount() === 0) {
            $check = $database->prepare('SELECT 1 FROM secure_messages WHERE id = :id AND school_key = :school_key');
            $check->execute([':id' => $id, ':school_key' => $user['school_key']]);
            if (!$check->fetchColumn()) {
                apiFail(404, 'A mensagem não foi encontrada.');
            }
        }
        apiResponse(200, ['message' => 'Mensagem marcada como lida.']);
    }

    apiFail(405, 'Método não permitido para esta operação.');
}

function applyRateLimit(PDO $database, string $email): void
{
    $key = hash('sha256', strtolower($email) . '|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $now = time();
    $statement = $database->prepare('SELECT attempts, window_started FROM rate_limits WHERE rate_key = :key');
    $statement->execute([':key' => $key]);
    $limit = $statement->fetch();
    if ($limit && $now - (int)$limit['window_started'] < 900 && (int)$limit['attempts'] >= 10) {
        apiFail(429, 'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.');
    }
    if (!$limit || $now - (int)$limit['window_started'] >= 900) {
        $database->prepare(
            'INSERT INTO rate_limits (rate_key, attempts, window_started) VALUES (:key, 1, :started)
             ON DUPLICATE KEY UPDATE attempts = 1, window_started = VALUES(window_started)'
        )->execute([':key' => $key, ':started' => $now]);
    } else {
        $database->prepare('UPDATE rate_limits SET attempts = attempts + 1 WHERE rate_key = :key')
            ->execute([':key' => $key]);
    }
}

function requireAdmin(array $user): void
{
    if (($user['profile'] ?? '') !== 'admin') {
        apiFail(403, 'Apenas administradores podem acessar esta área.');
    }
}

function handleAdminActions(PDO $database, array $user, string $action, array $body): void
{
    requireAdmin($user);
    if ($action === 'admin-users-list' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        $statement = $database->query(
            'SELECT id, email, profile, name, phone, school_key, created_at
             FROM users ORDER BY FIELD(profile, "admin", "escola", "professor", "assistente", "aluno"), name'
        );
        $users = array_map(static function (array $row): array {
            return [
                'id' => (int)$row['id'], 'email' => $row['email'], 'profile' => $row['profile'],
                'name' => $row['name'], 'phone' => $row['phone'], 'schoolKey' => $row['school_key'],
                'createdAt' => $row['created_at']
            ];
        }, $statement->fetchAll());
        apiResponse(200, ['users' => $users]);
    }
    if ($action === 'admin-user-create' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $email = strtolower(jsonField($body, 'email', 254));
        $name = jsonField($body, 'name', 120);
        $profile = $body['profile'] ?? '';
        $password = $body['password'] ?? '';
        $schoolName = jsonField($body, 'schoolName', 120);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) ||
            !is_string($password) || strlen($password) < 8 || strlen($password) > 1024 ||
            !in_array($profile, ['admin', 'aluno', 'professor', 'escola', 'assistente'], true)) {
            apiFail(422, 'Informe e-mail, perfil válido e uma senha com pelo menos 8 caracteres.');
        }
        try {
            $statement = $database->prepare(
                'INSERT INTO users
                    (email, password_hash, profile, name, details_json, quiz_json, preferences_json, school_key, created_at)
                 VALUES (:email, :password_hash, :profile, :name, :details, :quiz, :preferences, :school_key, :created_at)'
            );
            $statement->execute([
                ':email' => $email, ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ':profile' => $profile, ':name' => $name, ':details' => '{}', ':quiz' => '{}',
                ':preferences' => '{}', ':school_key' => schoolKeyForName($schoolName), ':created_at' => gmdate('c')
            ]);
        } catch (PDOException $error) {
            if (isDuplicateKey($error)) apiFail(409, 'Este e-mail já está cadastrado.');
            throw $error;
        }
        apiResponse(201, ['message' => 'Usuário criado com sucesso.']);
    }
    if ($action === 'admin-user-password' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $id = filter_var($body['id'] ?? null, FILTER_VALIDATE_INT);
        $password = $body['password'] ?? '';
        if (!$id || !is_string($password) || strlen($password) < 8 || strlen($password) > 1024) {
            apiFail(422, 'Informe um usuário e uma senha com pelo menos 8 caracteres.');
        }
        $statement = $database->prepare('UPDATE users SET password_hash = :password_hash WHERE id = :id');
        $statement->execute([':password_hash' => password_hash($password, PASSWORD_DEFAULT), ':id' => $id]);
        if ($statement->rowCount() !== 1) apiFail(404, 'Usuário não encontrado.');
        apiResponse(200, ['message' => 'Senha atualizada com sucesso.']);
    }
    if ($action === 'admin-user-delete' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        $id = filter_var($body['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$id) apiFail(422, 'Usuário inválido.');
        if ((int)$user['id'] === (int)$id) apiFail(422, 'A própria conta administradora não pode ser excluída.');
        $statement = $database->prepare('DELETE FROM users WHERE id = :id');
        $statement->execute([':id' => $id]);
        if ($statement->rowCount() !== 1) apiFail(404, 'Usuário não encontrado.');
        apiResponse(200, ['message' => 'Usuário excluído com sucesso.']);
    }
    apiFail(404, 'Operação administrativa não encontrada.');
}

if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    session_start([
        'cookie_httponly' => true,
        'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'cookie_samesite' => 'Lax'
    ]);
    $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32));

    $action = $_GET['action'] ?? '';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method !== 'GET') {
        requireCsrf();
    }

    if ($action === 'csrf' && $method === 'GET') {
        apiResponse(200, ['csrfToken' => $_SESSION['csrf_token']]);
    }

    if ($action === 'logout' && $method === 'POST') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        apiResponse(200, ['ok' => true]);
    }

    $database = apiDatabase();

    if ($action === 'me' && $method === 'GET') {
        $user = apiUser($database);
        apiResponse(200, ['user' => $user ? publicUser($user) : null, 'csrfToken' => $_SESSION['csrf_token']]);
    }

    $body = $method === 'GET' ? [] : requestBody();

    if ($action === 'login' && $method === 'POST') {
        $email = strtolower(jsonField($body, 'email', 254));
        $password = $body['password'] ?? '';
        $profile = $body['profile'] ?? '';
        if (!is_string($password) || strlen($password) > 1024 ||
            !in_array($profile, ['aluno', 'professor', 'escola', 'assistente', 'admin'], true)) {
            apiFail(422, 'Confira os dados de acesso.');
        }
        applyRateLimit($database, $email);
        $statement = $database->prepare('SELECT * FROM users WHERE email = :email');
        $statement->execute([':email' => $email]);
        $user = $statement->fetch();
        if (!$user || $user['profile'] !== $profile || !password_verify($password, $user['password_hash'])) {
            apiFail(401, 'Confira e-mail, senha e perfil selecionado.');
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        apiResponse(200, ['user' => publicUser($user), 'csrfToken' => $_SESSION['csrf_token']]);
    }

    if ($action === 'register-request' && $method === 'POST') {
        $name = jsonField($body, 'name', 120);
        $email = strtolower(jsonField($body, 'email', 254));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            apiFail(422, 'Informe um endereço de e-mail válido.');
        }
        $password = $body['password'] ?? '';
        $profile = $body['profile'] ?? '';
        if (!is_string($password) || strlen($password) < 8 || strlen($password) > 1024) {
            apiFail(422, 'A senha deve ter pelo menos 8 caracteres.');
        }
        if (!in_array($profile, ['aluno', 'professor'], true)) {
            apiFail(403, 'O cadastro deste perfil não está disponível por este formulário.');
        }
        $details = is_array($body['details'] ?? null) ? $body['details'] : [];
        foreach ($details as $key => $value) {
            if (!is_string($key) || !is_string($value) || strlen($value) > 500) {
                apiFail(422, 'Os dados do perfil são inválidos.');
            }
            $details[$key] = trim($value);
        }
        $schoolName = jsonField($details, 'institution', 120);
        $quiz = $body['quiz'] ?? null;
        if (!is_array($quiz) || count($quiz) !== 2 ||
            !in_array($quiz['question0'] ?? null, ['0', '1', '2'], true) ||
            !in_array($quiz['question1'] ?? null, ['0', '1', '2'], true)) {
            apiFail(422, 'Responda às duas perguntas do quiz para enviar sua solicitação.');
        }
        $phone = jsonField($body, 'phone', 40, false);
        $schoolKey = schoolKeyForName($schoolName);
        $schoolManager = $database->prepare('SELECT 1 FROM users WHERE profile = :profile AND school_key = :school_key LIMIT 1');
        $schoolManager->execute([':profile' => 'escola', ':school_key' => $schoolKey]);
        if (!$schoolManager->fetchColumn()) {
            apiFail(422, 'A escola informada ainda não possui uma conta de gestão para receber solicitações.');
        }

        $existingUser = $database->prepare('SELECT 1 FROM users WHERE email = :email');
        $existingUser->execute([':email' => $email]);
        if ($existingUser->fetchColumn()) {
            apiFail(409, 'Este e-mail já possui uma conta. Tente entrar.');
        }

        $requestId = newId();
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $requestedAt = gmdate('c');
        try {
            $existingRequest = $database->prepare('SELECT id, status FROM registration_requests WHERE email = :email');
            $existingRequest->execute([':email' => $email]);
            $previousRequest = $existingRequest->fetch();
            if ($previousRequest && $previousRequest['status'] === 'pending') {
                apiFail(409, 'Já existe uma solicitação pendente para este e-mail.');
            }

            $values = [
                ':email' => $email,
                ':password_hash' => $passwordHash,
                ':profile' => $profile,
                ':name' => $name,
                ':phone' => $phone,
                ':details' => json_encode($details, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                ':quiz' => json_encode($quiz, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                ':school_key' => $schoolKey,
                ':requested_at' => $requestedAt
            ];
            if ($previousRequest) {
                $database->prepare(
                    'UPDATE registration_requests
                     SET id = :id, password_hash = :password_hash, profile = :profile, name = :name, phone = :phone,
                         details_json = :details, quiz_json = :quiz, school_key = :school_key, status = :status,
                         requested_at = :requested_at, reviewed_at = NULL, reviewed_by = NULL
                     WHERE email = :email'
                )->execute($values + [':id' => $requestId, ':status' => 'pending']);
            } else {
                $database->prepare(
                    'INSERT INTO registration_requests
                        (id, email, password_hash, profile, name, phone, details_json, quiz_json, school_key, status, requested_at)
                     VALUES (:id, :email, :password_hash, :profile, :name, :phone, :details, :quiz, :school_key, :status, :requested_at)'
                )->execute($values + [':id' => $requestId, ':status' => 'pending']);
            }
        } catch (PDOException $error) {
            if (isDuplicateKey($error)) {
                apiFail(409, 'Já existe uma solicitação ou conta vinculada a este e-mail.');
            }
            throw $error;
        }
        apiResponse(201, ['request' => ['id' => $requestId, 'status' => 'pending']]);
    }

    $user = requireUser(apiUser($database));
    if (str_starts_with($action, 'admin-')) {
        handleAdminActions($database, $user, $action, $body);
    }

    if (str_starts_with($action, 'registration-request')) {
        handleRegistrationRequests($database, $user, $action, $body);
    }

    if (str_starts_with($action, 'school-account')) {
        handleSchoolAccounts($database, $user, $action, $body);
    }

    if (str_starts_with($action, 'meeting-') || $action === 'meetings-list') {
        handleMeetings($database, $user, $action, $body);
    }

    if (str_starts_with($action, 'message-') || $action === 'messages-list') {
        handleMessages($database, $user, $action, $body);
    }

    if ($action === 'records-list' && $method === 'GET') {
        $type = $_GET['type'] ?? '';
        apiResponse(200, ['records' => recordList($database, $user, is_string($type) ? $type : '')]);
    }

    if ($action === 'record-create' && $method === 'POST') {
        $type = $body['type'] ?? '';
        $data = $body['data'] ?? [];
        if (!is_string($type) || !is_array($data)) {
            apiFail(422, 'Informe o tipo e os dados do registro.');
        }
        $allowedProfiles = [
            'student_diagnostic' => ['aluno'],
            'student_request' => ['aluno'],
            'student_message' => ['aluno'],
            'school_notice' => ['escola'],
            'teacher_referral' => ['professor'],
            'social_appointment' => ['assistente'],
            'class_checkin' => ['professor'],
            'profile_update' => ['aluno', 'professor', 'escola', 'assistente']
        ];
        if (!isset($allowedProfiles[$type])) {
            apiFail(422, 'Tipo de registro não permitido.');
        }
        requireProfile($user, $allowedProfiles[$type]);
        $record = saveRecord($database, $user, $type, $data);
        apiResponse(201, ['record' => $record]);
    }

    if ($action === 'preferences-save' && $method === 'POST') {
        $preferences = $body['preferences'] ?? null;
        if (!is_array($preferences)) {
            apiFail(422, 'As preferências enviadas são inválidas.');
        }
        $safePreferences = [
            'darkMode' => (bool)($preferences['darkMode'] ?? false),
            'colorblindMode' => (bool)($preferences['colorblindMode'] ?? false),
            'notifications' => (bool)($preferences['notifications'] ?? true),
            'opportunities' => (bool)($preferences['opportunities'] ?? true)
        ];
        $database->prepare('UPDATE users SET preferences_json = :preferences WHERE id = :id')
            ->execute([
                ':preferences' => json_encode($safePreferences, JSON_THROW_ON_ERROR),
                ':id' => $user['id']
            ]);
        saveRecord($database, $user, 'profile_update', ['preferences' => $safePreferences]);
        apiResponse(200, ['preferences' => $safePreferences]);
    }

    if ($action === 'file-download' && $method === 'GET') {
        $fileId = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
        if (!$fileId) {
            apiFail(422, 'Identificador de arquivo inválido.');
        }
        $statement = $database->prepare(
            'SELECT record_files.original_name, record_files.content_type, record_files.content
             FROM record_files
             JOIN records ON records.id = record_files.record_id
             WHERE record_files.id = :id AND records.user_id = :user_id'
        );
        $statement->execute([':id' => $fileId, ':user_id' => $user['id']]);
        $file = $statement->fetch();
        if (!$file) {
            apiFail(404, 'Arquivo não encontrado.');
        }
        header('Content-Type: ' . $file['content_type']);
        header('Content-Disposition: attachment; filename="' . rawurlencode($file['original_name']) . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, private');
        echo $file['content'];
        exit;
    }

    apiFail(404, 'Operação de API não encontrada.');
}
