CREATE DATABASE IF NOT EXISTS salve_aluno
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE salve_aluno;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    profile VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    details_json LONGTEXT NOT NULL,
    quiz_json LONGTEXT NOT NULL,
    preferences_json LONGTEXT NOT NULL,
    school_key VARCHAR(64) NOT NULL DEFAULT 'escola-municipal',
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY users_email_unique (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS registration_requests (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    email VARCHAR(254) NOT NULL,
    password_hash VARCHAR(255) NULL,
    profile VARCHAR(20) NOT NULL,
    name VARCHAR(120) NOT NULL,
    phone VARCHAR(40) NOT NULL DEFAULT '',
    details_json LONGTEXT NOT NULL,
    quiz_json LONGTEXT NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    requested_at VARCHAR(35) NOT NULL,
    reviewed_at VARCHAR(35) NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    UNIQUE KEY registration_requests_email_unique (email),
    KEY registration_requests_school_status (school_key, status, requested_at),
    CONSTRAINT registration_requests_reviewer_fk FOREIGN KEY (reviewed_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS records (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    type VARCHAR(40) NOT NULL,
    data_json LONGTEXT NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY records_user_type_created (user_id, type, created_at),
    CONSTRAINT records_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS record_files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    record_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    content MEDIUMBLOB NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (id),
    KEY record_files_record_id (record_id),
    CONSTRAINT record_files_record_fk FOREIGN KEY (record_id) REFERENCES records (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS meetings (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    meeting_date VARCHAR(64) NOT NULL,
    cancelled TINYINT(1) NOT NULL DEFAULT 0,
    created_by BIGINT UNSIGNED NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    cancelled_at VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY meetings_school_date (school_key, meeting_date),
    CONSTRAINT meetings_creator_fk FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS meeting_participants (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    participant_name VARCHAR(120) NOT NULL,
    created_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id),
    CONSTRAINT meeting_participants_meeting_fk FOREIGN KEY (meeting_id) REFERENCES meetings (id) ON DELETE CASCADE,
    CONSTRAINT meeting_participants_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS meeting_closures (
    meeting_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    closed_at VARCHAR(35) NOT NULL,
    PRIMARY KEY (meeting_id, user_id),
    CONSTRAINT meeting_closures_meeting_fk FOREIGN KEY (meeting_id) REFERENCES meetings (id) ON DELETE CASCADE,
    CONSTRAINT meeting_closures_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS secure_messages (
    id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    school_key VARCHAR(64) NOT NULL,
    sender_user_id BIGINT UNSIGNED NOT NULL,
    source VARCHAR(20) NOT NULL,
    sender_name VARCHAR(120) NOT NULL,
    student_name VARCHAR(120) NOT NULL DEFAULT '',
    anonymous TINYINT(1) NOT NULL DEFAULT 0,
    message TEXT NOT NULL,
    sent_at VARCHAR(35) NOT NULL,
    read_at VARCHAR(35) NULL,
    PRIMARY KEY (id),
    KEY secure_messages_school_sent (school_key, sent_at),
    CONSTRAINT secure_messages_sender_fk FOREIGN KEY (sender_user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
    rate_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    attempts INT UNSIGNED NOT NULL,
    window_started BIGINT NOT NULL,
    PRIMARY KEY (rate_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
