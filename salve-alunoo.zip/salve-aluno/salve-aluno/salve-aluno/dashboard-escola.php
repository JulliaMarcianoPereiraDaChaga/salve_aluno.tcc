<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Painel de gestão escolar Salve Aluno">
	<title>Painel da Escola | Salve Aluno</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/role-dashboards.css">
	<link rel="stylesheet" href="css/meetings.css">
</head>
<body class="role-app" data-required-role="escola">
	<header class="role-topbar">
		<a class="role-brand" href="index.php"><span class="role-mark">S</span>salve.aluno</a>
		<div class="role-user">
			<div><strong id="schoolName">Escola Municipal</strong><small>Gestão escolar</small></div>
			<button type="button" onclick="logout()">Sair</button>
		</div>
	</header>
	<main class="role-main">
		<div class="role-heading">
			<div>
				<p class="eyebrow">Gestão e permanência</p>
				<h1>Painel da escola</h1>
				<p>Uma visão clara para fortalecer o cuidado em toda a comunidade escolar.</p>
			</div>
			<div class="role-actions"><button class="role-button alt" type="button" id="schoolNotice">Novo comunicado</button></div>
		</div>
		<nav class="role-actions" role="tablist" aria-label="Seções do painel escolar" style="margin-bottom:18px">
			<button id="schoolOverviewTab" class="role-button" type="button" role="tab" aria-controls="schoolOverviewPanel" data-school-tab="overview" aria-selected="true">Visão geral</button>
			<button id="schoolAccountsTab" class="role-button alt" type="button" role="tab" aria-controls="schoolAccountsPanel" data-school-tab="accounts" aria-selected="false">Cadastro de alunos e professores</button>
		</nav>
		<section id="schoolOverviewPanel" role="tabpanel" aria-labelledby="schoolOverviewTab" data-school-panel="overview">
		<section class="role-grid">
			<article class="role-stat"><span>Total de alunos</span><strong id="totalStudents">0</strong><span class="trend">+12 este mês</span></article>
			<article class="role-stat"><span>Alunos em atenção</span><strong id="atRiskStudents">0</strong><span class="status high">Acompanhar</span></article>
			<article class="role-stat"><span>Benefícios ativos</span><strong id="activeBenefits">0</strong><span class="trend">86% utilizados</span></article>
			<article class="role-stat"><span>Presença nos check-ins</span><strong id="attendanceRate">0%</strong><span class="trend">+4% na semana</span></article>
		</section>
		<div class="role-columns">
			<section class="role-card">
				<h2>Indicadores da rede</h2>
				<p>Acompanhe os sinais que orientam suas decisões.</p>
				<div id="indicators"></div>
			</section>
			<section class="role-card">
				<h2>Atividade recente</h2>
				<p>O que mudou na sua comunidade hoje.</p>
				<div id="schoolActivity" class="role-list"></div>
			</section>
			<section class="role-card">
				<header class="secure-inbox-header">
					<div><h2>Solicitações de cadastro</h2><p>Revise os pedidos de acesso vinculados à sua escola.</p></div>
					<button id="refreshRegistrationRequests" class="role-button alt" type="button">Atualizar</button>
				</header>
				<p id="registrationRequestsStatus" role="status" aria-live="polite"></p>
				<div id="registrationRequests" class="role-list" aria-live="polite"></div>
			</section>
			<section class="role-card">
				<h2>Mapa de apoio</h2>
				<p>Equipes conectadas à escola.</p>
				<div class="role-list">
					<div class="role-list-item"><div class="avatar">12</div><div><strong>Professores ativos</strong><small>3 turmas realizaram check-in hoje</small></div><span class="status ok">Online</span></div>
					<div class="role-list-item"><div class="avatar">04</div><div><strong>Rede de assistência</strong><small>2 atendimentos aguardando retorno</small></div><span class="status medium">Acompanhar</span></div>
					<div class="role-list-item"><div class="avatar">86</div><div><strong>Benefícios utilizados</strong><small>Alimentação, transporte e tecnologia</small></div><span class="status ok">Ativo</span></div>
				</div>
			</section>
			<section class="role-card" data-meetings-view="school">
				<h2>Agendar reunião</h2>
				<p>Informe o nome, a descrição e a data da reunião.</p>
				<p class="meeting-storage-note">As reuniões e confirmações ficam salvas no banco de dados da escola.</p>
				<form id="meetingForm" class="meeting-form">
					<label>Nome da reunião<input name="title" type="text" maxlength="120" required placeholder="Ex.: Reunião pedagógica"></label>
					<label>Descrição<textarea name="description" rows="3" maxlength="1000" required placeholder="Descreva os assuntos da reunião"></textarea></label>
					<label>Data<input name="date" type="date" required></label>
					<button class="role-button" type="submit">Agendar reunião</button>
				</form>
				<p class="meeting-message" data-meetings-message aria-live="polite"></p>
				<div class="meeting-list" data-meetings-list aria-live="polite"></div>
			</section>
		</div>
		</section>
		<section id="schoolAccountsPanel" class="role-columns" role="tabpanel" aria-labelledby="schoolAccountsTab" data-school-panel="accounts" hidden>
			<section class="role-card">
				<h2>Cadastrar aluno ou professor</h2>
				<p>A conta ficará vinculada à sua escola e poderá acessar o painel correspondente.</p>
				<form id="schoolAccountForm" class="meeting-form">
					<label>Perfil
						<select name="profile" required>
							<option value="">Selecione</option>
							<option value="aluno">Aluno</option>
							<option value="professor">Professor</option>
						</select>
					</label>
					<label>Nome completo<input name="name" type="text" maxlength="120" required autocomplete="name" placeholder="Nome do aluno ou professor"></label>
					<label>E-mail<input name="email" type="email" maxlength="254" required autocomplete="email" placeholder="nome@escola.edu.br"></label>
					<label>Senha inicial<input name="password" type="password" minlength="8" maxlength="1024" required autocomplete="new-password" placeholder="Mínimo de 8 caracteres"></label>
					<button class="role-button" type="submit">Criar conta</button>
				</form>
				<p id="schoolAccountStatus" class="meeting-message" role="status" aria-live="polite"></p>
			</section>
			<section class="role-card">
				<header class="secure-inbox-header">
					<div><h2>Contas da escola</h2><p>Alunos e professores cadastrados nesta instituição.</p></div>
					<button id="refreshSchoolAccounts" class="role-button alt" type="button">Atualizar</button>
				</header>
				<p id="schoolAccountsStatus" role="status" aria-live="polite"></p>
				<div id="schoolAccounts" class="role-list" aria-live="polite"></div>
			</section>
		</section>
	</main>
	<div class="modal-backdrop" id="noticeModal" hidden>
		<form class="role-modal" id="noticeForm">
			<header><h2>Publicar comunicado</h2><button class="role-modal-close" type="button" data-close-modal>×</button></header>
			<label>Título<input required placeholder="Ex.: Check-in da turma"></label>
			<label>Mensagem<textarea rows="4" required placeholder="Escreva um aviso para a rede"></textarea></label>
			<button class="role-button" type="submit">Publicar comunicado</button>
			<p id="noticeMessage"></p>
		</form>
	</div>
	<script src="js/api-client.js"></script>
	<script src="js/login.js"></script>
	<script src="js/reunioes.js"></script>
	<script src="js/dashboard-escola.js"></script>
<script src="js/buttons.js"></script>
</body>
</html>
