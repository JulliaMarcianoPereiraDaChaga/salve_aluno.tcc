(() => {
    const toast = (message) => {
        let node = document.querySelector('[data-global-toast]');
        if (!node) { node=document.createElement('div'); node.dataset.globalToast=''; Object.assign(node.style,{position:'fixed',right:'22px',bottom:'22px',zIndex:'9999',maxWidth:'min(380px,calc(100vw - 44px))',padding:'13px 16px',borderRadius:'10px',background:'#145f50',color:'#fff',boxShadow:'0 12px 30px rgba(0,0,0,.2)',fontWeight:'600',fontSize:'13px'}); document.body.append(node); }
        node.textContent=message; node.hidden=false; clearTimeout(node._timer); node._timer=setTimeout(()=>{node.hidden=true},3200);
    };
    window.SalveUi={toast};
    document.addEventListener('click',(event)=>{
        const button=event.target.closest('button'); if(!button || button.disabled) return;
        if (button.type==='submit' || button.matches('.password-toggle,[data-close-modal],[data-close-channel],.role-modal-close')) return;
        if (button.dataset.viewTarget || button.dataset.view || button.matches('.faq-question,.landing-menu,.menu-button,.notification-button')) return;
        const label=(button.textContent||'').replace(/\s+/g,' ').trim();
        if (label) setTimeout(()=>toast(`${label} selecionado.`),0);
    });
})();
