const profileConfig = {
    admin: {
        label: 'Administrador',
        redirect: 'admin.php',
        placeholder: 'admin@salvealuno.local'
    },
    aluno: {
        label: 'Aluno',
        redirect: 'dashboard-aluno.php',
        placeholder: 'aluno@escola.edu.br'
    },
    professor: {
        label: 'Professor',
        redirect: 'dashboard-professor.php',
        placeholder: 'professor@escola.edu.br'
    },
    escola: {
        label: 'Escola',
        redirect: 'dashboard-escola.php',
        placeholder: 'gestao@escola.edu.br'
    },
    assistente: {
        label: 'Assistente social',
        redirect: 'dashboard-assistente.php',
        placeholder: 'assistente@escola.edu.br'
    }
};

let currentProfile = 'aluno';

function setMessage(selector, text, type = '') {
    const element = document.querySelector(selector);
    if (!element) return;
    element.className = `form-message ${type}`.trim();
    element.textContent = text;
}

function showAuthView(view) {
    document.querySelectorAll('[data-auth-panel]').forEach((panel) => {
        const active = panel.dataset.authPanel === view;
        panel.hidden = !active;
        panel.classList.toggle('active', active);
    });
}

function selectProfile(profile, scope = document) {
    currentProfile = profile;
    scope.querySelectorAll('[data-profile]').forEach((button) => button.classList.toggle('active', button.dataset.profile === profile));
    const email = document.querySelector('#loginEmail');
    if (email) email.placeholder = profileConfig[profile].placeholder;
}

function redirectByProfile(profile) {
    window.location.href = profileConfig[profile]?.redirect || profileConfig.aluno.redirect;
}

document.addEventListener('DOMContentLoaded', () => {
    const syncAuthState = async () => {
        try {
            const { user } = await SalveDatabase.request('me');
            if (!user) {
                localStorage.removeItem('currentUser');
                if (document.body.dataset.requiredRole) window.location.href = 'login.php';
                return;
            }
            localStorage.setItem('currentUser', JSON.stringify(user));
            const requiredRole = document.body.dataset.requiredRole;
            if (requiredRole && requiredRole !== user.profile) {
                redirectByProfile(user.profile);
                return;
            }
            const profileLabels = { aluno: 'Estudante', professor: 'Professor', escola: 'Gestão escolar', assistente: 'Assistência social', admin: 'Administrador' };
            ['schoolName', 'professorName', 'assistantName', 'userName', 'settingsUserName'].forEach((selector) => {
                const element = document.getElementById(selector);
                if (element) element.textContent = user.name;
            });
            const settingsEmail = document.querySelector('#settingsUserEmail');
            if (settingsEmail) settingsEmail.textContent = user.email;
            const studentProfileLabel = document.querySelector('[data-page="configuracoes"] .settings-info div:nth-child(2) strong');
            if (studentProfileLabel) studentProfileLabel.textContent = profileLabels[user.profile] || 'Conta';
        } catch (error) {
            const status = document.querySelector('#loginMessage') || document.querySelector('[data-meetings-message]');
            if (status) status.textContent = `Não foi possível conectar ao banco de dados: ${error.message}`;
            else console.error('Não foi possível verificar a sessão:', error);
        }
    };
    syncAuthState();

    document.querySelectorAll('[data-profile]').forEach((button) => button.addEventListener('click', () => selectProfile(button.dataset.profile)));

    document.querySelector('#loginForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const email = document.querySelector('#loginEmail').value.trim().toLowerCase();
        const password = document.querySelector('#loginPassword').value;
        const button = event.currentTarget.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            const { user } = await SalveDatabase.request('login', {
                method: 'POST',
                data: { email, password, profile: currentProfile }
            });
            localStorage.setItem('currentUser', JSON.stringify(user));
            setMessage('#loginMessage', `Acesso de ${profileConfig[currentProfile].label} confirmado. Abrindo seu painel...`);
            window.setTimeout(() => redirectByProfile(currentProfile), 350);
        } catch (error) {
            setMessage('#loginMessage', error.message, 'error-message');
        } finally {
            button.disabled = false;
        }
    });

    document.querySelector('.forgot-trigger')?.addEventListener('click', () => showAuthView('forgot'));
    document.querySelector('.back-login')?.addEventListener('click', () => showAuthView('login'));
    document.querySelector('#forgotForm')?.addEventListener('submit', (event) => {
        event.preventDefault();
        setMessage('#forgotMessage', 'Para proteger seus dados, a recuperação de senha precisa ser configurada pelo administrador do servidor.', 'error-message');
    });

    document.querySelector('.password-toggle')?.addEventListener('click', (event) => {
        const input = document.querySelector('#loginPassword');
        const visible = input.type === 'text';
        input.type = visible ? 'password' : 'text';
        event.currentTarget.textContent = visible ? '◉' : '◌';
        event.currentTarget.setAttribute('aria-label', visible ? 'Mostrar senha' : 'Ocultar senha');
    });
});

async function logout() {
    try {
        await SalveDatabase.request('logout', { method: 'POST', data: {} });
    } catch (error) {
        const status = document.querySelector('#loginMessage') || document.querySelector('[data-meetings-message]');
        if (status) status.textContent = `Não foi possível encerrar a sessão: ${error.message}`;
        else console.error('Não foi possível encerrar a sessão:', error);
        return;
    }
    localStorage.removeItem('currentUser');
    localStorage.removeItem('rememberMe');
    window.location.href = 'login.php';
}
