const schoolData = {
    students: 248,
    risk: 32,
    benefits: 86,
    attendance: 91,
    indicators: [
        ['Check-ins realizados', '184 de 248 alunos', 74],
        ['Solicitacoes respondidas', '42 de 48 solicitacoes', 88],
        ['Atendimentos no prazo', '27 de 32 atendimentos', 84]
    ],
    activity: [
        { initials: '8A', title: '8º ano A atualizou o clima da turma', detail: '32 respostas · agora', status: 'Novo', tone: 'ok' },
        { initials: '!', title: '5 alunos precisam de acompanhamento', detail: 'Sinais identificados hoje', status: 'Atenção', tone: 'high' },
        { initials: '✓', title: '12 benefícios foram aprovados', detail: 'Neste mês', status: 'Concluído', tone: 'ok' }
    ]
};

function renderSchool() {
    document.querySelector('#totalStudents').textContent = schoolData.students;
    document.querySelector('#atRiskStudents').textContent = schoolData.risk;
    document.querySelector('#activeBenefits').textContent = schoolData.benefits;
    document.querySelector('#attendanceRate').textContent = `${schoolData.attendance}%`;
    document.querySelector('#indicators').innerHTML = schoolData.indicators.map(([title, detail, progress]) => `<div class="progress-row"><header><span>${title}<small> · ${detail}</small></span><b>${progress}%</b></header><div class="progress"><i style="width:${progress}%"></i></div></div>`).join('');
    document.querySelector('#schoolActivity').innerHTML = schoolData.activity.map((item) => `<div class="role-list-item"><div class="avatar">${item.initials}</div><div><strong>${item.title}</strong><small>${item.detail}</small></div><span class="status ${item.tone}">${item.status}</span></div>`).join('');
}

document.addEventListener('DOMContentLoaded', () => {
    renderSchool();

    const schoolTabs = [...document.querySelectorAll('[data-school-tab]')];
    const schoolPanels = [...document.querySelectorAll('[data-school-panel]')];
    schoolTabs.forEach((tab) => tab.addEventListener('click', () => {
        schoolTabs.forEach((item) => {
            const active = item === tab;
            item.classList.toggle('alt', !active);
            item.setAttribute('aria-selected', String(active));
        });
        schoolPanels.forEach((panel) => { panel.hidden = panel.dataset.schoolPanel !== tab.dataset.schoolTab; });
    }));

    const accountsList = document.querySelector('#schoolAccounts');
    const accountsStatus = document.querySelector('#schoolAccountsStatus');
    const loadSchoolAccounts = async () => {
        accountsList.replaceChildren();
        accountsStatus.textContent = 'Carregando contas...';
        try {
            const { accounts } = await SalveDatabase.request('school-accounts-list');
            if (!accounts.length) {
                accountsStatus.textContent = 'Ainda não há alunos ou professores cadastrados pela escola.';
                return;
            }
            accountsStatus.textContent = `${accounts.length} conta(s) cadastrada(s).`;
            accounts.forEach((account) => {
                const item = document.createElement('div');
                item.className = 'role-list-item';
                const avatar = document.createElement('div');
                avatar.className = 'avatar';
                avatar.textContent = account.profile === 'aluno' ? 'A' : 'P';
                const content = document.createElement('div');
                const name = document.createElement('strong');
                name.textContent = account.name;
                const detail = document.createElement('small');
                detail.textContent = `${account.profile === 'aluno' ? 'Aluno' : 'Professor'} · ${account.email}`;
                content.append(name, detail);
                item.append(avatar, content);
                accountsList.appendChild(item);
            });
        } catch (error) {
            accountsStatus.textContent = `Não foi possível carregar as contas: ${error.message}`;
        }
    };

    document.querySelector('#refreshSchoolAccounts').addEventListener('click', loadSchoolAccounts);
    loadSchoolAccounts();

    document.querySelector('#schoolAccountForm').addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const submitButton = form.querySelector('[type="submit"]');
        const formData = new FormData(form);
        submitButton.disabled = true;
        accountsStatus.textContent = '';
        const status = document.querySelector('#schoolAccountStatus');
        status.textContent = 'Criando conta...';
        try {
            const { account } = await SalveDatabase.request('school-account-create', {
                method: 'POST',
                data: Object.fromEntries(formData)
            });
            status.textContent = `Conta de ${account.profile === 'aluno' ? 'aluno' : 'professor'} criada para ${account.name}. A pessoa já pode entrar em seu painel usando o e-mail e a senha definidos.`;
            form.reset();
            await loadSchoolAccounts();
        } catch (error) {
            status.textContent = `Não foi possível criar a conta: ${error.message}`;
        } finally {
            submitButton.disabled = false;
        }
    });

    const requestsList = document.querySelector('#registrationRequests');
    const requestsStatus = document.querySelector('#registrationRequestsStatus');
    const loadRegistrationRequests = async () => {
        requestsList.replaceChildren();
        requestsStatus.textContent = 'Carregando solicitações...';
        try {
            const { requests } = await SalveDatabase.request('registration-requests-list');
            requestsStatus.textContent = '';
            if (!requests.length) {
                requestsStatus.textContent = 'Não há solicitações de cadastro pendentes.';
                return;
            }
            requests.forEach((request) => {
                const item = document.createElement('div');
                item.className = 'role-list-item';
                const avatar = document.createElement('div');
                avatar.className = 'avatar';
                avatar.textContent = request.profile === 'aluno' ? 'A' : 'P';
                const content = document.createElement('div');
                const name = document.createElement('strong');
                name.textContent = request.name;
                const details = document.createElement('small');
                const institution = request.details.institution || 'Escola não informada';
                const profile = request.profile === 'aluno' ? 'Aluno' : 'Professor';
                details.textContent = `${profile} · ${request.email} · ${institution}`;
                const actions = document.createElement('div');
                actions.className = 'role-actions';
                const approve = document.createElement('button');
                approve.className = 'role-button';
                approve.type = 'button';
                approve.textContent = 'Aprovar';
                const reject = document.createElement('button');
                reject.className = 'role-button alt';
                reject.type = 'button';
                reject.textContent = 'Recusar';
                const review = async (status) => {
                    approve.disabled = true;
                    reject.disabled = true;
                    try {
                        await SalveDatabase.request('registration-request-review', {
                            method: 'POST',
                            data: { id: request.id, status }
                        });
                        requestsStatus.textContent = status === 'approved'
                            ? `Cadastro de ${request.name} aprovado.`
                            : `Solicitação de ${request.name} recusada.`;
                        await loadRegistrationRequests();
                    } catch (error) {
                        requestsStatus.textContent = `Não foi possível analisar a solicitação: ${error.message}`;
                        approve.disabled = false;
                        reject.disabled = false;
                    }
                };
                approve.addEventListener('click', () => review('approved'));
                reject.addEventListener('click', () => review('rejected'));
                content.append(name, details);
                actions.append(approve, reject);
                item.append(avatar, content, actions);
                requestsList.appendChild(item);
            });
        } catch (error) {
            requestsStatus.textContent = `Não foi possível carregar as solicitações: ${error.message}`;
        }
    };
    document.querySelector('#refreshRegistrationRequests').addEventListener('click', loadRegistrationRequests);
    loadRegistrationRequests();

    const createSecureInbox = () => {
        const section = document.createElement('section');
        section.className = 'role-card secure-inbox-card';
        section.innerHTML = '<header class="secure-inbox-header"><div><h2>Canal seguro</h2><p>Mensagens e pedidos enviados pelo canal seguro para a gestão escolar.</p></div><button id="refreshSecureInbox" class="role-button alt" type="button">Atualizar mensagens</button></header><p class="secure-inbox-privacy">As mensagens são armazenadas no banco de dados e ficam disponíveis para a equipe autorizada da mesma escola.</p><div class="secure-inbox-controls"><label for="secureInboxFilter">Exibir</label><select id="secureInboxFilter"><option value="all">Todas as mensagens</option><option value="unread">Não lidas</option><option value="student">Enviadas por estudantes</option><option value="assistant">Enviadas pela assistência social</option></select><strong id="secureInboxCount" aria-live="polite"></strong></div><p id="secureInboxStatus" role="status"></p><div id="secureInboxMessages" class="secure-inbox-list" aria-live="polite"></div>';
        const stylesheet = document.createElement('link');
        stylesheet.rel = 'stylesheet';
        stylesheet.href = 'css/secure-inbox.css';
        document.head.appendChild(stylesheet);
        document.querySelector('.role-columns')?.before(section);
        return section;
    };

    const inbox = createSecureInbox();
    const renderSecureInbox = async () => {
        const list = inbox.querySelector('#secureInboxMessages');
        const status = inbox.querySelector('#secureInboxStatus');
        const filter = inbox.querySelector('#secureInboxFilter').value;
        list.replaceChildren();
        status.textContent = 'Carregando mensagens...';
        try {
            const { messages } = await SalveDatabase.request('messages-list');
            status.textContent = '';
            const unreadCount = messages.filter((message) => !message.read).length;
            inbox.querySelector('#secureInboxCount').textContent = `${messages.length} mensagem(ns) · ${unreadCount} não lida(s)`;
            const visible = messages.filter((message) => {
                if (filter === 'unread') return !message.read;
                if (filter === 'student') return message.source === 'student';
                if (filter === 'assistant') return message.source === 'assistant';
                return true;
            });
            if (!visible.length) {
                const empty = document.createElement('p');
                empty.className = 'secure-inbox-empty';
                empty.textContent = messages.length ? 'Não há mensagens para este filtro.' : 'Nenhuma mensagem recebida pelo canal seguro.';
                list.appendChild(empty);
                return;
            }
            visible.forEach((entry) => {
                const card = document.createElement('article');
                card.className = `secure-inbox-message${entry.read ? ' is-read' : ''}`;
                const header = document.createElement('header');
                const identity = document.createElement('div');
                const sender = document.createElement('strong');
                sender.textContent = entry.sender;
                const context = document.createElement('small');
                context.textContent = entry.source === 'assistant'
                    ? `Mensagem da assistência social${entry.student ? ` · ${entry.student}` : ''}`
                    : (entry.anonymous ? 'Mensagem anônima' : `Estudante · ${entry.student}`);
                identity.append(sender, context);
                const badge = document.createElement('span');
                badge.className = `status ${entry.read ? 'ok' : 'medium'}`;
                badge.textContent = entry.read ? 'Lida' : 'Não lida';
                header.append(identity, badge);
                const body = document.createElement('p');
                body.className = 'secure-inbox-body';
                body.textContent = entry.message;
                const footer = document.createElement('footer');
                const date = document.createElement('small');
                const parsedDate = new Date(entry.sentAt);
                date.textContent = Number.isNaN(parsedDate.getTime()) ? 'Data indisponível' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium', timeStyle: 'short' }).format(parsedDate);
                footer.appendChild(date);
                if (!entry.read) {
                    const markRead = document.createElement('button');
                    markRead.className = 'role-button alt';
                    markRead.type = 'button';
                    markRead.textContent = 'Marcar como lida';
                    markRead.addEventListener('click', async () => {
                        markRead.disabled = true;
                        try {
                            await SalveDatabase.request('message-read', { method: 'POST', data: { id: entry.id } });
                            await renderSecureInbox();
                        } catch (error) {
                            status.textContent = `Não foi possível atualizar a mensagem: ${error.message}`;
                            markRead.disabled = false;
                        }
                    });
                    footer.appendChild(markRead);
                }
                card.append(header, body, footer);
                list.appendChild(card);
            });
        } catch (error) {
            status.textContent = `Não foi possível carregar as mensagens do canal seguro: ${error.message}`;
            inbox.querySelector('#secureInboxCount').textContent = '';
        }
    };

    inbox.querySelector('#secureInboxFilter').addEventListener('change', renderSecureInbox);
    inbox.querySelector('#refreshSecureInbox').addEventListener('click', renderSecureInbox);
    renderSecureInbox();

    document.querySelector('#schoolNotice')?.addEventListener('click', () => { document.querySelector('#noticeModal').hidden = false; });
    document.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', () => { document.querySelector('#noticeModal').hidden = true; }));
    document.querySelector('#noticeForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const fields = form.querySelectorAll('input, textarea');
        const button = form.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            await SalveDatabase.saveRecord('school_notice', {
                title: fields[0].value.trim(),
                message: fields[1].value.trim()
            });
            document.querySelector('#noticeMessage').textContent = 'Comunicado salvo no banco de dados e disponível para a equipe da escola.';
            form.reset();
            window.setTimeout(() => { document.querySelector('#noticeModal').hidden = true; }, 900);
        } catch (error) {
            document.querySelector('#noticeMessage').textContent = `Não foi possível salvar o comunicado: ${error.message}`;
        } finally {
            button.disabled = false;
        }
    });
});
