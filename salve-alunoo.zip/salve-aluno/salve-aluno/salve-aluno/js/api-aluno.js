const SalveApi = (() => {
    const delay = (value) => new Promise((resolve) => setTimeout(() => resolve(value), 250));

    return {
        getDashboard: () => delay({ student: 'Ana Clara', benefits: 3, requests: 2, risk: 68 }),
        submitRequest: (request) => delay({ ...request, protocol: '#SA-0251', status: 'Em análise' }),
        calculateRisk: (answers) => delay(Object.values(answers).reduce((total, score) => total + Number(score), 0))
    };
})();