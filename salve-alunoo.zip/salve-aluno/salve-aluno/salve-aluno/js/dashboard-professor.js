const professorData = {
    classes: [
        { name: '8º ano A', detail: '32 alunos · 2 sinais recentes', progress: 78 },
        { name: '9º ano B', detail: '28 alunos · 5 acompanhamentos', progress: 64 },
        { name: '1º ano EM', detail: '35 alunos · 1 encaminhamento', progress: 86 }
    ],
    students: [
        { initials: 'LM', name: 'Lucas Martins', detail: '9º ano B · faltas recorrentes', status: 'Atenção', tone: 'high' },
        { initials: 'BS', name: 'Beatriz Santos', detail: '8º ano A · pediu conversa', status: 'Acompanhar', tone: 'medium' },
        { initials: 'CN', name: 'Caio Nunes', detail: '1º ano EM · diagnóstico atualizado', status: 'Em dia', tone: 'ok' }
    ],
    referrals: [
        { title: 'Conversa de acolhimento', detail: 'Beatriz Santos · hoje, 14:30', status: 'Agendado', tone: 'ok' },
        { title: 'Reunião com assistência social', detail: 'Lucas Martins · amanhã, 09:00', status: 'Pendente', tone: 'medium' },
        { title: 'Plano de estudos individual', detail: 'Caio Nunes · enviado ontem', status: 'Concluído', tone: 'ok' }
    ]
};

function renderProfessor() {
    document.querySelector('#myClasses').innerHTML = professorData.classes.map((item) => `<div class="role-list-item"><div class="avatar">${item.name.replace(/[^0-9]/g, '').slice(0,2)}</div><div><strong>${item.name}</strong><small>${item.detail}</small><div class="progress-row"><header><span>Engajamento</span><b>${item.progress}%</b></header><div class="progress"><i style="width:${item.progress}%"></i></div></div></div></div>`).join('');
    document.querySelector('#attentionStudents').innerHTML = professorData.students.map((item) => `<div class="role-list-item" data-search="${item.name.toLowerCase()} ${item.detail.toLowerCase()}"><div class="avatar">${item.initials}</div><div><strong>${item.name}</strong><small>${item.detail}</small></div><span class="status ${item.tone}">${item.status}</span></div>`).join('');
    document.querySelector('#pedagogicalReferrals').innerHTML = professorData.referrals.map((item) => `<div class="role-list-item"><div class="avatar">→</div><div><strong>${item.title}</strong><small>${item.detail}</small></div><span class="status ${item.tone}">${item.status}</span></div>`).join('');
}

document.addEventListener('DOMContentLoaded', () => {
    renderProfessor();
    const loadReferrals = async () => {
        const { records } = await SalveDatabase.listRecords('teacher_referral');
        const container = document.querySelector('#pedagogicalReferrals');
        if (!records.length) return;
        container.replaceChildren();
        records.forEach(({ data }) => {
            const item = document.createElement('div');
            item.className = 'role-list-item';
            const avatar = document.createElement('div');
            avatar.className = 'avatar';
            avatar.textContent = '→';
            const content = document.createElement('div');
            const title = document.createElement('strong');
            title.textContent = data.reason || 'Encaminhamento';
            const detail = document.createElement('small');
            detail.textContent = `${data.student} · ${data.note}`;
            content.append(title, detail);
            item.append(avatar, content);
            container.appendChild(item);
        });
    };
    loadReferrals().catch((error) => {
        document.querySelector('#pedagogicalReferrals').textContent = `Não foi possível carregar os encaminhamentos: ${error.message}`;
    });
    document.querySelector('#studentSearch')?.addEventListener('input', (event) => {
        const query = event.target.value.toLowerCase();
        document.querySelectorAll('#attentionStudents [data-search]').forEach((item) => { item.hidden = !item.dataset.search.includes(query); });
    });
    document.querySelector('#newReferral')?.addEventListener('click', () => { document.querySelector('#referralModal').hidden = false; });
    document.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', () => { document.querySelector('#referralModal').hidden = true; }));
    document.querySelector('#referralForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const fields = form.querySelectorAll('input, select, textarea');
        const button = form.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            await SalveDatabase.saveRecord('teacher_referral', {
                student: fields[0].value.trim(),
                reason: fields[1].value,
                note: fields[2].value.trim()
            });
            document.querySelector('#referralMessage').textContent = 'Encaminhamento salvo no banco de dados para acompanhamento.';
            form.reset();
            await loadReferrals();
            window.setTimeout(() => { document.querySelector('#referralModal').hidden = true; }, 900);
        } catch (error) {
            document.querySelector('#referralMessage').textContent = `Não foi possível salvar o encaminhamento: ${error.message}`;
        } finally {
            button.disabled = false;
        }
    });
    document.querySelector('#classCheckIn')?.addEventListener('click', async () => {
        const details = window.prompt('Como está sua turma hoje?');
        if (!details?.trim()) return;
        try {
            await SalveDatabase.saveRecord('class_checkin', { className: 'Minha turma', details: details.trim() });
            window.alert('Check-in salvo no banco de dados.');
        } catch (error) {
            window.alert(`Não foi possível salvar o check-in: ${error.message}`);
        }
    });
});
