(() => {
    let csrfToken = '';

    async function readJsonResponse(response) {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (error) {
            if (error instanceof SyntaxError) {
                throw new Error('A API retornou uma resposta inválida. Confira se o Apache/PHP está ativo e se o projeto foi aberto pelo endereço http://localhost.');
            }
            throw error;
        }
    }

    async function request(action, options = {}) {
        const method = options.method || 'GET';
        const url = new URL('api.php', window.location.href);
        url.hash = '';
        url.search = new URLSearchParams({ action, ...(options.query || {}) }).toString();
        const headers = new Headers(options.headers || {});
        const config = { method, credentials: 'same-origin', headers };

        if (options.formData) {
            config.body = options.formData;
        } else if (options.data !== undefined) {
            headers.set('Content-Type', 'application/json');
            config.body = JSON.stringify(options.data);
        }

        if (method !== 'GET') {
            if (!csrfToken) {
                const tokenResponse = await fetch(new URL(`${url.pathname}?action=csrf`, window.location.origin), {
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' }
                });
                const tokenBody = await readJsonResponse(tokenResponse);
                if (!tokenResponse.ok || !tokenBody.csrfToken) {
                    throw new Error(tokenBody.error || 'Não foi possível validar a sessão.');
                }
                csrfToken = tokenBody.csrfToken;
            }
            headers.set('X-CSRF-Token', csrfToken);
        }

        const response = await fetch(url, config);
        const body = await readJsonResponse(response);
        if (!response.ok) {
            if (response.status === 403) csrfToken = '';
            throw new Error(body.error || 'Não foi possível concluir a operação.');
        }
        if (body.csrfToken) csrfToken = body.csrfToken;
        return body;
    }

    window.SalveDatabase = {
        request,
        listRecords: (type) => request('records-list', { query: { type } }),
        saveRecord: (type, data) => request('record-create', { method: 'POST', data: { type, data } })
    };
})();
