document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.faq-question').forEach((question) => {
        question.addEventListener('click', () => {
            const item = question.closest('.faq-item');
            const wasActive = item.classList.contains('active');
            document.querySelectorAll('.faq-item').forEach((faq) => faq.classList.remove('active'));
            if (!wasActive) item.classList.add('active');
        });
    });

    document.querySelectorAll('.landing-nav a[href^="#"], .inline-link[href^="#"], .button-ghost[href^="#"], .landing-footer a[href^="#"]').forEach((link) => {
        link.addEventListener('click', (event) => {
            const target = document.querySelector(link.getAttribute('href'));
            if (!target) return;
            event.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    const menuButton = document.querySelector('.landing-menu');
    const nav = document.querySelector('.landing-nav');
    menuButton?.addEventListener('click', () => nav?.classList.toggle('is-open'));

    const loginForm = document.querySelector('#loginForm');
    const passwordToggle = document.querySelector('.password-toggle');
    const demoUsers = [
        { email: 'ana@escola.edu.br', password: 'salvealuno', role: 'Aluno' },
        { email: 'marina@escola.edu.br', password: 'salvesocial', role: 'Assistente social' },
        { email: 'gestao@escola.edu.br', password: 'salvegestao', role: 'Gestão escolar' }
    ];

    if (loginForm) {
        loginForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const message = document.querySelector('#loginMessage');
            const email = document.querySelector('#email').value.trim().toLowerCase();
            const password = document.querySelector('#password').value;
            const user = demoUsers.find((demoUser) => demoUser.email === email && demoUser.password === password);
            if (!user) {
                message.className = 'form-message error-message';
                message.textContent = 'E-mail ou senha inválidos. Escolha um acesso de demonstração abaixo.';
                return;
            }
            sessionStorage.setItem('salveAlunoUser', JSON.stringify(user));
            message.className = 'form-message';
            message.textContent = `Acesso de ${user.role} confirmado. Abrindo seu painel...`;
            window.setTimeout(() => { window.location.href = 'dashboard-aluno.php'; }, 450);
        });
    }

    document.querySelectorAll('.demo-user').forEach((demoButton) => {
        demoButton.addEventListener('click', () => {
            document.querySelector('#email').value = demoButton.dataset.email;
            document.querySelector('#password').value = demoButton.dataset.password;
            document.querySelector('#loginMessage').textContent = 'Acesso selecionado. Clique em entrar.';
            document.querySelector('#email').focus();
        });
    });

    passwordToggle?.addEventListener('click', () => {
        const password = document.querySelector('#password');
        const visible = password.type === 'text';
        password.type = visible ? 'password' : 'text';
        passwordToggle.textContent = visible ? '◉' : '◌';
        passwordToggle.setAttribute('aria-label', visible ? 'Mostrar senha' : 'Ocultar senha');
    });
});