document.addEventListener('DOMContentLoaded', () => {
    const user = JSON.parse(localStorage.getItem('currentUser') || 'null');
    if (user?.name) document.querySelector('#userName').textContent = user.name;

    document.querySelector('#updateQuiz')?.addEventListener('click', () => {
        document.querySelector('#diagnosticAction')?.focus();
        document.querySelector('#diagnosticAction').textContent = 'Diagnóstico selecionado';
    });
});
