document.addEventListener('DOMContentLoaded', () => {
    const views = [...document.querySelectorAll('.view')];
    const navItems = [...document.querySelectorAll('[data-view]')];
    const pageTitle = document.querySelector('#pageTitle');
    const sidebar = document.querySelector('#sidebar');
    const titleByView = { inicio: 'Início', diagnostico: 'Diagnóstico inteligente', beneficios: 'Benefícios', oportunidades: 'Oportunidades', solicitacoes: 'Solicitações', historico: 'Histórico', canal: 'Canal seguro', alertas: 'Alertas', configuracoes: 'Configurações' };
    let preferences = {};
    const opportunitiesSetting = [...document.querySelectorAll('[data-page="configuracoes"] .settings-option')]
        .find((option) => option.querySelector('strong')?.textContent.includes('Novidades'));
    const opportunitiesToggle = opportunitiesSetting?.querySelector('input[type="checkbox"]');
    const applyPreferences = () => {
        document.body.classList.toggle('dark-mode', Boolean(preferences.darkMode));
        document.body.classList.toggle('colorblind-mode', Boolean(preferences.colorblindMode));
        const darkModeToggle = document.querySelector('#darkModeToggle');
        const colorblindModeToggle = document.querySelector('#colorblindModeToggle');
        const notificationToggle = document.querySelector('#notificationToggle');
        if (darkModeToggle) darkModeToggle.checked = Boolean(preferences.darkMode);
        if (colorblindModeToggle) colorblindModeToggle.checked = Boolean(preferences.colorblindMode);
        if (notificationToggle) notificationToggle.checked = preferences.notifications !== false;
        if (opportunitiesToggle) opportunitiesToggle.checked = preferences.opportunities !== false;
    };

    const notify = (message) => {
        let toast = document.querySelector('.app-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'app-toast';
            Object.assign(toast.style, { position: 'fixed', right: '24px', bottom: '24px', zIndex: '20', maxWidth: 'min(360px, calc(100vw - 48px))', padding: '14px 18px', borderRadius: '10px', background: '#176b59', color: '#fff', boxShadow: '0 12px 30px rgba(23,107,89,.25)', fontWeight: '600' });
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.hidden = false;
        window.clearTimeout(toast.hideTimer);
        toast.hideTimer = window.setTimeout(() => { toast.hidden = true; }, 3200);
    };

    const showView = (viewName) => {
        const target = document.querySelector(`[data-page="${viewName}"]`);
        if (!target) return;
        views.forEach((view) => view.classList.toggle('active-view', view === target));
        navItems.forEach((item) => item.classList.toggle('active', item.dataset.view === viewName));
        if (pageTitle) pageTitle.textContent = titleByView[viewName] || 'Início';
        window.history.replaceState(null, '', `#${viewName}`);
        sidebar?.classList.remove('open');
    };

    document.querySelectorAll('[data-view], [data-view-target]').forEach((element) => {
        element.addEventListener('click', (event) => {
            const viewName = element.dataset.view || element.dataset.viewTarget;
            if (viewName) { event.preventDefault(); showView(viewName); }
        });
    });
    document.querySelector('#menuButton')?.addEventListener('click', () => sidebar?.classList.toggle('open'));
    SalveDatabase.request('me').then(({ user }) => {
        preferences = user?.preferences || {};
        applyPreferences();
        const storedUser = user || {};
        if (storedUser.name) {
            document.querySelectorAll('.profile-chip strong').forEach((element) => { element.textContent = storedUser.name; });
            const initials = storedUser.name.split(/\s+/).filter(Boolean).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
            document.querySelectorAll('.profile-chip .avatar').forEach((element) => { element.textContent = initials; });
            const heading = document.querySelector('[data-page="inicio"] .page-heading h1');
            if (heading) {
                heading.replaceChildren(document.createTextNode(`Bom dia, ${storedUser.name} `));
                const wave = document.createElement('span');
                wave.className = 'wave';
                wave.textContent = '✦';
                heading.appendChild(wave);
            }
        }
        const profileLabels = { aluno: 'Estudante', professor: 'Professor', escola: 'Gestão escolar', assistente: 'Assistência social' };
        if (profileLabels[storedUser.profile]) {
            document.querySelectorAll('.profile-chip small').forEach((element) => { element.textContent = profileLabels[storedUser.profile]; });
            const profileSetting = document.querySelector('[data-page="configuracoes"] .settings-info div:nth-child(2) strong');
            if (profileSetting) profileSetting.textContent = profileLabels[storedUser.profile];
        }
        const settingsName = document.querySelector('#settingsUserName');
        const settingsEmail = document.querySelector('#settingsUserEmail');
        if (settingsName && storedUser.name) settingsName.textContent = storedUser.name;
        if (settingsEmail && storedUser.email) settingsEmail.textContent = storedUser.email;
    }).catch((error) => notify(`Não foi possível carregar seus dados: ${error.message}`));
    const savePreferences = async (previousPreferences) => {
        const settingsMessage = document.querySelector('#settingsMessage');
        try {
            const response = await SalveDatabase.request('preferences-save', {
                method: 'POST',
                data: { preferences }
            });
            preferences = response.preferences;
            applyPreferences();
            if (settingsMessage) settingsMessage.textContent = 'Preferências salvas no banco de dados.';
        } catch (error) {
            if (settingsMessage) settingsMessage.textContent = `Não foi possível salvar as preferências: ${error.message}`;
            notify(`Não foi possível salvar as preferências: ${error.message}`);
            preferences = previousPreferences;
            applyPreferences();
        }
    };
    applyPreferences();
    [
        ['#darkModeToggle', 'darkMode'],
        ['#colorblindModeToggle', 'colorblindMode'],
        ['#notificationToggle', 'notifications']
    ].forEach(([selector, key]) => {
        document.querySelector(selector)?.addEventListener('change', (event) => {
            const previousPreferences = { ...preferences };
            preferences[key] = event.target.checked;
            savePreferences(previousPreferences);
        });
    });
    opportunitiesToggle?.addEventListener('change', (event) => {
        const previousPreferences = { ...preferences };
        preferences.opportunities = event.target.checked;
        savePreferences(previousPreferences);
    });
    document.querySelector('#editProfileButton')?.addEventListener('click', () => {
        const user = JSON.parse(localStorage.getItem('currentUser') || 'null');
        notify(`Perfil: ${user?.name || 'Estudante'} · ${user?.email || ''}`);
    });
    document.querySelector('[data-logout]')?.addEventListener('click', async (event) => {
        event.preventDefault();
        await logout();
    });
    document.querySelector('.notification-button')?.addEventListener('click', () => {
        showView('alertas');
        notify('Você tem 2 alertas para conferir.');
    });
    document.querySelector('.profile-chip')?.addEventListener('click', async () => {
        try {
            const { user } = await SalveDatabase.request('me');
            if (!user) throw new Error('Nenhuma conta está conectada.');
            const profileLabels = { aluno: 'Estudante', professor: 'Professor', escola: 'Gestão escolar', assistente: 'Assistência social' };
            notify(`Perfil de ${user.name} · ${profileLabels[user.profile] || 'Conta'}`);
        } catch (error) {
            notify(`Não foi possível carregar os dados do perfil: ${error.message}`);
        }
    });
    document.querySelector('[data-page="inicio"] .outline-button')?.addEventListener('click', () => notify('Conversa de acompanhamento com Marina Souza em 18 de setembro, às 15:00.'));
    document.querySelectorAll('.recommendation-item .small-button').forEach((button) => button.addEventListener('click', () => showView('beneficios')));
    document.querySelectorAll('[data-page="beneficios"] .text-button').forEach((button) => button.addEventListener('click', () => {
        const title = button.closest('.benefit-card')?.querySelector('h2')?.textContent || 'este benefício';
        notify(`${title}: consulte a equipe para verificar disponibilidade e critérios.`);
    }));
    document.querySelector('.secure-card .button')?.addEventListener('click', () => {
        const field = document.querySelector('.secure-card textarea');
        const message = field?.value.trim();
        if (!message) {
            notify('Escreva uma mensagem antes de enviar.');
            field?.focus();
            return;
        }
        SalveDatabase.request('message-send', {
            method: 'POST',
            data: { message, anonymous: Boolean(document.querySelector('.secure-card input[type="checkbox"]')?.checked) }
        }).then(() => {
            field.value = '';
            notify('Mensagem salva no canal seguro.');
        }).catch((error) => notify(`Não foi possível enviar a mensagem: ${error.message}`));
    });
    const initialView = window.location.hash.slice(1) || 'inicio';
    showView(titleByView[initialView] ? initialView : 'inicio');

    const loadStudentRecords = async () => {
        const history = document.querySelector('#requestHistory');
        const notices = document.querySelector('#schoolNotices');
        try {
            const [requestResult, noticeResult] = await Promise.all([
                SalveDatabase.listRecords('student_request'),
                SalveDatabase.listRecords('school_notice')
            ]);
            const { records } = requestResult;
            history.replaceChildren();
            if (!records.length) {
                history.textContent = 'Você ainda não enviou solicitações.';
            } else {
                records.forEach((record) => {
                    const row = document.createElement('div');
                    row.className = 'request-row';
                    const protocol = document.createElement('strong');
                    protocol.textContent = `#SA-${record.id.slice(0, 8).toUpperCase()}`;
                    const category = document.createElement('span');
                    category.textContent = record.data.category;
                    const date = document.createElement('span');
                    const parsedDate = new Date(record.createdAt);
                    date.textContent = Number.isNaN(parsedDate.getTime()) ? 'Data indisponível' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium' }).format(parsedDate);
                    const status = document.createElement('span');
                    status.className = 'status analysis';
                    status.textContent = 'Recebida';
                    row.append(protocol, category, date, status);
                    history.appendChild(row);
                });
            }
            notices.replaceChildren();
            const { records: schoolMessages } = noticeResult;
            if (!schoolMessages.length) {
                notices.textContent = 'Sua escola ainda não publicou comunicados.';
            } else {
                schoolMessages.forEach(({ data, createdAt }) => {
                    const item = document.createElement('div');
                    item.className = 'alert-item alert-success';
                    const icon = document.createElement('span');
                    icon.textContent = '✓';
                    const content = document.createElement('div');
                    const title = document.createElement('strong');
                    title.textContent = data.title || 'Comunicado da escola';
                    const message = document.createElement('p');
                    message.textContent = data.message || '';
                    const date = document.createElement('small');
                    const parsedDate = new Date(createdAt);
                    date.textContent = Number.isNaN(parsedDate.getTime()) ? '' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium' }).format(parsedDate);
                    content.append(title, message, date);
                    item.append(icon, content);
                    notices.appendChild(item);
                });
            }
        } catch (error) {
            history.textContent = `Não foi possível carregar suas solicitações: ${error.message}`;
            notices.textContent = `Não foi possível carregar os comunicados: ${error.message}`;
        }
    };
    loadStudentRecords();

    document.querySelector('#diagnosticForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const data = Object.fromEntries(new FormData(event.currentTarget));
        const score = Object.values(data).reduce((total, value) => total + Number(value), 0);
        const level = score >= 60 ? 'alto' : score >= 30 ? 'moderado' : 'baixo';
        const result = document.querySelector('#diagnosticResult');
        try {
            await SalveDatabase.saveRecord('student_diagnostic', { answers: data, score, level });
            result.textContent = `Seu índice estimado é ${score}/80. Nível de atenção: ${level}. Respostas salvas com segurança para orientar o apoio.`;
        } catch (error) {
            result.textContent = `Não foi possível salvar seu diagnóstico: ${error.message}`;
        }
    });

    document.querySelector('#requestForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        button.disabled = true;
        button.textContent = 'Enviando...';
        const fields = [...form.querySelectorAll('select, textarea, input[type="date"]')];
        const data = {
            category: fields[0]?.value || '',
            description: fields[1]?.value.trim() || '',
            requestedDate: fields[2]?.value || ''
        };
        const attachments = form.querySelector('input[type="file"]')?.files || [];
        try {
            if (attachments.length > 5) throw new Error('Anexe no máximo 5 arquivos.');
            if ([...attachments].some((file) => file.size > 5 * 1024 * 1024)) {
                throw new Error('Cada anexo pode ter no máximo 5 MB.');
            }
            if ([...attachments].some((file) => !/\.(pdf|jpe?g|png)$/i.test(file.name))) {
                throw new Error('Os anexos devem ser arquivos PDF, JPG ou PNG.');
            }
            let response;
            if (attachments.length) {
                const formData = new FormData();
                formData.set('type', 'student_request');
                formData.set('data', JSON.stringify(data));
                [...attachments].forEach((file) => formData.append('attachments[]', file));
                response = await SalveDatabase.request('record-create', { method: 'POST', formData });
            } else {
                response = await SalveDatabase.saveRecord('student_request', data);
            }
            const protocol = `#SA-${response.record.id.slice(0, 8).toUpperCase()}`;
            document.querySelector('#requestMessage').textContent = `Solicitação ${protocol} salva no banco de dados. Você poderá acompanhar pelo Histórico.`;
            button.textContent = 'Solicitação enviada ✓';
            await loadStudentRecords();
        } catch (error) {
            document.querySelector('#requestMessage').textContent = `Não foi possível salvar a solicitação: ${error.message}`;
            button.disabled = false;
            button.textContent = 'Enviar solicitação';
        }
    });
    const uploadNote = document.querySelector('#requestForm input[type="file"]')?.parentElement?.querySelector('p');
    if (uploadNote) uploadNote.textContent = 'PDF, JPG ou PNG · até 5 arquivos de 5 MB cada.';
});
