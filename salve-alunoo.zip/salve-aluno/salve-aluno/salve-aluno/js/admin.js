(() => {
    const table = document.querySelector('#usersTable');
    const modal = document.querySelector('#userModal');
    const form = document.querySelector('#userForm');
    const message = document.querySelector('#adminMessage');
    const formMessage = document.querySelector('#userFormMessage');
    let users = [];
    const labels = { admin: 'Administrador', aluno: 'Aluno', professor: 'Professor', escola: 'Gestão escolar', assistente: 'Assistente social' };
    const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
    const showMessage = (element, text, error = false) => { element.textContent = text; element.className = `admin-message${error ? ' error-message' : ''}`; };
    const initials = (name) => String(name || '?').trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
    function render() {
        const query = (document.querySelector('#userSearch').value || '').toLowerCase().trim();
        const filtered = users.filter((user) => `${user.name} ${user.email} ${labels[user.profile]}`.toLowerCase().includes(query));
        table.innerHTML = filtered.length ? filtered.map((user) => `<tr><td><div class="admin-user"><span class="avatar">${escapeHtml(initials(user.name))}</span><div><strong>${escapeHtml(user.name)}</strong><small>${escapeHtml(user.email)}</small></div></div></td><td><span class="status ${user.profile === 'admin' ? 'high' : 'ok'}">${escapeHtml(labels[user.profile] || user.profile)}</span></td><td>${escapeHtml(user.schoolKey === 'escola-municipal' ? 'Escola Municipal' : user.schoolKey)}</td><td>${escapeHtml(new Date(user.createdAt).toLocaleDateString('pt-BR'))}</td><td><div class="admin-actions"><button type="button" class="table-button" data-password="${user.id}">Senha</button>${user.profile !== 'admin' ? `<button type="button" class="table-button danger" data-delete="${user.id}">Excluir</button>` : ''}</div></td></tr>`).join('') : '<tr><td colspan="5" class="role-empty">Nenhum usuário encontrado.</td></tr>';
        document.querySelector('#totalUsers').textContent = users.length;
        document.querySelector('#totalAlunos').textContent = users.filter((user) => user.profile === 'aluno').length;
        document.querySelector('#totalEquipe').textContent = users.filter((user) => ['professor', 'escola', 'assistente'].includes(user.profile)).length;
        document.querySelector('#totalAdmins').textContent = users.filter((user) => user.profile === 'admin').length;
    }
    async function loadUsers() {
        try { const result = await SalveDatabase.request('admin-users-list'); users = result.users || []; render(); }
        catch (error) { showMessage(message, error.message, true); table.innerHTML = '<tr><td colspan="5" class="role-empty">Não foi possível carregar os usuários.</td></tr>'; }
    }
    function openModal() { form.reset(); form.elements.schoolName.value = 'Escola Municipal'; formMessage.textContent = ''; modal.hidden = false; }
    function closeModal() { modal.hidden = true; }
    document.querySelector('#openCreateUser').addEventListener('click', openModal);
    document.querySelector('[data-close-modal]').addEventListener('click', closeModal);
    document.querySelector('#userSearch').addEventListener('input', render);
    table.addEventListener('click', async (event) => {
        const passwordButton = event.target.closest('[data-password]');
        const deleteButton = event.target.closest('[data-delete]');
        try {
            if (passwordButton) {
                const password = window.prompt('Digite a nova senha (mínimo de 8 caracteres):');
                if (password === null) return;
                await SalveDatabase.request('admin-user-password', { method: 'POST', data: { id: Number(passwordButton.dataset.password), password } });
                showMessage(message, 'Senha atualizada com sucesso.');
            }
            if (deleteButton && window.confirm('Excluir esta conta? Esta ação não pode ser desfeita.')) {
                await SalveDatabase.request('admin-user-delete', { method: 'POST', data: { id: Number(deleteButton.dataset.delete) } });
                showMessage(message, 'Usuário excluído com sucesso.'); await loadUsers();
            }
        } catch (error) { showMessage(message, error.message, true); }
    });
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const data = Object.fromEntries(new FormData(form).entries());
        try { await SalveDatabase.request('admin-user-create', { method: 'POST', data }); closeModal(); showMessage(message, 'Usuário criado com sucesso.'); await loadUsers(); }
        catch (error) { showMessage(formMessage, error.message, true); }
    });
    loadUsers();
})();
