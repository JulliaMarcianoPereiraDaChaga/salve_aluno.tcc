function createMeetingElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
}

function formatMeetingDate(date) {
    const [year, month, day] = date.split('-').map(Number);
    return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'long' }).format(new Date(year, month - 1, day));
}

function initializeMeetings() {
    const section = document.querySelector('[data-meetings-view]');
    if (!section) return;

    const mode = section.dataset.meetingsView;
    const message = section.querySelector('[data-meetings-message]');
    const list = section.querySelector('[data-meetings-list]');

    const renderMeetings = async () => {
        try {
            const { meetings } = await SalveDatabase.request('meetings-list');
            list.replaceChildren();
            if (!meetings.length) {
                list.appendChild(createMeetingElement('p', 'role-empty', 'Nenhuma reunião agendada.'));
                return;
            }

            meetings.forEach((meeting) => {
                const article = createMeetingElement('article', `meeting-item${meeting.cancelled ? ' is-cancelled' : ''}`);
                const heading = createMeetingElement('h3', '', meeting.title);
                const date = createMeetingElement('time', 'meeting-date', formatMeetingDate(meeting.date));
                date.dateTime = meeting.date;
                article.append(
                    heading,
                    date,
                    createMeetingElement('p', 'meeting-description', meeting.description)
                );

                if (meeting.cancelled) {
                    article.appendChild(createMeetingElement('p', 'meeting-cancelled-status', 'Esta reunião foi cancelada.'));
                    const closeButton = createMeetingElement('button', 'meeting-close-button', 'Fechar reunião');
                    closeButton.type = 'button';
                    closeButton.addEventListener('click', async () => {
                        closeButton.disabled = true;
                        try {
                            await SalveDatabase.request('meeting-close', {
                                method: 'POST',
                                data: { id: meeting.id }
                            });
                            message.textContent = `A reunião "${meeting.title}" foi fechada e removida da sua lista.`;
                            await renderMeetings();
                        } catch (error) {
                            message.textContent = `Não foi possível fechar a reunião: ${error.message}`;
                            closeButton.disabled = false;
                        }
                    });
                    article.appendChild(closeButton);
                } else if (mode === 'school') {
                    const cancelButton = createMeetingElement('button', 'meeting-cancel-button', 'Cancelar reunião');
                    cancelButton.type = 'button';
                    cancelButton.addEventListener('click', async () => {
                        cancelButton.disabled = true;
                        try {
                            await SalveDatabase.request('meeting-cancel', {
                                method: 'POST',
                                data: { id: meeting.id }
                            });
                            message.textContent = `A reunião "${meeting.title}" foi cancelada.`;
                            await renderMeetings();
                        } catch (error) {
                            message.textContent = `Não foi possível cancelar a reunião: ${error.message}`;
                            cancelButton.disabled = false;
                        }
                    });
                    article.appendChild(cancelButton);
                } else {
                    const form = createMeetingElement('form', 'meeting-join-form');
                    const label = createMeetingElement('label', '', 'Seu nome');
                    const input = createMeetingElement('input');
                    input.name = 'participant';
                    input.type = 'text';
                    input.maxLength = 80;
                    input.required = true;
                    input.placeholder = 'Digite seu nome';
                    label.appendChild(input);
                    const button = createMeetingElement('button', 'role-button', 'Participar da reunião');
                    button.type = 'submit';
                    form.append(label, button);
                    form.addEventListener('submit', async (event) => {
                        event.preventDefault();
                        const name = input.value.trim();
                        if (!name) {
                            input.focus();
                            return;
                        }
                        if (meeting.participants.some((participant) =>
                            participant.toLocaleLowerCase('pt-BR') === name.toLocaleLowerCase('pt-BR')
                        )) {
                            message.textContent = 'Este nome já está confirmado nesta reunião.';
                            return;
                        }

                        button.disabled = true;
                        try {
                            await SalveDatabase.request('meeting-join', {
                                method: 'POST',
                                data: { id: meeting.id, name }
                            });
                            message.textContent = `Presença confirmada para ${name}.`;
                            await renderMeetings();
                        } catch (error) {
                            message.textContent = `Não foi possível confirmar a participação: ${error.message}`;
                            button.disabled = false;
                        }
                    });
                    article.appendChild(form);
                }

                const participantHeading = createMeetingElement(
                    'strong',
                    'meeting-participant-count',
                    `Participantes (${meeting.participants.length})`
                );
                const participantList = createMeetingElement('ul', 'meeting-participants');
                if (meeting.participants.length) {
                    meeting.participants.forEach((name) => participantList.appendChild(createMeetingElement('li', '', name)));
                } else {
                    participantList.appendChild(createMeetingElement('li', 'meeting-no-participants', 'Ninguém confirmou presença ainda.'));
                }
                article.append(participantHeading, participantList);
                list.appendChild(article);
            });
        } catch (error) {
            list.replaceChildren();
            message.textContent = `Não foi possível carregar as reuniões: ${error.message}`;
        }
    };

    if (mode === 'school') {
        const form = section.querySelector('#meetingForm');
        const fieldLabels = { title: 'o nome da reunião', description: 'a descrição', date: 'a data' };
        form.noValidate = true;
        form.addEventListener('input', () => { message.textContent = ''; });
        form.addEventListener('change', () => { message.textContent = ''; });
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const missingField = [...form.querySelectorAll('[required]')].find((field) => !field.value.trim());
            if (missingField) {
                message.textContent = `Preencha ${fieldLabels[missingField.name]} para agendar a reunião.`;
                missingField.focus();
                return;
            }

            const data = Object.fromEntries(new FormData(form));
            const button = form.querySelector('[type="submit"]');
            button.disabled = true;
            try {
                await SalveDatabase.request('meeting-create', { method: 'POST', data });
                form.reset();
                message.textContent = 'Reunião agendada com sucesso.';
                await renderMeetings();
            } catch (error) {
                message.textContent = `Não foi possível agendar a reunião: ${error.message}`;
            } finally {
                button.disabled = false;
            }
        });
    }

    renderMeetings();
    window.addEventListener('storage', (event) => {
        if (event.key === 'currentUser') renderMeetings();
    });
    window.addEventListener('focus', renderMeetings);
}

document.addEventListener('DOMContentLoaded', initializeMeetings);
