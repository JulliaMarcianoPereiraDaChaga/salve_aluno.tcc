document.addEventListener('DOMContentLoaded', () => {
    const views = [...document.querySelectorAll('.view')];
    const navItems = [...document.querySelectorAll('[data-view]')];
    const pageTitle = document.querySelector('#pageTitle');
    const sidebar = document.querySelector('#sidebar');
    const titleByView = { inicio: 'Início', diagnostico: 'Diagnóstico inteligente', beneficios: 'Benefícios', oportunidades: 'Oportunidades', solicitacoes: 'Solicitações', historico: 'Histórico', canal: 'Canal seguro', alertas: 'Alertas', configuracoes: 'Configurações' };
    const requestStorageKey = 'salveAlunoRequests';
    const interestStorageKey = 'salveAlunoOpportunityInterests';

    const notify = (message) => {
        let toast = document.querySelector('.app-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'app-toast';
            toast.setAttribute('role', 'status');
            Object.assign(toast.style, { position: 'fixed', right: '24px', bottom: '24px', zIndex: '30', maxWidth: 'min(360px, calc(100vw - 48px))', padding: '14px 18px', borderRadius: '10px', background: '#176b59', color: '#fff', boxShadow: '0 12px 30px rgba(23,107,89,.25)', fontWeight: '600' });
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.hidden = false;
        window.clearTimeout(toast.hideTimer);
        toast.hideTimer = window.setTimeout(() => { toast.hidden = true; }, 3200);
    };

    const readJson = (key, fallback) => {
        const value = localStorage.getItem(key);
        if (!value) return fallback;
        try {
            return JSON.parse(value);
        } catch (error) {
            notify(`Não foi possível ler os dados salvos (${key}): ${error.message}`);
            return fallback;
        }
    };

    const saveJson = (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            notify(`Não foi possível salvar as alterações: ${error.message}`);
            return false;
        }
    };

    const createActionDialog = () => {
        const dialog = document.createElement('dialog');
        dialog.className = 'action-dialog';
        dialog.innerHTML = '<section class="action-dialog-card"><header><h2></h2><button type="button" class="action-dialog-close" aria-label="Fechar">×</button></header><div class="action-dialog-content"></div><footer></footer></section>';
        dialog.querySelector('.action-dialog-close').addEventListener('click', () => dialog.close());
        dialog.addEventListener('click', (event) => {
            if (event.target === dialog) dialog.close();
        });
        document.body.appendChild(dialog);
        return dialog;
    };
    const actionDialog = createActionDialog();

    const openDialog = (title, description, actions = []) => {
        actionDialog.querySelector('h2').textContent = title;
        const content = actionDialog.querySelector('.action-dialog-content');
        content.replaceChildren();
        if (description) {
            const paragraph = document.createElement('p');
            paragraph.textContent = description;
            content.appendChild(paragraph);
        }
        const footer = actionDialog.querySelector('footer');
        footer.replaceChildren();
        actions.forEach(({ label, run, primary = false }) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = `button${primary ? ' button-primary' : ' button-light'}`;
            button.textContent = label;
            button.addEventListener('click', () => {
                actionDialog.close();
                run();
            });
            footer.appendChild(button);
        });
        if (!actionDialog.open) actionDialog.showModal();
    };

    const getPreferences = () => {
        const preferences = readJson('salveAlunoPreferences', {});
        return preferences && typeof preferences === 'object' ? preferences : {};
    };

    const applyPreferences = () => {
        const preferences = getPreferences();
        document.body.classList.toggle('dark-mode', Boolean(preferences.darkMode));
        document.body.classList.toggle('colorblind-mode', Boolean(preferences.colorblindMode));
        const darkModeToggle = document.querySelector('#darkModeToggle');
        const colorblindModeToggle = document.querySelector('#colorblindModeToggle');
        if (darkModeToggle) darkModeToggle.checked = Boolean(preferences.darkMode);
        if (colorblindModeToggle) colorblindModeToggle.checked = Boolean(preferences.colorblindMode);
        const notificationToggle = document.querySelector('#notificationToggle');
        const opportunityToggle = document.querySelector('#opportunityNotificationToggle');
        if (notificationToggle) notificationToggle.checked = preferences.notifications?.alerts !== false;
        if (opportunityToggle) opportunityToggle.checked = preferences.notifications?.opportunities !== false;
        updateAlertBadge(preferences);
    };

    const updateAlertBadge = (preferences = getPreferences()) => {
        const badge = document.querySelector('.nav-badge');
        const indicator = document.querySelector('.notification-button span');
        const unread = localStorage.getItem('salveAlunoAlertsRead') === 'true' || preferences.notifications?.alerts === false ? 0 : 2;
        if (badge) {
            badge.textContent = String(unread);
            badge.hidden = unread === 0;
        }
        if (indicator) indicator.hidden = unread === 0;
    };

    const showView = (viewName) => {
        const target = document.querySelector(`[data-page="${viewName}"]`);
        if (!target) return;
        views.forEach((view) => view.classList.toggle('active-view', view === target));
        navItems.forEach((item) => item.classList.toggle('active', item.dataset.view === viewName));
        if (pageTitle) pageTitle.textContent = titleByView[viewName] || 'Início';
        window.history.replaceState(null, '', `#${viewName}`);
        sidebar?.classList.remove('open');
    };

    const readRequests = () => {
        const requests = readJson(requestStorageKey, []);
        if (!Array.isArray(requests)) {
            notify('O histórico salvo está em um formato inválido.');
            return [];
        }
        return requests;
    };

    const requestStatusClass = (status) => status === 'Aprovado' ? 'approved' : status === 'Concluído' ? 'completed' : 'analysis';
    const formatRequestDate = (value) => {
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? 'Data indisponível' : new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
    };

    const renderRequestHistory = () => {
        const history = document.querySelector('[data-page="historico"] .table-surface');
        if (!history) return;
        const header = history.querySelector('.request-header');
        history.querySelectorAll('.request-row:not(.request-header)[data-saved-request]').forEach((row) => row.remove());
        const requests = readRequests();
        requests.forEach((request) => {
            const row = document.createElement('div');
            row.className = 'request-row';
            row.dataset.savedRequest = 'true';
            row.dataset.status = request.status || 'Em análise';
            const values = [request.protocol, request.category, formatRequestDate(request.createdAt)];
            values.forEach((value, index) => {
                const cell = document.createElement(index === 0 ? 'strong' : 'span');
                cell.textContent = value || '—';
                row.appendChild(cell);
            });
            const status = document.createElement('span');
            status.className = `status ${requestStatusClass(request.status)}`;
            status.textContent = request.status || 'Em análise';
            row.appendChild(status);
            history.insertBefore(row, header.nextSibling);
        });
        const activeRequestCount = requests.filter((request) => request.status !== 'Concluído').length;
        const requestStat = [...document.querySelectorAll('[data-page="inicio"] .stat-card')].find((card) => card.querySelector('.card-label')?.textContent.trim() === 'Solicitações em andamento');
        if (requestStat && activeRequestCount) {
            const count = requestStat.querySelector('strong');
            if (count) count.textContent = String(2 + activeRequestCount);
        }
        filterHistory();
    };

    const filterHistory = () => {
        const filter = document.querySelector('#requestHistoryFilter');
        const selected = filter?.value || 'Todas';
        document.querySelectorAll('[data-page="historico"] .request-row:not(.request-header)').forEach((row) => {
            const status = row.dataset.status || row.querySelector('.status')?.textContent.trim();
            row.hidden = selected !== 'Todas' && status !== selected;
        });
    };

    const installHistoryFilter = () => {
        const oldFilter = document.querySelector('[data-page="historico"] .filter-pill');
        if (!oldFilter) return;
        const filter = document.createElement('select');
        filter.id = 'requestHistoryFilter';
        filter.className = 'filter-pill';
        filter.setAttribute('aria-label', 'Filtrar solicitações por status');
        ['Todas', 'Em análise', 'Aprovado', 'Concluído'].forEach((status) => {
            const option = document.createElement('option');
            option.value = status;
            option.textContent = status === 'Todas' ? 'Todas as solicitações' : status;
            filter.appendChild(option);
        });
        oldFilter.replaceWith(filter);
        filter.addEventListener('change', filterHistory);
    };

    const getUser = () => {
        const user = readJson('currentUser', null);
        return user && typeof user === 'object' ? user : { name: 'Ana Clara', email: 'ana@escola.edu.br' };
    };

    const updateProfileLabels = (user) => {
        const name = user.name || 'Ana Clara';
        const email = user.email || 'ana@escola.edu.br';
        const profileName = document.querySelector('.profile-chip strong');
        const avatar = document.querySelector('.profile-chip .avatar');
        if (profileName) profileName.textContent = name;
        if (avatar) avatar.textContent = name.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
        const heading = document.querySelector('[data-page="inicio"] .page-heading h1');
        if (heading) {
            heading.replaceChildren(document.createTextNode(`Bom dia, ${name} `));
            const wave = document.createElement('span');
            wave.className = 'wave';
            wave.textContent = '✦';
            heading.appendChild(wave);
        }
        const settingsName = document.querySelector('#settingsUserName');
        const settingsEmail = document.querySelector('#settingsUserEmail');
        if (settingsName) settingsName.textContent = name;
        if (settingsEmail) settingsEmail.textContent = email;
    };

    const openProfileEditor = () => {
        const user = getUser();
        const content = actionDialog.querySelector('.action-dialog-content');
        actionDialog.querySelector('h2').textContent = 'Editar perfil';
        content.replaceChildren();
        const form = document.createElement('form');
        form.className = 'profile-edit-form';
        form.innerHTML = '<label>Nome completo<input name="name" required maxlength="80"></label><label>E-mail<input name="email" type="email" required maxlength="160"></label>';
        form.elements.name.value = user.name || 'Ana Clara';
        form.elements.email.value = user.email || 'ana@escola.edu.br';
        content.appendChild(form);
        const footer = actionDialog.querySelector('footer');
        footer.replaceChildren();
        const saveButton = document.createElement('button');
        saveButton.type = 'button';
        saveButton.className = 'button button-primary';
        saveButton.textContent = 'Salvar perfil';
        saveButton.addEventListener('click', () => {
            if (!form.reportValidity()) return;
            const updatedUser = { ...user, name: form.elements.name.value.trim(), email: form.elements.email.value.trim().toLowerCase() };
            if (!saveJson('currentUser', updatedUser)) return;
            updateProfileLabels(updatedUser);
            actionDialog.close();
            notify('Perfil atualizado neste dispositivo.');
        });
        footer.appendChild(saveButton);
        actionDialog.showModal();
    };

    const openBenefitDetails = (card) => {
        const title = card.querySelector('h2')?.textContent.trim() || 'Benefício';
        const description = card.querySelector('p')?.textContent.trim() || '';
        openDialog(title, description, [
            { label: 'Solicitar apoio', primary: true, run: () => openRequestForm(title) },
            { label: 'Fechar', run: () => {} }
        ]);
    };

    const openRequestForm = (category) => {
        const form = document.querySelector('#requestForm');
        const select = form?.querySelector('select');
        if (select) {
            const option = [...select.options].find((item) => item.textContent.trim() === category);
            if (option) select.value = option.value;
        }
        showView('solicitacoes');
        select?.focus();
    };

    const addOpportunityActions = () => {
        const savedInterests = readJson(interestStorageKey, []);
        const interests = Array.isArray(savedInterests) ? savedInterests : [];
        if (!Array.isArray(savedInterests)) notify('Os interesses salvos estão em formato inválido.');
        document.querySelectorAll('.opportunity-item').forEach((item) => {
            const title = item.querySelector('strong')?.textContent.trim();
            if (!title || item.querySelector('button')) return;
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'opportunity-action';
            button.textContent = interests.includes(title) ? 'Interesse registrado' : 'Ver oportunidade';
            button.disabled = interests.includes(title);
            item.appendChild(button);
            button.addEventListener('click', () => {
                const description = item.querySelector('p')?.textContent.trim() || 'Consulte a equipe de apoio para saber mais.';
                openDialog(title, description, [
                    { label: 'Registrar interesse', primary: true, run: () => {
                        const savedInterests = readJson(interestStorageKey, []);
                        if (!savedInterests.includes(title)) savedInterests.push(title);
                        if (!saveJson(interestStorageKey, savedInterests)) return;
                        button.textContent = 'Interesse registrado';
                        button.disabled = true;
                        notify(`Seu interesse em "${title}" foi salvo neste dispositivo.`);
                    } },
                    { label: 'Canal seguro', run: () => showView('canal') },
                    { label: 'Fechar', run: () => {} }
                ]);
            });
        });
    };

    const restoreLastDiagnostic = () => {
        const diagnostic = readJson('salveAlunoLastDiagnostic', null);
        if (!diagnostic || typeof diagnostic !== 'object') return;
        const form = document.querySelector('#diagnosticForm');
        const result = document.querySelector('#diagnosticResult');
        if (!form || !result) return;
        Object.entries(diagnostic.answers || {}).forEach(([name, value]) => {
            const field = form.elements.namedItem(name);
            if (field instanceof HTMLSelectElement) field.value = String(value);
        });
        const score = Number(diagnostic.score);
        if (!Number.isFinite(score)) return;
        const scoreElement = document.querySelector('.risk-score');
        const progress = document.querySelector('.progress-track span');
        const label = document.querySelector('.risk-label');
        const level = diagnostic.level || (score >= 70 ? 'alto' : score >= 35 ? 'moderado' : 'baixo');
        if (scoreElement) scoreElement.innerHTML = `${score}<small>/100</small>`;
        if (progress) progress.style.width = `${score}%`;
        if (label) label.textContent = level === 'alto' ? 'Atenção necessária' : level === 'moderado' ? 'Acompanhamento recomendado' : 'Situação estável';
        result.textContent = `Último índice estimado: ${score}/100. Nível de atenção: ${level}.`;
    };

    const installAlertActions = () => {
        const alertList = document.querySelector('[data-page="alertas"] .alert-list');
        if (!alertList) return;
        const successAlert = alertList.querySelector('.alert-success');
        if (successAlert && !successAlert.querySelector('button')) {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'text-button';
            button.textContent = 'Ver benefício';
            successAlert.appendChild(button);
            button.addEventListener('click', () => {
                showView('beneficios');
                const benefit = [...document.querySelectorAll('[data-page="beneficios"] .benefit-card')].find((card) => card.querySelector('h2')?.textContent.includes('alimentação'));
                if (benefit) openBenefitDetails(benefit);
            });
        }
        const markReadButton = document.createElement('button');
        markReadButton.type = 'button';
        markReadButton.className = 'button button-light alert-read-button';
        const read = localStorage.getItem('salveAlunoAlertsRead') === 'true';
        markReadButton.textContent = read ? 'Alertas lidos' : 'Marcar alertas como lidos';
        markReadButton.disabled = read;
        markReadButton.addEventListener('click', () => {
            localStorage.setItem('salveAlunoAlertsRead', 'true');
            markReadButton.textContent = 'Alertas lidos';
            markReadButton.disabled = true;
            updateAlertBadge();
            notify('Alertas marcados como lidos.');
        });
        alertList.appendChild(markReadButton);
    };

    document.body.addEventListener('click', (event) => {
        const target = event.target.closest('[data-view], [data-view-target]');
        if (!target) return;
        const viewName = target.dataset.view || target.dataset.viewTarget;
        if (!viewName) return;
        event.preventDefault();
        showView(viewName);
    });
    document.querySelector('#menuButton')?.addEventListener('click', () => sidebar?.classList.toggle('open'));
    document.querySelector('.profile-chip')?.addEventListener('click', openProfileEditor);
    document.querySelector('.profile-chip')?.setAttribute('role', 'button');
    document.querySelector('.profile-chip')?.setAttribute('tabindex', '0');
    document.querySelector('.profile-chip')?.setAttribute('aria-label', 'Editar perfil');
    document.querySelector('.profile-chip')?.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            openProfileEditor();
        }
    });
    document.querySelector('.notification-button')?.addEventListener('click', () => showView('alertas'));
    document.querySelector('[data-logout]')?.addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        localStorage.removeItem('rememberMe');
    });
    document.querySelector('[data-page="inicio"] .outline-button')?.addEventListener('click', () => {
        openDialog('Próximo atendimento', 'Conversa de acompanhamento com Marina Souza em 18 de setembro de 2026, às 15h. Se precisar alterar o horário, envie uma mensagem pelo Canal seguro.', [
            { label: 'Enviar mensagem', primary: true, run: () => showView('canal') },
            { label: 'Fechar', run: () => {} }
        ]);
    });
    document.querySelectorAll('.recommendation-item .small-button').forEach((button) => {
        button.addEventListener('click', () => {
            showView('beneficios');
            const title = button.closest('.recommendation-item')?.querySelector('strong')?.textContent.trim();
            const benefit = [...document.querySelectorAll('[data-page="beneficios"] .benefit-card')].find((card) => card.querySelector('h2')?.textContent.trim() === title);
            if (benefit) openBenefitDetails(benefit);
            else openDialog(title || 'Recomendação', button.closest('.recommendation-item')?.querySelector('p')?.textContent.trim() || 'Consulte os detalhes desta recomendação.', [
                { label: 'Ver oportunidades', primary: true, run: () => showView('oportunidades') },
                { label: 'Canal seguro', run: () => showView('canal') },
                { label: 'Fechar', run: () => {} }
            ]);
        });
    });
    document.querySelectorAll('[data-page="beneficios"] .text-button').forEach((button) => {
        button.addEventListener('click', () => openBenefitDetails(button.closest('.benefit-card')));
    });
    document.querySelectorAll('[data-page="beneficios"] .button-light').forEach((button) => {
        button.addEventListener('click', () => openRequestForm(button.closest('.benefit-card')?.querySelector('h2')?.textContent.trim()));
    });
    document.querySelector('.secure-card .button')?.addEventListener('click', () => {
        const field = document.querySelector('.secure-card textarea');
        const message = field?.value.trim();
        if (!message) {
            notify('Escreva uma mensagem antes de enviar.');
            field?.focus();
            return;
        }
        try {
            const user = getUser();
            const inbox = readJson('salveAlunoSecureInbox', []);
            if (!Array.isArray(inbox)) throw new Error('A caixa de mensagens está em formato inválido.');
            const anonymous = Boolean(document.querySelector('.secure-card input[type="checkbox"]')?.checked);
            inbox.push({
                id: `student-${Date.now()}-${Math.random().toString(36).slice(2)}`,
                source: 'student',
                sender: anonymous ? 'Estudante anônimo' : (user.name || 'Estudante'),
                student: anonymous ? '' : (user.name || 'Estudante'),
                anonymous,
                message,
                sentAt: new Date().toISOString(),
                read: false
            });
            if (!saveJson('salveAlunoSecureInbox', inbox)) return;
        } catch (error) {
            notify(`Não foi possível enviar a mensagem à gestão escolar: ${error.message}`);
            return;
        }
        field.value = '';
        notify('Mensagem encaminhada à caixa do canal seguro da gestão escolar.');
    });

    const initialView = window.location.hash.slice(1) || 'inicio';
    showView(titleByView[initialView] ? initialView : 'inicio');
    const settingsOptions = document.querySelectorAll('[data-page="configuracoes"] .settings-option input[type="checkbox"]');
    if (settingsOptions[3]) settingsOptions[3].id = 'opportunityNotificationToggle';
    const user = getUser();
    updateProfileLabels(user);
    installHistoryFilter();
    renderRequestHistory();
    addOpportunityActions();
    installAlertActions();
    restoreLastDiagnostic();
    applyPreferences();

    document.querySelector('#darkModeToggle')?.addEventListener('change', (event) => {
        const preferences = getPreferences();
        preferences.darkMode = event.target.checked;
        if (saveJson('salveAlunoPreferences', preferences)) applyPreferences();
    });
    document.querySelector('#colorblindModeToggle')?.addEventListener('change', (event) => {
        const preferences = getPreferences();
        preferences.colorblindMode = event.target.checked;
        if (saveJson('salveAlunoPreferences', preferences)) applyPreferences();
    });
    document.querySelector('#notificationToggle')?.addEventListener('change', (event) => {
        const preferences = getPreferences();
        preferences.notifications = { ...preferences.notifications, alerts: event.target.checked };
        saveJson('salveAlunoPreferences', preferences);
    });
    document.querySelector('#opportunityNotificationToggle')?.addEventListener('change', (event) => {
        const preferences = getPreferences();
        preferences.notifications = { ...preferences.notifications, opportunities: event.target.checked };
        saveJson('salveAlunoPreferences', preferences);
    });
    document.querySelector('#editProfileButton')?.addEventListener('click', openProfileEditor);

    const fileInput = document.querySelector('#requestForm input[type="file"]');
    fileInput?.addEventListener('change', () => {
        const files = [...fileInput.files];
        const tooLarge = files.find((file) => file.size > 10 * 1024 * 1024);
        const help = fileInput.closest('.upload-box')?.querySelector('p');
        if (tooLarge) {
            fileInput.value = '';
            if (help) help.textContent = 'PDF, JPG ou PNG até 10 MB';
            notify(`O arquivo "${tooLarge.name}" excede o limite de 10 MB.`);
            return;
        }
        if (help) help.textContent = files.length ? `${files.length} arquivo(s) selecionado(s)` : 'PDF, JPG ou PNG até 10 MB';
    });

    document.querySelector('#diagnosticForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        const result = document.querySelector('#diagnosticResult');
        button.disabled = true;
        button.textContent = 'Calculando...';
        try {
            const data = Object.fromEntries(new FormData(form));
            const score = await SalveApi.calculateRisk(data);
            const percentage = Math.round((score / 80) * 100);
            const level = percentage >= 70 ? 'alto' : percentage >= 35 ? 'moderado' : 'baixo';
            result.textContent = `Seu índice estimado é ${percentage}/100. Nível de atenção: ${level}. Nossa equipe pode conversar com você sobre os próximos passos.`;
            const scoreElement = document.querySelector('.risk-score');
            const progress = document.querySelector('.progress-track span');
            const label = document.querySelector('.risk-label');
            if (scoreElement) scoreElement.innerHTML = `${percentage}<small>/100</small>`;
            if (progress) progress.style.width = `${percentage}%`;
            if (label) label.textContent = level === 'alto' ? 'Atenção necessária' : level === 'moderado' ? 'Acompanhamento recomendado' : 'Situação estável';
            saveJson('salveAlunoLastDiagnostic', { score: percentage, level, answers: data, updatedAt: new Date().toISOString() });
            notify('Diagnóstico atualizado.');
        } catch (error) {
            notify(`Não foi possível calcular o diagnóstico: ${error.message}`);
        } finally {
            button.disabled = false;
            button.innerHTML = 'Calcular meu índice <span>→</span>';
        }
    });

    document.querySelector('#requestForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        const message = document.querySelector('#requestMessage');
        const select = form.querySelector('select');
        const files = [...(form.querySelector('input[type="file"]')?.files || [])];
        const description = form.querySelector('textarea')?.value.trim() || '';
        const preferredDate = form.querySelector('input[type="date"]')?.value || '';
        button.disabled = true;
        button.textContent = 'Enviando...';
        message.textContent = '';
        try {
            const response = await SalveApi.submitRequest({ category: select.value, description, preferredDate, attachments: files.map((file) => file.name) });
            const requests = readRequests();
            const request = { ...response, protocol: `#SA-${Date.now().toString().slice(-6)}`, category: select.value, description, preferredDate, attachments: files.map((file) => file.name), createdAt: new Date().toISOString(), status: response.status || 'Em análise' };
            requests.unshift(request);
            if (!saveJson(requestStorageKey, requests)) return;
            message.textContent = `Solicitação ${request.protocol} enviada. Você poderá acompanhar o andamento pelo Histórico.`;
            renderRequestHistory();
            form.reset();
            const uploadHelp = form.querySelector('.upload-box p');
            if (uploadHelp) uploadHelp.textContent = 'PDF, JPG ou PNG até 10 MB';
            notify(`Solicitação ${request.protocol} enviada com sucesso.`);
            showView('historico');
        } catch (error) {
            notify(`Não foi possível enviar a solicitação: ${error.message}`);
            message.textContent = 'Não foi possível enviar sua solicitação. Tente novamente.';
        } finally {
            button.disabled = false;
            button.innerHTML = 'Enviar solicitação <span>→</span>';
        }
    });
});
