const assistantCases = [
    { initials: 'LM', name: 'Lucas Martins', detail: 'Vulnerabilidade alta · transporte', status: 'Prioridade alta', tone: 'high' },
    { initials: 'AR', name: 'Ana Ribeiro', detail: 'Apoio alimentar · novo caso', status: 'Prioridade média', tone: 'medium' },
    { initials: 'JP', name: 'Joao Pedro', detail: 'Acompanhamento ativo', status: 'Em andamento', tone: 'ok' }
];

function renderAssistantCases() {
    document.querySelector('#priorityCases').innerHTML = assistantCases.map((item) => `<div class="role-list-item" data-search="${item.name.toLowerCase()} ${item.detail.toLowerCase()}"><div class="avatar">${item.initials}</div><div><strong>${item.name}</strong><small>${item.detail}</small></div><span class="status ${item.tone}">${item.status}</span></div>`).join('');
}

document.addEventListener('DOMContentLoaded', () => {
    const dialog = document.createElement('dialog');
    dialog.className = 'secure-channel-dialog';
    dialog.setAttribute('aria-labelledby', 'secureChannelTitle');
    Object.assign(dialog.style, { padding: '0', border: '0', background: 'transparent', maxWidth: 'calc(100vw - 32px)', maxHeight: '90vh', overflow: 'visible' });
    dialog.innerHTML = '<form id="secureChannelForm" class="role-modal"><header><h2 id="secureChannelTitle">Canal seguro</h2><button type="button" class="role-modal-close" data-close-channel aria-label="Fechar">×</button></header><label for="secureChannelStudent">Estudante</label><input id="secureChannelStudent" required maxlength="120" placeholder="Nome do estudante"><div class="secure-channel-messages" aria-live="polite"></div><label for="secureChannelMessage">Mensagem</label><textarea id="secureChannelMessage" rows="4" maxlength="2000" required placeholder="Escreva uma mensagem de acompanhamento"></textarea><p class="secure-channel-notice">A mensagem será salva no banco de dados e ficará disponível à equipe autorizada da escola.</p><p id="secureChannelStatus" role="status"></p><button class="role-button" type="submit">Encaminhar à gestão escolar</button></form>';
    Object.assign(dialog.querySelector('form').style, { maxHeight: '85vh', overflowY: 'auto' });
    Object.assign(dialog.querySelector('.secure-channel-notice').style, { padding: '10px', borderRadius: '8px', background: '#fff5d8', color: '#7d8992', fontSize: '11px', lineHeight: '1.5' });
    Object.assign(dialog.querySelector('.secure-channel-messages').style, { display: 'grid', gap: '8px', maxHeight: '180px', overflowY: 'auto', marginTop: '16px' });
    document.body.appendChild(dialog);

    const loadRecords = async () => {
        const [appointments, referrals] = await Promise.all([
            SalveDatabase.listRecords('social_appointment'),
            SalveDatabase.listRecords('teacher_referral')
        ]);
        const appointmentContainer = document.querySelector('#pendingAttendances');
        appointmentContainer.replaceChildren();
        appointments.records.forEach(({ data }) => {
            const item = document.createElement('div');
            item.className = 'role-list-item';
            const detail = document.createElement('small');
            detail.textContent = `${data.date || ''} · ${data.type || 'Atendimento'}`;
            const name = document.createElement('strong');
            name.textContent = data.student || 'Estudante';
            const avatar = document.createElement('div');
            avatar.className = 'avatar';
            avatar.textContent = '◷';
            const content = document.createElement('div');
            content.append(name, detail);
            item.append(content);
            appointmentContainer.appendChild(item);
        });
        const referralContainer = document.querySelector('#referrals');
        referralContainer.replaceChildren();
        referrals.records.forEach(({ data }) => {
            const item = document.createElement('div');
            item.className = 'role-list-item';
            const avatar = document.createElement('div');
            avatar.className = 'avatar';
            avatar.textContent = '↗';
            const content = document.createElement('div');
            const name = document.createElement('strong');
            name.textContent = data.student || 'Estudante';
            const detail = document.createElement('small');
            detail.textContent = `${data.reason || 'Encaminhamento'} · ${data.note || ''}`;
            content.append(name, detail);
            item.append(avatar, content);
            referralContainer.appendChild(item);
        });
    };

    const loadSecureMessages = async () => {
        const status = dialog.querySelector('#secureChannelStatus');
        const selectedStudent = dialog.querySelector('#secureChannelStudent').value.trim().toLocaleLowerCase('pt-BR');
        const container = dialog.querySelector('.secure-channel-messages');
        container.replaceChildren();
        try {
            const { messages } = await SalveDatabase.request('messages-list');
            const filtered = messages.filter((message) => message.source === 'assistant' &&
                message.student.toLocaleLowerCase('pt-BR') === selectedStudent);
            if (!filtered.length) {
                const empty = document.createElement('p');
                empty.textContent = 'Nenhuma mensagem salva para este estudante.';
                container.appendChild(empty);
                return;
            }
            filtered.forEach((message) => {
                const item = document.createElement('article');
                Object.assign(item.style, { padding: '10px 12px', borderRadius: '8px', background: '#f4f8f5', overflowWrap: 'anywhere' });
                const body = document.createElement('p');
                body.textContent = message.message;
                const date = document.createElement('small');
                const sentAt = new Date(message.sentAt);
                date.textContent = Number.isNaN(sentAt.getTime()) ? 'Data indisponível' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(sentAt);
                item.append(body, date);
                container.appendChild(item);
            });
        } catch (error) {
            status.textContent = `Não foi possível carregar as mensagens: ${error.message}`;
        }
    };

    renderAssistantCases();
    loadRecords().catch((error) => {
        document.querySelector('#pendingAttendances').textContent = `Não foi possível carregar os atendimentos: ${error.message}`;
        document.querySelector('#referrals').textContent = `Não foi possível carregar os encaminhamentos: ${error.message}`;
    });
    document.querySelector('#caseSearch')?.addEventListener('input', (event) => {
        const query = event.target.value.toLowerCase();
        document.querySelectorAll('#priorityCases [data-search]').forEach((item) => { item.hidden = !item.dataset.search.includes(query); });
    });
    document.querySelector('#newAttendance')?.addEventListener('click', () => { document.querySelector('#attendanceModal').hidden = false; });
    document.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', () => { document.querySelector('#attendanceModal').hidden = true; }));
    document.querySelector('#attendanceForm')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const fields = form.querySelectorAll('input, select');
        const button = form.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            await SalveDatabase.saveRecord('social_appointment', {
                student: fields[0].value.trim(),
                date: fields[1].value,
                type: fields[2].value
            });
            document.querySelector('#attendanceMessage').textContent = 'Atendimento salvo no banco de dados.';
            form.reset();
            await loadRecords();
            window.setTimeout(() => { document.querySelector('#attendanceModal').hidden = true; }, 900);
        } catch (error) {
            document.querySelector('#attendanceMessage').textContent = `Não foi possível salvar o atendimento: ${error.message}`;
        } finally {
            button.disabled = false;
        }
    });
    document.querySelector('.role-notice .role-button')?.addEventListener('click', () => {
        dialog.querySelector('#secureChannelStatus').textContent = '';
        dialog.showModal();
        loadSecureMessages();
    });
    dialog.querySelector('[data-close-channel]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
    dialog.querySelector('#secureChannelStudent').addEventListener('change', loadSecureMessages);
    dialog.querySelector('#secureChannelForm').addEventListener('submit', async (event) => {
        event.preventDefault();
        const student = dialog.querySelector('#secureChannelStudent').value.trim();
        const messageField = dialog.querySelector('#secureChannelMessage');
        const button = event.currentTarget.querySelector('[type="submit"]');
        button.disabled = true;
        try {
            await SalveDatabase.request('message-send', {
                method: 'POST',
                data: { student, message: messageField.value.trim() }
            });
            messageField.value = '';
            dialog.querySelector('#secureChannelStatus').textContent = 'Mensagem salva no canal seguro da gestão escolar.';
            await loadSecureMessages();
        } catch (error) {
            dialog.querySelector('#secureChannelStatus').textContent = `Não foi possível enviar a mensagem: ${error.message}`;
        } finally {
            button.disabled = false;
        }
    });
});
