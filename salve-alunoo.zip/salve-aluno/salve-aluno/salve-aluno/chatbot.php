<?php
declare(strict_types=1);

session_start([
    'cookie_httponly' => true,
    'cookie_secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'cookie_samesite' => 'Lax'
]);

if (!isset($_SESSION['team_chat_csrf'])) {
    $_SESSION['team_chat_csrf'] = bin2hex(random_bytes(32));
}

function escapeChat(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function answerTeamQuestion(string $message): string
{
    $normalized = function_exists('iconv')
        ? iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $message)
        : false;
    $message = strtolower($normalized === false ? $message : $normalized);

    if (preg_match('/\b(urgente|emergencia|perigo|risco imediato|me machucar|me ferir)\b/', $message)) {
        return 'Se você ou alguém estiver em perigo imediato, procure agora um adulto de confiança e os serviços de emergência da sua região. Este chat não é monitorado em tempo real. Para conversar com a equipe, escreva para oi@salvealuno.org.';
    }
    if (str_contains($message, 'privacidade') || str_contains($message, 'confidencial') || str_contains($message, 'dados')) {
        return 'O Salve Aluno é uma porta de entrada para orientação e apoio. Evite compartilhar senhas, documentos ou informações íntimas neste chat. Para dúvidas sobre privacidade, fale com a equipe pelo e-mail oi@salvealuno.org.';
    }
    if (str_contains($message, 'senha') || str_contains($message, 'login') || str_contains($message, 'entrar') || str_contains($message, 'acesso')) {
        return 'Para entrar, use o e-mail e a senha da sua conta e selecione o perfil correto na tela de login. Se não conseguir acessar, peça ajuda à gestão da sua escola ou escreva para oi@salvealuno.org.';
    }
    if (str_contains($message, 'cadastro') || str_contains($message, 'conta') || str_contains($message, 'perfil')) {
        return 'As contas de alunos e professores são cadastradas pela gestão escolar. Se você é estudante ou professor, procure a gestão da sua escola para criar ou corrigir seu acesso.';
    }
    if (str_contains($message, 'escola') || str_contains($message, 'gestao') || str_contains($message, 'parceria')) {
        return 'O painel da escola ajuda a gestão a acompanhar solicitações e cadastrar alunos e professores. Para conversar sobre parceria ou implantação, escreva para oi@salvealuno.org.';
    }
    if (str_contains($message, 'beneficio') || str_contains($message, 'solicitacao') || str_contains($message, 'apoio') || str_contains($message, 'ajuda')) {
        return 'Entre no painel do estudante para consultar benefícios e registrar uma solicitação de apoio. A equipe da escola poderá acompanhar o pedido. Não inclua dados sensíveis aqui.';
    }
    if (str_contains($message, 'equipe') || str_contains($message, 'humano') || str_contains($message, 'pessoa') || str_contains($message, 'email') || str_contains($message, 'e-mail')) {
        return 'Este assistente responde dúvidas gerais, mas não envia mensagens para a equipe. Para falar com uma pessoa, escreva diretamente para oi@salvealuno.org.';
    }

    return 'Posso ajudar com dúvidas sobre acesso, cadastro, privacidade, benefícios e uso do painel escolar. Escreva sua dúvida sem incluir senhas ou informações pessoais. Para falar diretamente com a equipe, use oi@salvealuno.org.';
}

$_SESSION['team_chat_history'] ??= [
    [
        'role' => 'assistant',
        'text' => 'Olá! Sou o assistente virtual do Salve Aluno. Posso responder dúvidas gerais sobre acesso, cadastro e apoio escolar. Não sou uma pessoa da equipe e este chat não é monitorado em tempo real.'
    ]
];
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['team_chat_csrf'], $token)) {
        $error = 'A sessão expirou. Atualize a página e tente novamente.';
    } elseif (($_POST['action'] ?? '') === 'clear') {
        $_SESSION['team_chat_history'] = [[
            'role' => 'assistant',
            'text' => 'Olá! Sou o assistente virtual do Salve Aluno. Posso responder dúvidas gerais sobre acesso, cadastro e apoio escolar. Não sou uma pessoa da equipe e este chat não é monitorado em tempo real.'
        ]];
        header('Location: chatbot.php');
        exit;
    } else {
        $message = $_POST['message'] ?? '';
        if (!is_string($message)) {
            $error = 'A mensagem enviada não é válida.';
        } else {
            $message = trim($message);
            $messageLength = preg_match_all('/./us', $message, $characters);
            if ($message === '') {
                $error = 'Escreva uma dúvida antes de enviar.';
            } elseif ($messageLength === false) {
                $error = 'A mensagem contém caracteres inválidos.';
            } elseif ($messageLength > 1000) {
                $error = 'A mensagem deve ter no máximo 1.000 caracteres.';
            } else {
                $_SESSION['team_chat_history'][] = ['role' => 'user', 'text' => $message];
                $_SESSION['team_chat_history'][] = ['role' => 'assistant', 'text' => answerTeamQuestion($message)];
                $_SESSION['team_chat_history'] = array_slice($_SESSION['team_chat_history'], -30);
                header('Location: chatbot.php');
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Assistente virtual do Salve Aluno para dúvidas gerais.">
    <title>Falar com a equipe | Salve Aluno</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
    <style>
        :root{font-family:"DM Sans",sans-serif;color:#183b35;background:#f4f8f5;font-synthesis:none}
        *{box-sizing:border-box}
        body{margin:0;min-height:100vh;padding:32px 16px;background:linear-gradient(145deg,#f4f8f5,#e8f2ed)}
        .chat-shell{width:min(720px,100%);margin:0 auto;border:1px solid #dbe8df;border-radius:20px;background:#fff;box-shadow:0 18px 48px rgba(23,75,60,.12);overflow:hidden}
        .chat-header{padding:24px 28px;background:#176b59;color:#fff}
        .chat-header a{color:#e1f5eb;text-decoration:none;font-size:14px}
        .chat-header h1{margin:18px 0 6px;font:700 27px "Space Grotesk",sans-serif}
        .chat-header p{margin:0;color:#d6eee4;line-height:1.5}
        .chat-notice{margin:18px 22px 0;padding:12px 14px;border-radius:10px;background:#fff5dc;color:#684d10;font-size:13px;line-height:1.5}
        .chat-log{display:flex;flex-direction:column;gap:12px;min-height:300px;max-height:52vh;overflow:auto;padding:20px 22px}
        .chat-message{max-width:88%;padding:12px 15px;border-radius:14px;line-height:1.5;overflow-wrap:anywhere}
        .chat-message.assistant{align-self:flex-start;background:#eff6f1}
        .chat-message.user{align-self:flex-end;background:#176b59;color:#fff}
        .chat-form{display:flex;gap:10px;padding:16px 22px;border-top:1px solid #e4ece6}
        .chat-form textarea{flex:1;min-height:54px;max-height:150px;resize:vertical;padding:13px;border:1px solid #cbd9d0;border-radius:10px;font:inherit}
        button{border:0;border-radius:10px;padding:0 20px;background:#176b59;color:#fff;font:600 15px "DM Sans",sans-serif;cursor:pointer}
        button:hover{background:#125544}
        .chat-error{margin:12px 22px 0;color:#a33d36;font-size:14px}
        .chat-footer{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:0 22px 20px;color:#61746b;font-size:13px}
        .chat-footer a{color:#176b59}
        .clear-form{margin:0}
        .clear-form button{padding:8px 10px;background:#eef4f0;color:#31574b;font-size:12px}
        @media(max-width:520px){body{padding:12px 8px}.chat-shell{border-radius:14px}.chat-header{padding:20px}.chat-log{min-height:280px;padding:16px}.chat-form{padding:14px 16px}.chat-footer{padding:0 16px 16px;align-items:flex-start;flex-direction:column}}
    </style>
</head>
<body>
    <main class="chat-shell">
        <header class="chat-header">
            <a href="index.php">← Voltar ao Salve Aluno</a>
            <h1>Assistente virtual</h1>
            <p>Uma primeira orientação para dúvidas comuns.</p>
        </header>
        <p class="chat-notice">Este assistente é automático e não encaminha mensagens à equipe. Não envie senhas ou informações pessoais. Para falar com uma pessoa, use <a href="mailto:oi@salvealuno.org">oi@salvealuno.org</a>.</p>
        <section class="chat-log" aria-label="Conversa com o assistente" aria-live="polite">
            <?php foreach ($_SESSION['team_chat_history'] as $entry): ?>
                <div class="chat-message <?= escapeChat($entry['role']) ?>"><?= nl2br(escapeChat($entry['text'])) ?></div>
            <?php endforeach; ?>
        </section>
        <?php if ($error !== ''): ?>
            <p class="chat-error" role="alert"><?= escapeChat($error) ?></p>
        <?php endif; ?>
        <form class="chat-form" method="post" action="chatbot.php">
            <input type="hidden" name="csrf_token" value="<?= escapeChat($_SESSION['team_chat_csrf']) ?>">
            <label for="message" class="visually-hidden">Sua dúvida</label>
            <textarea id="message" name="message" maxlength="1000" placeholder="Escreva sua dúvida..." required></textarea>
            <button type="submit">Enviar</button>
        </form>
        <footer class="chat-footer">
            <span>Respostas automáticas para orientações gerais.</span>
            <form class="clear-form" method="post" action="chatbot.php">
                <input type="hidden" name="csrf_token" value="<?= escapeChat($_SESSION['team_chat_csrf']) ?>">
                <input type="hidden" name="action" value="clear">
                <button type="submit">Limpar conversa</button>
            </form>
        </footer>
    </main>
    <style>.visually-hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}</style>
</body>
</html>
